<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->string('customer_name', 120)->nullable()->after('user_id');
            $table->string('customer_email', 190)->nullable()->after('customer_name');
            $table->string('customer_phone', 30)->nullable()->after('customer_email');
            $table->string('receiver_name', 120)->nullable()->after('address_id');
            $table->string('receiver_phone', 30)->nullable()->after('receiver_name');
            $table->string('shipping_province', 100)->nullable()->after('receiver_phone');
            $table->string('shipping_city', 100)->nullable()->after('shipping_province');
            $table->text('shipping_address')->nullable()->after('shipping_city');
            $table->string('shipping_postal_code', 20)->nullable()->after('shipping_address');
            $table->string('shipping_method', 20)->nullable()->after('shipping_postal_code');
            $table->string('discount_code', 50)->nullable()->after('discount');
        });

        Schema::table('order_items', function (Blueprint $table) {
            $table->string('product_sku', 100)->nullable()->after('product_name');
            $table->string('variant_sku', 100)->nullable()->after('product_sku');
            $table->string('variant_size', 100)->nullable()->after('variant_sku');
            $table->string('variant_color', 100)->nullable()->after('variant_size');
            $table->string('variant_image', 500)->nullable()->after('variant_color');
        });
    }

    public function down(): void
    {
        Schema::table('order_items', function (Blueprint $table) {
            $table->dropColumn(['product_sku', 'variant_sku', 'variant_size', 'variant_color', 'variant_image']);
        });

        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn([
                'customer_name', 'customer_email', 'customer_phone',
                'receiver_name', 'receiver_phone', 'shipping_province', 'shipping_city',
                'shipping_address', 'shipping_postal_code', 'shipping_method', 'discount_code',
            ]);
        });
    }
};
