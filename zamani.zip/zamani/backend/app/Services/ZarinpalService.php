<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;

class ZarinpalService
{
    public function request(
        int $amount,
        string $description,
        string $callback,
        ?string $email = null,
        ?string $mobile = null
    ): array {

        $payload = [
            'merchant_id' => config('zarinpal.merchant_id'),
            'amount' => $amount,
            'currency' => 'IRR',
            'description' => $description,
            'callback_url' => $callback,
            'metadata' => array_filter([
                'email' => $email,
                'mobile' => $mobile,
            ]),
        ];

        Log::info('Zarinpal payment request started', [
            'amount' => $amount,
            'has_email' => !empty($email),
            'has_mobile' => !empty($mobile),
        ]);

        $response = Http::acceptJson()
            ->timeout(20)
            ->post(config('zarinpal.request_url'), $payload);


        Log::info('Zarinpal payment request response', [
            'status' => $response->status(),
            'success' => $response->successful(),
        ]);


        if (!$response->successful()) {

            throw new RuntimeException(
                'خطا در ارتباط با زرین‌پال: HTTP ' . $response->status()
            );
        }


        $json = $response->json();

        $data = $json['data'] ?? [];


        if (($data['code'] ?? null) !== 100 || empty($data['authority'])) {

            throw new RuntimeException(
                $this->message(
                    $data['code'] ?? null,
                    $json['errors'] ?? []
                )
            );
        }


        return [
            'authority' => $data['authority'],
            'url' => config('zarinpal.start_url') . $data['authority'],
            'raw' => $json,
        ];
    }


    public function verify(int $amount, string $authority): array
    {

        $response = Http::acceptJson()
            ->timeout(20)
            ->post(config('zarinpal.verify_url'), [
                'merchant_id' => config('zarinpal.merchant_id'),
                'amount' => $amount,
                'authority' => $authority,
            ]);


        Log::info('Zarinpal verify response', [
            'status' => $response->status(),
            'success' => $response->successful(),
        ]);


        if (!$response->successful()) {

            throw new RuntimeException(
                'تأیید تراکنش از زرین‌پال ناموفق بود.'
            );
        }


        $json = $response->json();

        $data = $json['data'] ?? [];


        return [
            'code' => $data['code'] ?? null,
            'ref_id' => $data['ref_id'] ?? null,
            'raw' => $json,
        ];
    }


    private function message($code, array $errors): string
    {

        if ($code === -9) {
            return 'خطای اعتبارسنجی اطلاعات پرداخت.';
        }

        if ($code === -10) {
            return 'اطلاعات پذیرنده یا درگاه نامعتبر است.';
        }

        if ($code === -11) {
            return 'درخواست پرداخت با خطا مواجه شد.';
        }

        return $errors['message'] ?? 'ایجاد تراکنش در زرین‌پال انجام نشد.';
    }
}