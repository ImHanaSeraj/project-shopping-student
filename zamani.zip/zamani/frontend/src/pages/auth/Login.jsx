import React, { useState } from 'react';
import { Link, useNavigate } from '../utils/routerCompat';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ login: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const change = (e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await api.post('/auth/login', form);
      login(response.data.user, response.data.token);
      navigate('/profile', { replace: true });
    } catch (err) {
      if (!err.response) {
        setError('ارتباط با سرویس فروشگاه برقرار نشد. لطفاً دوباره تلاش کنید.');
      } else if (err.response.status === 401) {
        setError('ایمیل/شماره موبایل یا رمز عبور اشتباه است.');
      } else if (err.response.status === 422) {
        setError('اطلاعات ورود را کامل و صحیح وارد کنید.');
      } else {
        setError(err.response.data?.message || `خطایی در ورود رخ داد. (کد ${err.response.status})`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth">
      <form onSubmit={submit} noValidate>
        <h1>ZAMANI</h1>
        <p className="auth-subtitle">ورود به حساب کاربری</p>
        {error && <div className="auth-error" role="alert">{error}</div>}
        <input name="login" value={form.login} onChange={change} placeholder="ایمیل یا شماره موبایل" autoComplete="username" required />
        <input name="password" value={form.password} onChange={change} type="password" placeholder="رمز عبور" autoComplete="current-password" required />
        <button type="submit" disabled={loading}>{loading ? 'در حال ورود...' : 'ورود'}</button>
        <div className="auth-links">
          <Link to="/register">حساب کاربری ندارید؟ <strong>ثبت‌نام کنید</strong></Link>
          <Link to="/forgot-password">رمز عبور را فراموش کرده‌اید؟</Link>
          <Link to="/">بازگشت به فروشگاه</Link>
        </div>
      </form>
    </div>
  );
}
