<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->string('inventory_status', 20)->default('none')->after('payment_status');
            $table->timestamp('inventory_reserved_at')->nullable()->after('inventory_status');
            $table->timestamp('inventory_released_at')->nullable()->after('inventory_reserved_at');
            $table->index(['inventory_status', 'status']);
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropIndex(['inventory_status', 'status']);
            $table->dropColumn(['inventory_status', 'inventory_reserved_at', 'inventory_released_at']);
        });
    }
};
