import React,{useState} from 'react';

export default function ProductImageUploader({onUpload}){
 const [preview,setPreview]=useState([]);
 const change=e=>{
  const files=[...e.target.files];
  setPreview(files.map(f=>URL.createObjectURL(f)));
  if(onUpload) onUpload(files);
 };
 return <div className="image-uploader">
  <input type="file" multiple accept="image/*" onChange={change}/>
  <div>{preview.map((p,i)=><img key={i} src={p} alt="preview" />)}</div>
 </div>
}
