import Login from '../views/auth/Login';
import GuestRoute from '../guards/GuestRoute';
export default function LoginPage(){ return <GuestRoute><Login/></GuestRoute>; }
