<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\GeminiService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Throwable;

class GeminiController extends Controller
{
    public function __invoke(Request $request, GeminiService $gemini): JsonResponse
    {
        $mode = $request->input('mode', 'chat');
        if (!in_array($mode, ['chat','size','product_copy'], true)) return response()->json(['message'=>'حالت AI نامعتبر است.'], 422);
        if ($mode === 'chat' && !trim((string)$request->input('message'))) return response()->json(['message'=>'پیام خالی است.'], 422);
        if ($mode === 'product_copy' && !$request->user()) return response()->json(['message'=>'برای تولید متن محصول باید وارد پنل مدیریت شوید.'], 401);
        try {
            return response()->json($gemini->generate($mode, $request->all()));
        } catch (Throwable $e) {
            return response()->json(['message'=>$e->getMessage()], 502);
        }
    }
}
