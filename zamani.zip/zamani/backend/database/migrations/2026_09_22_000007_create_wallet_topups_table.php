<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::create('wallet_topups', function(Blueprint $t){
  $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->decimal('amount',14,2); $t->string('status',30)->default('pending');
  $t->string('authority')->nullable()->unique(); $t->string('transaction_id')->nullable(); $t->string('ref_id')->nullable(); $t->timestamp('paid_at')->nullable(); $t->timestamps();
  $t->index(['user_id','status']);
 }); }
 public function down(): void { Schema::dropIfExists('wallet_topups'); }
};
