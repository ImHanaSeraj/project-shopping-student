// Variants in the database can be stored in either the newer size/color
// columns or the older name/value format (name: "رنگ" / "سایز" / "جنس پارچه",
// value: the actual color/size/material). Normalize both formats so any
// page can ask "what colors/sizes/materials does this product have" the
// same way. Used by ProductDetails (variant picker) and Compare (table rows).

export const VARIANT_NAMES = {
  color: ['رنگ', 'color', 'colour'],
  size: ['سایز', 'size'],
  model: ['مدل', 'model', 'style'],
  material: ['جنس پارچه', 'جنس', 'material', 'fabric'],
};

export const normalize = (value) => String(value || '').trim().toLowerCase();

export function variantsByType(variants, type) {
  const names = VARIANT_NAMES[type] || [];
  const list = variants || [];
  const modern = list.filter((v) => v[type]);
  if (modern.length) {
    return [...new Set(modern.map((v) => v[type]).filter(Boolean))].map((value) => ({ value }));
  }
  return [...new Map(list.filter((v) => names.includes(normalize(v.name))).map((v) => [v.value, v])).values()];
}
