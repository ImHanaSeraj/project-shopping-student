import { useEffect } from "react";

function useDocumentTitle(title) {
  useEffect(() => {
    document.title = title;
    return () => {
      document.title = "کالکشن زمانی | ZAMANI";
    };
  }, [title]);
}

export default useDocumentTitle;