<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;









class File extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'path', 'disk', 'mime_type', 'size', 'collection', 'uploaded_by',
    ];

    protected $appends = ['url'];

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    public function getUrlAttribute(): string
    {
        return Storage::disk($this->disk)->url($this->path);
    }
}
