import { useMemo, useState } from 'react';
import { Link, useNavigate, useSearchParams } from '../utils/routerCompat';
import api from '../../services/api';

export default function ResetPassword() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const token = useMemo(() => params.get('token') || '', [params]);
  const email = useMemo(() => params.get('email') || '', [params]);
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const submit = async (event) => {
    event.preventDefault();
    setError('');
    setMessage('');
    if (!token || !email) {
      setError('لینک بازیابی ناقص یا نامعتبر است.');
      return;
    }
    if (password !== confirmation) {
      setError('تکرار رمز عبور با رمز جدید یکسان نیست.');
      return;
    }
    setLoading(true);
    try {
      const response = await api.post('/auth/reset-password', {
        token,
        email,
        password,
        password_confirmation: confirmation,
      });
      setMessage(response.data?.message || 'رمز عبور تغییر کرد.');
      setTimeout(() => navigate('/login', { replace: true }), 1200);
    } catch (err) {
      const errors = Object.values(err.response?.data?.errors || {}).flat();
      setError(errors[0] || err.response?.data?.message || 'امکان تغییر رمز عبور وجود ندارد.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth">
      <form onSubmit={submit} noValidate>
        <h1>ZAMANI</h1>
        <p className="auth-subtitle">تنظیم رمز عبور جدید</p>
        {error && <div className="auth-error" role="alert">{error}</div>}
        {message && <div className="auth-success" role="status">{message}</div>}
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="رمز عبور جدید" autoComplete="new-password" required />
        <input type="password" value={confirmation} onChange={(e) => setConfirmation(e.target.value)} placeholder="تکرار رمز عبور جدید" autoComplete="new-password" required />
        <button type="submit" disabled={loading}>{loading ? 'در حال ذخیره...' : 'تغییر رمز عبور'}</button>
        <div className="auth-links">
          <Link to="/login">بازگشت به ورود</Link>
          <Link to="/">بازگشت به فروشگاه</Link>
        </div>
      </form>
    </div>
  );
}
