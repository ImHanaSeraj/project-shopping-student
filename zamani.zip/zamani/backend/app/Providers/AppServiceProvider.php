<?php

namespace App\Providers;

use App\Contracts\SmsGatewayInterface;
use App\Services\Sms\KavenegarSmsGateway;
use App\Services\Sms\LogSmsGateway;
use App\Services\Sms\MelipayamakSmsGateway;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(SmsGatewayInterface::class, function () {
            return match (config('otp.driver', 'log')) {
                'kavenegar' => new KavenegarSmsGateway(),
                'melipayamak' => new MelipayamakSmsGateway(),
                default => new LogSmsGateway(),
            };
        });
    }

    public function boot(): void
    {
        ResetPassword::createUrlUsing(function ($user, string $token): string {
            $frontend = rtrim(config('app.frontend_url', 'http://localhost:3000'), '/');
            return $frontend . '/reset-password?token=' . urlencode($token)
                . '&email=' . urlencode($user->getEmailForPasswordReset());
        });
    }
}
