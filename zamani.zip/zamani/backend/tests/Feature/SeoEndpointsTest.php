<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SeoEndpointsTest extends TestCase
{
    use RefreshDatabase;

    public function test_robots_endpoint_disallows_private_routes_and_points_to_sitemap(): void
    {
        config(['app.frontend_url' => 'https://shop.example']);

        $response = $this->get('/robots.txt');

        $response->assertOk();
        $response->assertHeader('content-type', 'text/plain; charset=UTF-8');
        $response->assertSee('Disallow: /admin');
        $response->assertSee('Disallow: /checkout');
        $response->assertSee('Sitemap: https://shop.example/sitemap.xml');
    }

    public function test_sitemap_contains_only_active_products_and_categories(): void
    {
        config(['app.frontend_url' => 'https://shop.example']);

        Category::factory()->create(['name' => 'فعال', 'slug' => 'active-category', 'status' => true]);
        Category::factory()->create(['name' => 'غیرفعال', 'slug' => 'inactive-category', 'status' => false]);
        Product::factory()->create(['name' => 'فعال', 'slug' => 'active-product', 'status' => true]);
        Product::factory()->create(['name' => 'غیرفعال', 'slug' => 'inactive-product', 'status' => false]);

        $response = $this->get('/sitemap.xml');

        $response->assertOk();
        $response->assertHeader('content-type', 'application/xml; charset=UTF-8');
        $response->assertSee('https://shop.example/products/active-product');
        $response->assertSee('https://shop.example/categories/active-category');
        $response->assertDontSee('inactive-product');
        $response->assertDontSee('inactive-category');
    }
}
