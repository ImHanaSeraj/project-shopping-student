<?php

namespace Database\Seeders;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DemoProductsSeeder extends Seeder
{
    public function run(): void
    {
        $brand = Brand::updateOrCreate(
            ['slug' => 'zamani'],
            ['name' => 'ZAMANI', 'description' => 'کالکشن زمانی', 'status' => true]
        );

        $products = [
            [
                'name' => 'تیشرت مردانه مشکی',
                'slug' => 'black-mens-tshirt',
                'description' => 'تیشرت مشکی ساده با فرم راحت و مناسب استفاده روزمره.',
                'short_description' => 'تیشرت مینیمال و راحت برای استایل روزمره.',
                'price' => 850000,
                'discount_price' => null,
                'stock' => 25,
                'SKU' => 'ZM-TS-BLK-001',
                'category' => ['name' => 'تیشرت', 'slug' => 'tshirt'],
                'image' => '/images/products/product-tshirt-black.jpg',
                'featured' => true,
            ],
            [
                'name' => 'هودی کلاهدار کرم',
                'slug' => 'cream-hoodie',
                'description' => 'هودی کلاهدار کرم با پارچه نرم و فرم آزاد.',
                'short_description' => 'هودی گرم و نرم برای استایل کژوال.',
                'price' => 1650000,
                'discount_price' => 1450000,
                'stock' => 15,
                'SKU' => 'ZM-HD-CRM-001',
                'category' => ['name' => 'هودی', 'slug' => 'hoodie'],
                'image' => '/images/products/product-hoodie-cream.jpg',
                'featured' => true,
            ],
            [
                'name' => 'کتونی سفید کلاسیک',
                'slug' => 'classic-white-sneakers',
                'description' => 'کتونی سفید کلاسیک با طراحی مینیمال و مناسب استفاده روزانه.',
                'short_description' => 'کتونی سفید ساده برای استایل‌های روزمره.',
                'price' => 2350000,
                'discount_price' => null,
                'stock' => 10,
                'SKU' => 'ZM-SN-WHT-001',
                'category' => ['name' => 'کفش', 'slug' => 'shoes'],
                'image' => '/images/products/product-sneakers-white.jpg',
                'featured' => false,
            ],
        ];

        foreach ($products as $item) {
            $category = Category::updateOrCreate(
                ['slug' => $item['category']['slug']],
                ['name' => $item['category']['name'], 'status' => true]
            );

            $product = Product::updateOrCreate(
                ['SKU' => $item['SKU']],
                [
                    'name' => $item['name'],
                    'slug' => $item['slug'],
                    'description' => $item['description'],
                    'short_description' => $item['short_description'],
                    'price' => $item['price'],
                    'discount_price' => $item['discount_price'],
                    'stock' => $item['stock'],
                    'category_id' => $category->id,
                    'brand_id' => $brand->id,
                    'status' => true,
                    'featured' => $item['featured'],
                ]
            );

            $product->images()->delete();
            $product->images()->create([
                'image' => $item['image'],
                'is_primary' => true,
                'sort_order' => 0,
            ]);
        }
    }
}
