<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Route;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class SecurityHardeningTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_product_api_has_no_write_routes(): void
    {
        $this->assertFalse(Route::has('products.store'));
        $this->assertFalse(Route::has('products.update'));
        $this->assertFalse(Route::has('products.destroy'));
    }

    public function test_customer_cannot_access_another_users_order_payment_or_address(): void
    {
        $owner = User::factory()->create(['role' => 'customer', 'status' => true]);
        $attacker = User::factory()->create(['role' => 'customer', 'status' => true]);
        $address = Address::factory()->create(['user_id' => $owner->id]);
        $order = Order::factory()->create(['user_id' => $owner->id, 'address_id' => $address->id]);
        $payment = Payment::factory()->create(['order_id' => $order->id, 'amount' => $order->final_total]);

        Sanctum::actingAs($attacker);
        $this->getJson('/api/orders/'.$order->id)->assertNotFound();
        $this->getJson('/api/payments/'.$order->id)->assertForbidden();
        $this->putJson('/api/checkout/addresses/'.$address->id, [
            'receiver_name' => 'Attacker', 'phone' => '09120000000', 'province' => 'Tehran',
            'city' => 'Tehran', 'address' => 'Nope', 'postal_code' => '1234567890', 'is_default' => true,
        ])->assertNotFound();
        $this->deleteJson('/api/checkout/addresses/'.$address->id)->assertNotFound();
        $this->assertDatabaseHas('payments', ['id' => $payment->id, 'order_id' => $order->id]);
    }

    public function test_customer_cannot_access_admin_api(): void
    {
        Sanctum::actingAs(User::factory()->create(['role' => 'customer', 'status' => true]));
        $this->getJson('/api/admin/dashboard')->assertForbidden();
        $this->postJson('/api/admin/products', [])->assertForbidden();
        $this->getJson('/api/admin/users')->assertForbidden();
    }

    public function test_registration_cannot_mass_assign_admin_role_or_disabled_status(): void
    {
        $response = $this->postJson('/api/auth/register', [
            'name' => 'Safe User',
            'phone' => '0912'.random_int(1000000, 9999999),
            'email' => 'safe-'.uniqid().'@example.com',
            'password' => 'StrongPass123!',
            'password_confirmation' => 'StrongPass123!',
            'role' => 'admin',
            'status' => false,
        ]);

        $response->assertCreated();
        $user = User::where('email', $response->json('user.email'))->firstOrFail();
        $this->assertSame('customer', $user->role);
        $this->assertTrue((bool) $user->status);
    }

    public function test_search_treats_sql_payload_as_data_not_sql(): void
    {
        Product::factory()->create(['status' => true, 'name' => 'Normal Shirt']);
        Product::factory()->create(['status' => true, 'name' => 'Another Shirt']);

        $response = $this->getJson('/api/search?q=%27%20OR%201%3D1%20--');
        $response->assertSuccessful()->assertJsonPath('products_total', 0);
    }

    public function test_admin_image_upload_rejects_non_image_files(): void
    {
        Storage::fake('public');
        $admin = User::factory()->create(['role' => 'admin', 'status' => true]);
        Sanctum::actingAs($admin);

        $this->post('/api/admin/products/upload-image', [
            'image' => UploadedFile::fake()->create('payload.php', 10, 'application/x-php'),
        ])->assertUnprocessable();
    }

    public function test_cors_does_not_allow_arbitrary_origin(): void
    {
        $this->withHeader('Origin', 'https://attacker.example')
            ->get('/api/health')
            ->assertSuccessful()
            ->assertHeaderMissing('Access-Control-Allow-Origin');
    }

    public function test_frontend_does_not_use_unsafe_raw_html_rendering(): void
    {
        $root = realpath(base_path('../frontend/src'));
        $contents = '';
        if ($root !== false) {
            $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS));
            foreach ($iterator as $file) {
                if ($file->isFile() && in_array(strtolower($file->getExtension()), ['js', 'jsx'], true)) {
                    $contents .= file_get_contents($file->getPathname());
                }
            }
        }

        $this->assertStringNotContainsString('dangerouslySetInnerHTML', $contents);
        $this->assertStringNotContainsString('.innerHTML', $contents);
    }
}
