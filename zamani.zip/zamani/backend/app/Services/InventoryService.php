<?php

namespace App\Services;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class InventoryService
{
    public const RESERVED = 'reserved';
    public const COMMITTED = 'committed';
    public const RELEASED = 'released';

    /**
     * Reserve the exact quantities represented by the order items.
     * Must be called inside a database transaction.
     */
    public function reserve(Order $order): void
    {
        if ($order->inventory_status === self::RESERVED || $order->inventory_status === self::COMMITTED) {
            return;
        }
        // A failed payment releases stock. The same pending order may be paid again,
        // so a released reservation can be safely re-created from current stock.
        if ($order->inventory_status === self::RELEASED) {
            $order->forceFill([
                'inventory_status' => 'none',
                'inventory_released_at' => null,
            ])->save();
        }

        $items = $order->items()->orderBy('variant_id')->orderBy('product_id')->get();
        if ($items->isEmpty()) {
            throw new RuntimeException('سفارش فاقد کالا است.');
        }

        foreach ($items as $item) {
            $this->decrementForItem($item);
        }

        $order->forceFill([
            'inventory_status' => self::RESERVED,
            'inventory_reserved_at' => now(),
            'inventory_released_at' => null,
        ])->save();
    }

    /**
     * A successful payment consumes the reservation. No second stock decrement occurs.
     */
    public function commit(Order $order): void
    {
        $locked = Order::query()->lockForUpdate()->findOrFail($order->id);

        if ($locked->inventory_status === self::COMMITTED) {
            return;
        }
        if ($locked->inventory_status !== self::RESERVED) {
            throw new RuntimeException('رزرو موجودی این سفارش معتبر نیست.');
        }

        $locked->forceFill([
            'inventory_status' => self::COMMITTED,
            'inventory_released_at' => null,
        ])->save();
    }

    /**
     * Return reserved stock after a failed/cancelled order. Idempotent by status.
     */
    public function release(Order $order): void
    {
        $lockedOrder = Order::query()->lockForUpdate()->findOrFail($order->id);

        if ($lockedOrder->inventory_status === self::RELEASED) {
            return;
        }
        if ($lockedOrder->inventory_status === self::COMMITTED) {
            throw new RuntimeException('موجودی سفارش پرداخت‌شده قابل آزادسازی نیست؛ ابتدا فرآیند مرجوعی/استرداد انجام شود.');
        }
        if ($lockedOrder->inventory_status !== self::RESERVED) {
            return;
        }

        $items = $lockedOrder->items()->orderBy('variant_id')->orderBy('product_id')->get();
        foreach ($items as $item) {
            $this->incrementForItem($item);
        }

        $lockedOrder->forceFill([
            'inventory_status' => self::RELEASED,
            'inventory_released_at' => now(),
        ])->save();
    }

    private function decrementForItem(OrderItem $item): void
    {
        $quantity = (int) $item->quantity;
        if ($quantity < 1) {
            throw new RuntimeException('تعداد یکی از اقلام سفارش معتبر نیست.');
        }

        $product = Product::query()->lockForUpdate()->find($item->product_id);
        if (!$product || !$product->status) {
            throw new RuntimeException('یکی از محصولات سفارش دیگر در دسترس نیست.');
        }

        if ($item->variant_id) {
            $variant = ProductVariant::query()
                ->whereKey($item->variant_id)
                ->where('product_id', $product->id)
                ->lockForUpdate()
                ->first();

            if (!$variant || !$variant->status) {
                throw new RuntimeException('یکی از تنوع‌های سفارش دیگر در دسترس نیست.');
            }
            if ((int) $variant->stock < $quantity) {
                throw new RuntimeException("موجودی «{$product->name}» برای انتخاب سفارش کافی نیست.");
            }

            $variant->decrement('stock', $quantity);
            // Product.stock is retained as a derived aggregate for backwards compatibility.
            $product->decrement('stock', $quantity);
            return;
        }

        if ($product->variants()->exists()) {
            throw new RuntimeException('این محصول دارای تنوع است و انتخاب سایز/رنگ الزامی است.');
        }
        if ((int) $product->stock < $quantity) {
            throw new RuntimeException("موجودی «{$product->name}» کافی نیست.");
        }

        $product->decrement('stock', $quantity);
    }

    private function incrementForItem(OrderItem $item): void
    {
        $quantity = (int) $item->quantity;
        if ($quantity < 1) {
            throw new RuntimeException('تعداد یکی از اقلام سفارش معتبر نیست.');
        }

        $product = Product::query()->lockForUpdate()->find($item->product_id);
        if (!$product) {
            // Product deletion should not make release silently fail; this is an exceptional data-integrity case.
            throw new RuntimeException('محصول مربوط به سفارش برای بازگرداندن موجودی پیدا نشد.');
        }

        if ($item->variant_id) {
            $variant = ProductVariant::query()
                ->whereKey($item->variant_id)
                ->where('product_id', $product->id)
                ->lockForUpdate()
                ->first();
            if (!$variant) {
                throw new RuntimeException('تنوع مربوط به سفارش برای بازگرداندن موجودی پیدا نشد.');
            }

            $variant->increment('stock', $quantity);
            $product->increment('stock', $quantity);
            return;
        }

        $product->increment('stock', $quantity);
    }
}
