<?php

namespace App\Services;

use App\Models\Cart;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Services\DiscountService;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class PricingService
{
    public const STANDARD_SHIPPING = 89000.00;
    public const EXPRESS_SHIPPING = 149000.00;
    public const FREE_SHIPPING_THRESHOLD = 4000000.00;

    /**
     * Calculate a cart price from authoritative database values.
     * Client supplied prices/totals are intentionally ignored.
     */
    public function calculateCart(Cart $cart, string $shippingMethod = 'standard', ?string $discountCode = null, bool $lock = false, ?User $user = null): array
    {
        $user = $user ?: $cart->user;
        $items = $cart->items()->with(['product', 'variant'])->get();

        if ($items->isEmpty()) {
            throw new RuntimeException('سبد خرید شما خالی است.');
        }

        $subtotal = 0.0;
        $lines = [];

        foreach ($items as $cartItem) {
            $productQuery = Product::query()->whereKey($cartItem->product_id);
            if ($lock) {
                $productQuery->lockForUpdate();
            }
            $product = $productQuery->first();

            if (!$product || !$product->status) {
                throw new RuntimeException('یکی از محصولات سبد دیگر در دسترس نیست.');
            }

            $hasVariants = $product->variants()->exists();
            if ($hasVariants && !$cartItem->variant_id) {
                throw new RuntimeException('برای یکی از محصولات سبد انتخاب سایز/رنگ الزامی است.');
            }

            $variant = null;
            if ($cartItem->variant_id) {
                $variantQuery = ProductVariant::query()
                    ->whereKey($cartItem->variant_id)
                    ->where('product_id', $product->id);
                if ($lock) {
                    $variantQuery->lockForUpdate();
                }
                $variant = $variantQuery->first();

                if (!$variant || !$variant->status) {
                    throw new RuntimeException('یکی از تنوع‌های انتخاب‌شده دیگر در دسترس نیست.');
                }
            }

            $quantity = (int) $cartItem->quantity;
            if ($quantity < 1) {
                throw new RuntimeException('تعداد یکی از اقلام سبد معتبر نیست.');
            }

            $stock = (int) ($variant?->stock ?? $product->stock);
            if ($quantity > $stock) {
                throw new RuntimeException("موجودی «{$product->name}» برای این انتخاب کافی نیست.");
            }

            $unitPrice = $variant?->price !== null
                ? (float) $variant->price
                : (float) ($product->discount_price !== null && (float) $product->discount_price < (float) $product->price
                    ? $product->discount_price
                    : $product->price);

            if ($unitPrice < 0) {
                throw new RuntimeException('قیمت یکی از محصولات معتبر نیست.');
            }

            $lineTotal = round($unitPrice * $quantity, 2);
            $subtotal = round($subtotal + $lineTotal, 2);

            $lines[] = [
                'cart_item_id' => $cartItem->id,
                'product_id' => $product->id,
                'variant_id' => $variant?->id,
                'quantity' => $quantity,
                'unit_price' => round($unitPrice, 2),
                'line_total' => $lineTotal,
            ];
        }

        // Coupon discounts are resolved exclusively from the database.
        $discount = 0.0;
        $normalizedCode = $discountCode ? strtoupper(trim($discountCode)) : null;
        $discountId = null;
        if ($normalizedCode !== null && $normalizedCode !== '') {
            if (!$user) throw new RuntimeException('کاربر برای اعمال کد تخفیف مشخص نیست.');
            $result = app(DiscountService::class)->findForCart($normalizedCode, $cart, $subtotal, $user, $lock, $lines);
            $discount = $result['amount'];
            $discountId = $result['discount']->id;
        }

        $shipping = match ($shippingMethod) {
            'express' => self::EXPRESS_SHIPPING,
            'standard' => ($subtotal - $discount) >= self::FREE_SHIPPING_THRESHOLD ? 0.0 : self::STANDARD_SHIPPING,
            default => throw new RuntimeException('روش ارسال نامعتبر است.'),
        };

        $finalTotal = round(max(0, $subtotal - $discount + $shipping), 2);

        return [
            'items' => $lines,
            'subtotal' => round($subtotal, 2),
            'discount' => round($discount, 2),
            'shipping' => round($shipping, 2),
            'total' => $finalTotal,
            'shipping_method' => $shippingMethod,
            'discount_code' => $normalizedCode,
            'discount_id' => $discountId,
            'currency' => 'IRR',
        ];
    }
}
