import InfoPages from '../views/InfoPages';
export default function Bestsellers(){ return <InfoPages kind="bestsellers"/>; }
