import Link from './SafeLink';

import Icon from './Icon';

function Footer() {
  return <footer className="site-footer" id="contact">
    <div className="container footer-top">
      <div className="footer-content-group">
        <div className="footer-about"><Link href="/" className="footer-logo" aria-label="کالکشن زمانی"><img src="/images/branding/logo-zamani.png" alt="کالکشن زمانی" /><span>کالکشن زمانی</span></Link><p>زمانی، انتخابی برای زنانی که سادگی، کیفیت و اصالت را بخشی از استایل خود می‌دانند.</p><div className="socials"><a href="https://www.instagram.com/clothing.zamanii?igsi=MTh5ZnB6MGZ1cXV4bQ==" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><Icon name="instagram" /></a><a href="#telegram" aria-label="Telegram"><Icon name="telegram" /></a></div></div>
        <div><h3>خدمات مشتریان</h3><Link href="/guide">راهنمای خرید</Link><Link href="/shipping">شرایط ارسال</Link><Link href="/terms">قوانین و مقررات</Link><Link href="/contact#faq">سوالات متداول</Link></div>
        <div><h3>با ما در ارتباط باشید</h3><p>شنبه تا پنجشنبه · ۹ تا ۲۱</p><p className="gold-text">۰۹۲۱۷۱۲۰۰۱۷</p><a className="gold-text footer-email" href="mailto:sjack0324@gmail.com">sjack0324@gmail.com</a><address className="footer-address">تهران، فیروزکوه، خیابان پاسداران، پاساژ نگین (شهرداری)، طبقه دوم، بوتیک زمانی.</address></div>
      </div>
      {/* جای خالی برای نماد/بج سمت چپ فوتر - تصویر نماد را اینجا اضافه کنید */}
      <div className="footer-badge-slot"></div>
    </div>
    <div className="footer-bottom"><div className="container"><span>© تمامی حقوق برای کالکشن زمانی محفوظ است.</span><span>طراحی شده با عشق برای استایل شما</span></div></div>
  </footer>;
}
export default Footer;
