import InfoPages from '../views/InfoPages';
export default function Latest(){ return <InfoPages kind="latest"/>; }
