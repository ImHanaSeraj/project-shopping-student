import Register from '../views/auth/Register';
import GuestRoute from '../guards/GuestRoute';
export default function RegisterPage(){ return <GuestRoute><Register/></GuestRoute>; }
