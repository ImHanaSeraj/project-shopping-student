import React, { Suspense, lazy } from 'react';
import { Routes, Route, useLocation } from "react-router-dom";
import MainLayout from "../layouts/MainLayout";
import ProtectedRoute from "./ProtectedRoute";
import GuestRoute from "./GuestRoute";
import AdminRoute from "./AdminRoute";
import SEOHead from '../components/SEOHead';
import NotFound from '../pages/NotFound';

const Home = lazy(() => import('../pages/Home'));
const Login = lazy(() => import('../pages/auth/Login'));
const Register = lazy(() => import('../pages/auth/Register'));
const ForgotPassword = lazy(() => import('../pages/auth/ForgotPassword'));
const ResetPassword = lazy(() => import('../pages/auth/ResetPassword'));
const Account = lazy(() => import('../pages/Account'));
const Products = lazy(() => import('../pages/Products'));
const ProductDetails = lazy(() => import('../pages/ProductDetails'));
const Contact = lazy(() => import('../pages/Contact'));
const Search = lazy(() => import('../pages/Search'));
const Cart = lazy(() => import('../pages/Cart'));
const Wishlist = lazy(() => import('../pages/Wishlist'));
const Compare = lazy(() => import('../pages/Compare'));
const Checkout = lazy(() => import('../pages/Checkout'));
const PaymentResult = lazy(() => import('../pages/PaymentResult'));
const MockPayment = lazy(() => import('../pages/MockPayment'));
const Orders = lazy(() => import('../pages/Orders'));
const OrderDetails = lazy(() => import('../pages/Orders').then(m => ({ default: m.OrderDetails })));
const InfoPages = lazy(() => import('../pages/InfoPages'));
const CategoryDetails = lazy(() => import('../pages/CategoryDetails'));
const Admin = lazy(() => import('../pages/admin/Admin'));
const AdminLogin = lazy(() => import('../pages/admin/AdminLogin'));

function RouteSEO() {
 const { pathname } = useLocation();
 const map = {
  '/': ['فروشگاه پوشاک زنانه', false], '/products': ['محصولات زنانه', false], '/categories': ['دسته‌بندی‌ها', false],
  '/latest': ['جدیدترین‌ها', false], '/bestsellers': ['پرفروش‌ترین‌ها', false], '/about': ['درباره زمانی', false], '/contact': ['تماس با ما', false],
  '/guide': ['راهنمای خرید', false], '/shipping': ['شرایط ارسال', false], '/terms': ['قوانین و مقررات', false],
  '/search': ['جستجوی محصولات', true], '/cart': ['سبد خرید', true], '/checkout': ['تسویه حساب', true], '/wishlist': ['علاقه‌مندی‌ها', true], '/compare': ['مقایسه محصولات', true],
  '/login': ['ورود', true], '/register': ['ثبت‌نام', true], '/forgot-password': ['بازیابی رمز عبور', true], '/reset-password': ['تنظیم رمز عبور', true], '/account': ['حساب کاربری', true],
  '/profile': ['پروفایل', true], '/orders': ['سفارش‌ها', true], '/admin': ['مدیریت فروشگاه', true], '/payment/result': ['نتیجه پرداخت', true], '/payment/mock': ['پرداخت آزمایشی', true]
 };
 const entry = map[pathname] || (pathname.startsWith('/account/') || pathname.startsWith('/orders/') || pathname.startsWith('/categories/') || pathname.startsWith('/products/') ? null : ['صفحه پیدا نشد', true]);
 return entry ? <SEOHead title={entry[0]} noindex={entry[1]} path={pathname} /> : null;
}

function RouteFallback() { return <div className="route-loading" role="status" aria-live="polite"><span className="loading-spinner"/>در حال بارگذاری…</div>; }
function Info({ kind }) { return <Suspense fallback={<RouteFallback />}><InfoPages kind={kind} /></Suspense>; }

export default function AppRouter(){
 return <Suspense fallback={<RouteFallback />}><RouteSEO/><Routes>
  <Route element={<MainLayout />}>
   <Route path="/" element={<Home/>}/>
   <Route path="/admin/login" element={<AdminLogin/>}/>
   <Route path="/admin" element={<AdminRoute><Admin/></AdminRoute>}/>
   <Route path="/products" element={<Products/>}/>
   <Route path="/categories" element={<Info kind="categories"/>}/>
   <Route path="/categories/:slug" element={<CategoryDetails/>}/>
   <Route path="/latest" element={<Info kind="latest"/>}/>
   <Route path="/bestsellers" element={<Info kind="bestsellers"/>}/>
   <Route path="/about" element={<Info kind="about"/>}/>
   <Route path="/guide" element={<Info kind="guide"/>}/>
   <Route path="/shipping" element={<Info kind="shipping"/>}/>
   <Route path="/terms" element={<Info kind="terms"/>}/>
   <Route path="/search" element={<Search/>}/>
   <Route path="/cart" element={<Cart/>}/>
   <Route path="/checkout" element={<ProtectedRoute><Checkout/></ProtectedRoute>}/>
   <Route path="/payment/result" element={<PaymentResult/>}/>
   <Route path="/payment/mock" element={<MockPayment/>}/>
   <Route path="/wishlist" element={<ProtectedRoute><Wishlist/></ProtectedRoute>}/>
   <Route path="/compare" element={<Compare/>}/>
   <Route path="/products/:slugOrId" element={<ProductDetails/>}/>
   <Route path="/contact" element={<Contact/>}/>
   <Route path="/login" element={<GuestRoute><Login/></GuestRoute>}/>
   <Route path="/register" element={<GuestRoute><Register/></GuestRoute>}/>
   <Route path="/forgot-password" element={<GuestRoute><ForgotPassword/></GuestRoute>}/>
   <Route path="/reset-password" element={<GuestRoute><ResetPassword/></GuestRoute>}/>
   <Route path="/profile" element={<ProtectedRoute><Account/></ProtectedRoute>}/>
   <Route path="/account" element={<ProtectedRoute><Account/></ProtectedRoute>}/>
   <Route path="/account/profile" element={<ProtectedRoute><Account/></ProtectedRoute>}/>
   <Route path="/account/orders" element={<ProtectedRoute><Orders/></ProtectedRoute>}/>
   <Route path="/account/addresses" element={<ProtectedRoute><Account/></ProtectedRoute>}/>
   <Route path="/account/wishlist" element={<ProtectedRoute><Account/></ProtectedRoute>}/>
   <Route path="/account/password" element={<ProtectedRoute><Account/></ProtectedRoute>}/>
   <Route path="/orders" element={<ProtectedRoute><Orders/></ProtectedRoute>}/>
   <Route path="/orders/:id" element={<ProtectedRoute><OrderDetails/></ProtectedRoute>}/>
   <Route path="*" element={<NotFound/>}/>
  </Route>
 </Routes></Suspense>
}
