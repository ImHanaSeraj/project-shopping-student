<?php

use Illuminate\Support\Facades\Broadcast;

// Only admins/managers may listen to the shared support queue. This is the
// only private channel the feature uses; the per-conversation channel
// ("chat.{session_id}") is public on purpose so guest customers - who have
// no Sanctum token - can also receive live replies.
Broadcast::channel('admin.chat', function ($user) {
    return $user && in_array($user->role, ['admin', 'manager'], true) ? $user : null;
});
