import {useState} from 'react';
import Link from '../../components/SafeLink';

import api from '../../services/api';
export default function ForgotPassword(){
 const [email,setEmail]=useState(''); const [msg,setMsg]=useState(''); const [error,setError]=useState(''); const [loading,setLoading]=useState(false);
 const submit=async(e)=>{e.preventDefault();setError('');setMsg('');setLoading(true);try{const r=await api.post('/auth/forgot-password',{email});setMsg(r.data?.message||'اگر ایمیل ثبت شده باشد، لینک بازیابی ارسال می‌شود.')}catch(err){const errors=Object.values(err.response?.data?.errors||{}).flat();setError(errors[0]||err.response?.data?.message||'درخواست بازیابی انجام نشد.')}finally{setLoading(false)}};
 return <div className="auth"><form onSubmit={submit} noValidate><h1>ZAMANI</h1><p className="auth-subtitle">بازیابی رمز عبور</p>{error&&<div className="auth-error" role="alert">{error}</div>}{msg&&<div className="auth-success" role="status">{msg}</div>}<input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="ایمیل حساب کاربری" autoComplete="email" required/><button type="submit" disabled={loading}>{loading?'در حال ارسال...':'ارسال لینک بازیابی'}</button><div className="auth-links"><Link href="/login">بازگشت به ورود</Link><Link href="/">بازگشت به فروشگاه</Link></div></form></div>
}
