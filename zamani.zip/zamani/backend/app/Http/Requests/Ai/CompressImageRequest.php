<?php

namespace App\Http\Requests\Ai;

use Illuminate\Foundation\Http\FormRequest;

class CompressImageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->isManager() ?? false;
    }

    public function rules(): array
    {
        return [
            'image' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:10240'],
            
            
            'quality' => ['nullable', 'integer', 'min:1', 'max:100'],
        ];
    }

    public function messages(): array
    {
        return [
            'image.required' => 'انتخاب تصویر الزامی است.',
            'image.image' => 'فایل انتخاب‌شده باید یک تصویر باشد.',
            'image.mimes' => 'فرمت تصویر باید jpg، jpeg، png یا webp باشد.',
            'image.max' => 'حجم تصویر نباید بیشتر از ۱۰ مگابایت باشد.',
            'quality.integer' => 'کیفیت باید عدد صحیح باشد.',
            'quality.min' => 'کیفیت باید حداقل ۱ باشد.',
            'quality.max' => 'کیفیت نباید بیشتر از ۱۰۰ باشد.',
        ];
    }
}
