<?php

namespace App\Http\Controllers\Api\Admin;

use App\Events\ChatConversationUpdated;
use App\Events\ChatMessageCreated;
use App\Http\Controllers\Controller;
use App\Models\ChatConversation;
use Illuminate\Http\Request;

class SupportChatAdminController extends Controller
{
    // Inbox list: chats waiting for any operator, chats this admin is already
    // handling, and (optionally) recently closed ones for reference.
    public function index(Request $request)
    {
        $admin = $request->user();

        $pending = ChatConversation::with('user:id,name')
            ->where('status', 'pending')
            ->orderBy('escalated_at')
            ->get();

        $mine = ChatConversation::with('user:id,name')
            ->where('status', 'active')
            ->where('assigned_admin_id', $admin->id)
            ->orderByDesc('escalated_at')
            ->get();

        $closed = ChatConversation::with('user:id,name')
            ->where('status', 'closed')
            ->orderByDesc('closed_at')
            ->limit(20)
            ->get();

        $map = fn ($c) => [
            'id' => $c->id,
            'session_id' => $c->session_id,
            'status' => $c->status,
            'customer_name' => $c->customerLabel(),
            'escalated_at' => $c->escalated_at?->toIso8601String(),
            'last_message' => $c->messages()->latest()->value('content'),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'pending' => $pending->map($map)->values(),
                'mine' => $mine->map($map)->values(),
                'closed' => $closed->map($map)->values(),
            ],
        ]);
    }

    public function show(ChatConversation $conversation)
    {
        return response()->json([
            'success' => true,
            'data' => [
                'id' => $conversation->id,
                'session_id' => $conversation->session_id,
                'status' => $conversation->status,
                'customer_name' => $conversation->customerLabel(),
                'assigned_admin' => $conversation->assignedAdmin->name ?? null,
                'messages' => $conversation->messages()->orderBy('id')->get(['id', 'role', 'content', 'created_at']),
            ],
        ]);
    }

    // An operator picks up a waiting chat. Only one admin can claim a given
    // conversation - a race is resolved by whichever update() commits first.
    public function claim(Request $request, ChatConversation $conversation)
    {
        if ($conversation->status !== 'pending') {
            return response()->json(['success' => false, 'message' => 'این گفتگو دیگر در انتظار پاسخ نیست.'], 409);
        }

        $conversation->update([
            'status' => 'active',
            'assigned_admin_id' => $request->user()->id,
        ]);

        $joinMessage = $conversation->messages()->create([
            'role' => 'system',
            'content' => ($request->user()->name ?? 'یک اپراتور') . ' به گفتگو پیوست.',
        ]);
        broadcast(new ChatMessageCreated($joinMessage->load('conversation')));
        broadcast(new ChatConversationUpdated($conversation->fresh()));

        return response()->json(['success' => true, 'data' => ['id' => $conversation->id, 'status' => $conversation->status]]);
    }

    public function reply(Request $request, ChatConversation $conversation)
    {
        $data = $request->validate(['message' => ['required', 'string', 'min:1', 'max:2000']]);

        if ($conversation->assigned_admin_id !== $request->user()->id) {
            return response()->json(['success' => false, 'message' => 'این گفتگو به شما اختصاص داده نشده است.'], 403);
        }

        $message = $conversation->messages()->create([
            'role' => 'admin',
            'content' => $data['message'],
            'sender_id' => $request->user()->id,
        ]);

        broadcast(new ChatMessageCreated($message->load('conversation', 'sender')));

        return response()->json(['success' => true, 'data' => ['id' => $message->id]]);
    }

    public function close(Request $request, ChatConversation $conversation)
    {
        $conversation->update(['status' => 'closed', 'closed_at' => now()]);

        $closeMessage = $conversation->messages()->create([
            'role' => 'system',
            'content' => 'این گفتگو توسط پشتیبانی بسته شد.',
        ]);
        broadcast(new ChatMessageCreated($closeMessage->load('conversation')));
        broadcast(new ChatConversationUpdated($conversation->fresh()));

        return response()->json(['success' => true]);
    }
}
