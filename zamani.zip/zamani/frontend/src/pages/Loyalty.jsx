import { useEffect, useState } from 'react';
import Link from 'next/link';
import Icon from '../components/Icon';
import ProtectedRoute from '../guards/ProtectedRoute';
import { getLoyalty } from '../services/loyalty';
import useDocumentTitle from '../hooks/useDocumentTitle';

const fa = n => new Intl.NumberFormat('fa-IR').format(Number(n || 0));
const money = n => `${fa(n)} تومان`;

function LoyaltyContent() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  useDocumentTitle('باشگاه مشتریان | زمانی');

  useEffect(() => {
    let alive = true;
    getLoyalty().then(r => { if (alive) setData(r.data); })
      .catch(e => { if (alive) setError(e.response?.data?.message || 'دریافت اطلاعات باشگاه مشتریان انجام نشد.'); });
    return () => { alive = false; };
  }, []);

  if (error) return <main className="loyalty-page container"><div className="loyalty-state">{error}</div></main>;
  if (!data) return <main className="loyalty-page container"><div className="loyalty-state">در حال دریافت اطلاعات باشگاه مشتریان...</div></main>;

  return <main className="loyalty-page container" dir="rtl">
    <div className="loyalty-breadcrumb"><Link to="/account">حساب کاربری</Link><Icon name="arrow" size={11}/><strong>باشگاه مشتریان</strong></div>
    <header className="loyalty-hero">
      <div>
        <span className="eyebrow">ZAMANI LOYALTY CLUB</span>
        <h1>باشگاه مشتریان</h1>
        <p>با خرید از زمانی امتیاز بگیرید و در خریدهای بعدی بخشی از مبلغ سفارش را با امتیاز پرداخت کنید.</p>
      </div>
      <div className="loyalty-balance">
        <span>امتیاز قابل استفاده</span>
        <strong>{fa(data.available_points)}</strong>
        <small>امتیاز</small>
      </div>
    </header>

    <section className="loyalty-rules">
      <article><span className="loyalty-rule-icon">+</span><div><strong>کسب امتیاز</strong><p>{data.next_purchase_rule}</p></div></article>
      <article><span className="loyalty-rule-icon">٪</span><div><strong>ارزش امتیاز</strong><p>{data.redemption_rule}</p></div></article>
      <article><span className="loyalty-rule-icon">Z</span><div><strong>موجودی فعلی</strong><p>{fa(data.balance)} امتیاز در حساب شما ثبت شده است.</p></div></article>
    </section>

    <section className="loyalty-history">
      <div className="loyalty-section-head"><div><span className="eyebrow">POINT HISTORY</span><h2>گردش امتیازها</h2></div><Link className="btn btn-outline" to="/products">خرید و کسب امتیاز</Link></div>
      {data.transactions?.length ? <div className="loyalty-table">
        {data.transactions.map(t => <div className="loyalty-row" key={t.id}>
          <div className={`loyalty-type ${t.points > 0 ? 'positive' : 'negative'}`}><Icon name={t.points > 0 ? 'plus' : 'minus'} size={13}/></div>
          <div><strong>{t.description}</strong><small>{new Date(t.created_at).toLocaleDateString('fa-IR')}</small></div>
          <b className={t.points > 0 ? 'positive' : 'negative'}>{t.points > 0 ? '+' : ''}{fa(t.points)} امتیاز</b>
          <span>{fa(t.balance_after)} موجودی</span>
        </div>)}
      </div> : <div className="loyalty-empty"><Icon name="star" size={28}/><h3>هنوز تراکنش امتیازی ندارید</h3><p>اولین خریدتان می‌تواند شروع باشگاه مشتریان شما باشد.</p><Link className="btn btn-primary" to="/products">مشاهده محصولات</Link></div>}
    </section>
  </main>;
}

export default function Loyalty() {
  return <ProtectedRoute><LoyaltyContent /></ProtectedRoute>;
}
