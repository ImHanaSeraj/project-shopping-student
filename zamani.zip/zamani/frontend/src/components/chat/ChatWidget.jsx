import { useEffect, useRef, useState } from 'react';
import Icon from '../Icon';
import { chatApi, getEcho } from '../../services/chat';
import { useAuth } from '../../context/AuthContext';

const SESSION_KEY = 'zamani_chat_session';

function getSessionId() {
  if (typeof window === 'undefined') return null;
  let id = localStorage.getItem(SESSION_KEY);
  if (!id) {
    id = (crypto?.randomUUID) ? crypto.randomUUID() : `guest-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    localStorage.setItem(SESSION_KEY, id);
  }
  return id;
}

const statusCopy = {
  bot: null,
  pending: 'در انتظار پاسخ اپراتور… معمولاً چند دقیقه طول می‌کشد.',
  active: 'یک اپراتور در حال پاسخگویی است.',
  closed: 'این گفتگو بسته شده است.',
};

export default function ChatWidget() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const [messages, setMessages] = useState([]);
  const [status, setStatus] = useState('bot');
  const [conversationId, setConversationId] = useState(null);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const sessionIdRef = useRef(null);
  const listRef = useRef(null);
  const channelRef = useRef(null);

  useEffect(() => {
    sessionIdRef.current = getSessionId();
    const timer = setTimeout(() => setShowWelcome(true), 900);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [messages, open]);

  // Subscribe to this conversation's live channel once we know its session_id.
  useEffect(() => {
    if (!open || !sessionIdRef.current) return;
    const echo = getEcho();
    if (!echo) return; // no Pusher key configured - widget still works, just without push updates
    const channel = echo.channel('chat.' + sessionIdRef.current);
    channelRef.current = channel;
    channel.listen('.message.created', (e) => {
      setMessages((prev) => (prev.some((m) => m.id === e.id) ? prev : [...prev, e]));
    });
    channel.listen('.conversation.updated', (e) => {
      setStatus(e.status);
    });
    return () => { echo.leave('chat.' + sessionIdRef.current); channelRef.current = null; };
  }, [open]);

  const pushLocal = (role, content) => {
    setMessages((prev) => [...prev, { id: `local-${Date.now()}`, role, content, created_at: new Date().toISOString() }]);
  };

  const send = async (e) => {
    e?.preventDefault();
    const text = input.trim();
    if (!text || sending) return;
    setInput('');
    pushLocal('user', text);
    setSending(true);
    try {
      const history = messages
        .filter((m) => m.role === 'user' || m.role === 'assistant')
        .slice(-10)
        .map((m) => ({ role: m.role, content: m.content }));
      const { data } = await chatApi.gemini({ message: text, history });
      if (data?.reply) setMessages((prev) => [...prev, { id: `bot-${Date.now()}`, role: 'assistant', content: data.reply }]);
    } catch {
      pushLocal('system', 'ارسال پیام با خطا مواجه شد. دوباره تلاش کنید.');
    } finally {
      setSending(false);
    }
  };

  const escalate = async () => {
    if (!conversationId || status !== 'bot') return;
    pushLocal('system', 'در حال اتصال به پشتیبان انسانی…');
    try {
      const { data } = await chatApi.escalate(conversationId);
      setStatus(data.status);
    } catch {
      pushLocal('system', 'اتصال به پشتیبان انسانی ممکن نشد.');
    }
  };

  const toggle = () => { setOpen((v) => !v); setShowWelcome(false); };
  const startChat = () => { setShowWelcome(false); setOpen(true); };

  return (
    <div className="chat-widget" dir="rtl">
      {showWelcome && !open && (
        <div className="chat-widget-welcome" role="status">
          <button type="button" className="chat-widget-welcome-close" onClick={() => setShowWelcome(false)} aria-label="بستن پیام">×</button>
          <div className="chat-widget-welcome-icon"><Icon name="support" /></div>
          <div className="chat-widget-welcome-copy">
            <strong>کمکی لازم داری؟ ✨</strong>
            <span>برای انتخاب محصول، مقایسه یا هر سوالی می‌تونی از دستیار زمانی کمک بگیری.</span>
            <button type="button" onClick={startChat}>شروع گفتگو</button>
          </div>
        </div>
      )}
      {open && (
        <div className="chat-widget-panel">
          <div className="chat-widget-head">
            <div>
              <strong>پشتیبانی زمانی</strong>
              <small>{statusCopy[status] || 'دستیار هوشمند فروشگاه'}</small>
            </div>
            <button type="button" onClick={toggle} aria-label="بستن"><Icon name="x" /></button>
          </div>
          <div className="chat-widget-body" ref={listRef}>
            {messages.length === 0 && (
              <div className="chat-widget-empty">سلام{user?.name ? ` ${user.name}` : ''}! چطور می‌توانم کمکتان کنم؟</div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={`chat-bubble chat-bubble-${m.role}`}>
                {m.content}
              </div>
            ))}
            {sending && <div className="chat-bubble chat-bubble-assistant chat-bubble-typing">در حال تایپ…</div>}
          </div>
          {status === 'bot' && conversationId && (
            <button type="button" className="chat-widget-escalate" onClick={escalate}>
              <Icon name="user" /> صحبت با پشتیبان انسانی
            </button>
          )}
          {status !== 'closed' ? (
            <form className="chat-widget-form" onSubmit={send}>
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="پیام خود را بنویسید…"
                maxLength={2000}
              />
              <button type="submit" disabled={!input.trim() || sending} aria-label="ارسال"><Icon name="arrow" /></button>
            </form>
          ) : (
            <div className="chat-widget-closed">این گفتگو بسته شده است. برای سوال جدید دوباره پیام بدهید.</div>
          )}
        </div>
      )}
      <button type="button" className="chat-widget-fab" onClick={toggle} aria-label="گفتگو با پشتیبانی">
        <Icon name={open ? 'x' : 'support'} />
        {!open && status === 'active' && <span className="chat-widget-dot" />}
      </button>
    </div>
  );
}
