<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class CartController extends Controller
{
    private function cart(Request $request): Cart
    {
        return Cart::firstOrCreate(['user_id' => $request->user()->id]);
    }

    private function itemPayload(CartItem $item): array
    {
        $product = $item->product;
        $variant = $item->variant;
        $price = $variant?->price !== null ? (float) $variant->price : (float) ($product->discount_price ?: $product->price);

        return [
            'id' => $item->id,
            'productId' => $product->id,
            'variantId' => $variant?->id,
            'name' => $product->name,
            'slug' => $product->slug,
            'SKU' => $variant?->SKU ?: $product->SKU,
            'quantity' => (int) $item->quantity,
            'price' => $price,
            'stock' => (int) ($variant?->stock ?? $product->stock),
            'selections' => array_filter([
                'color' => $variant?->color,
                'size' => $variant?->size,
            ]),
            'image' => $variant?->image ?: ($product->images->first()->image ?? $product->image ?? ''),
        ];
    }

    public function index(Request $request)
    {
        $cart = $this->cart($request)->load('items.product.images', 'items.variant');
        return response()->json([
            'items' => $cart->items->map(fn ($item) => $this->itemPayload($item))->values(),
            'count' => (int) $cart->items->sum('quantity'),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'variant_id' => ['nullable', 'integer', 'exists:product_variants,id'],
            'quantity' => ['required', 'integer', 'min:1', 'max:99'],
        ]);

        return DB::transaction(function () use ($request, $data) {
            $product = Product::query()->whereKey($data['product_id'])->lockForUpdate()->firstOrFail();
            if (!$product->status) {
                return response()->json(['message' => 'این محصول در دسترس نیست.'], 422);
            }

            $hasVariants = $product->variants()->exists();
            if ($hasVariants && empty($data['variant_id'])) {
                return response()->json(['message' => 'برای این محصول انتخاب سایز/رنگ الزامی است.'], 422);
            }

            $variant = null;
            if (!empty($data['variant_id'])) {
                $variant = ProductVariant::query()
                    ->whereKey($data['variant_id'])
                    ->where('product_id', $product->id)
                    ->lockForUpdate()
                    ->first();

                if (!$variant || !$variant->status) {
                    return response()->json(['message' => 'این تنوع محصول در دسترس نیست.'], 422);
                }
                $stock = (int) $variant->stock;
            } else {
                $stock = (int) $product->stock;
            }

            $cart = $this->cart($request);
            $query = $cart->items()->where('product_id', $product->id);
            $query = empty($data['variant_id']) ? $query->whereNull('variant_id') : $query->where('variant_id', $data['variant_id']);
            $item = $query->first();

            $newQuantity = ($item ? (int) $item->quantity : 0) + (int) $data['quantity'];
            if ($stock < $newQuantity) {
                return response()->json(['message' => "موجودی «{$product->name}» برای این انتخاب کافی نیست.", 'stock' => $stock], 422);
            }

            $price = $variant?->price !== null ? $variant->price : ($product->discount_price ?: $product->price);
            if ($item) {
                $item->update(['quantity' => $newQuantity, 'price' => $price]);
            } else {
                $item = $cart->items()->create([
                    'product_id' => $product->id,
                    'variant_id' => $variant?->id,
                    'quantity' => $newQuantity,
                    'price' => $price,
                ]);
            }

            return response()->json(['message' => 'محصول به سبد خرید اضافه شد.', 'item' => $this->itemPayload($item->load('product.images', 'variant'))], 201);
        });
    }

    public function update(Request $request, CartItem $cartItem)
    {
        $data = $request->validate(['quantity' => ['required', 'integer', 'min:1', 'max:99']]);
        $cart = $this->cart($request);

        if ((int) $cartItem->cart_id !== (int) $cart->id) {
            abort(404);
        }

        return DB::transaction(function () use ($cartItem, $data) {
            $cartItem = CartItem::with('product.images', 'variant')->lockForUpdate()->findOrFail($cartItem->id);
            $product = Product::query()->whereKey($cartItem->product_id)->lockForUpdate()->first();
            $variant = $cartItem->variant_id ? ProductVariant::query()->whereKey($cartItem->variant_id)->lockForUpdate()->first() : null;
            if (!$product || !$product->status || ($cartItem->variant_id && (!$variant || !$variant->status))) {
                return response()->json(['message' => 'این محصول دیگر در دسترس نیست.'], 422);
            }
            $stock = (int) ($variant?->stock ?? $product->stock);
            if ((int) $data['quantity'] > $stock) {
                return response()->json(['message' => 'تعداد انتخاب‌شده بیشتر از موجودی است.', 'stock' => $stock], 422);
            }
            $price = $variant?->price !== null ? $variant->price : ($product->discount_price ?: $product->price);
            $cartItem->update(['quantity' => $data['quantity'], 'price' => $price]);
            return response()->json(['message' => 'سبد خرید به‌روزرسانی شد.', 'item' => $this->itemPayload($cartItem->fresh()->load('product.images', 'variant'))]);
        });
    }

    public function destroy(Request $request, CartItem $cartItem)
    {
        $cart = $this->cart($request);
        if ((int) $cartItem->cart_id !== (int) $cart->id) abort(404);
        $cartItem->delete();
        return response()->json(['message' => 'محصول از سبد خرید حذف شد.']);
    }

    public function clear(Request $request)
    {
        $this->cart($request)->items()->delete();
        return response()->json(['message' => 'سبد خرید خالی شد.']);
    }
}
