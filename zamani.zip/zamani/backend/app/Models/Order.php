<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 'customer_name', 'customer_email', 'customer_phone', 'address_id', 'receiver_name', 'receiver_phone', 'shipping_province', 'shipping_city', 'shipping_address', 'shipping_postal_code', 'shipping_method', 'order_number', 'total', 'discount', 'discount_code', 'shipping_cost',
        'final_total', 'status', 'payment_status', 'inventory_status', 'inventory_reserved_at', 'inventory_released_at', 'delivered_at', 'return_requested_at',
    ];

    protected $casts = [
        'total' => 'decimal:2',
        'discount' => 'decimal:2',
        'shipping_cost' => 'decimal:2',
        'final_total' => 'decimal:2',
        'inventory_reserved_at' => 'datetime',
        'inventory_released_at' => 'datetime',
        'delivered_at' => 'datetime',
        'return_requested_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function address(): BelongsTo
    {
        return $this->belongsTo(Address::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function payment(): HasOne
    {
        return $this->hasOne(Payment::class)->latestOfMany();
    }
}
