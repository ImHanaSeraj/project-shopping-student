<?php
namespace App\Http\Controllers\Api\Admin;
use App\Models\Review; use Illuminate\Http\Request;
class ReviewAdminController extends AdminBaseController {
 public function index(Request $r){$this->guardAdmin($r); $q=Review::with(['user:id,name','product:id,name'])->latest(); if($r->filled('status'))$q->where('status',$r->status); if($r->filled('search')){$s=$r->search;$q->where(fn($x)=>$x->where('comment','like','%'.$s.'%')->orWhereHas('user',fn($u)=>$u->where('name','like','%'.$s.'%'))->orWhereHas('product',fn($p)=>$p->where('name','like','%'.$s.'%')));} return $q->paginate(20);}
 public function updateStatus(Request $r,$id){$this->guardAdmin($r); $d=$r->validate(['status'=>'required|in:pending,approved,rejected']); $v=Review::findOrFail($id); $v->update($d); return $v->load(['user:id,name','product:id,name']);}
 public function destroy(Request $r,$id){$this->guardAdmin($r); Review::findOrFail($id)->delete(); return ['message'=>'نظر حذف شد.'];}
}
