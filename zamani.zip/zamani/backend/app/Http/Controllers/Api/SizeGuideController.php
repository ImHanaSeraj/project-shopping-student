<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

class SizeGuideController extends Controller
{
    // Same S-XXL ladder as the static bust/waist/hip table shown on every
    // product page, extended with XS/XXL so the calculator covers a wider
    // range of heights/weights than the printed chart alone.
    private const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

    // Upper bound of each band, keyed to a BMI-style index (weight_kg / height_m^2).
    // This is a heuristic used only to turn two numbers (height/weight) into a
    // starting-point suggestion for ready-to-wear women's clothing - not a
    // medical BMI classification. The measurement-based table stays the
    // authoritative method; this just gives a fast first guess.
    private const BANDS = [
        'XS' => 18.5,
        'S' => 21.0,
        'M' => 24.0,
        'L' => 27.0,
        'XL' => 30.0,
        'XXL' => INF,
    ];

    public function recommend(Request $request)
    {
        $data = $request->validate([
            'height_cm' => ['required', 'numeric', 'min:130', 'max:210'],
            'weight_kg' => ['required', 'numeric', 'min:35', 'max:160'],
        ], [
            'height_cm.required' => 'وارد کردن قد الزامی است.',
            'height_cm.min' => 'قد باید بین ۱۳۰ تا ۲۱۰ سانتی‌متر باشد.',
            'height_cm.max' => 'قد باید بین ۱۳۰ تا ۲۱۰ سانتی‌متر باشد.',
            'weight_kg.required' => 'وارد کردن وزن الزامی است.',
            'weight_kg.min' => 'وزن باید بین ۳۵ تا ۱۶۰ کیلوگرم باشد.',
            'weight_kg.max' => 'وزن باید بین ۳۵ تا ۱۶۰ کیلوگرم باشد.',
        ]);

        $heightM = $data['height_cm'] / 100;
        $bmi = round($data['weight_kg'] / ($heightM * $heightM), 1);

        $index = 0;
        $lowerBound = 0;
        foreach (self::BANDS as $size => $max) {
            if ($bmi <= $max) {
                $size0 = $size;
                break;
            }
            $lowerBound = $max;
            $index++;
        }
        $size0 = $size0 ?? 'XXL';
        $index = array_search($size0, self::SIZES, true);

        // How close is this BMI to the boundary it just crossed? Close to a
        // boundary means the neighbouring size is a real possibility too.
        $upperBound = self::BANDS[$size0];
        $bandWidth = is_infinite($upperBound) ? 4.0 : max(0.1, $upperBound - $lowerBound);
        $distanceToEdge = min($bmi - $lowerBound, is_infinite($upperBound) ? $bandWidth : $upperBound - $bmi);
        $nearEdge = $distanceToEdge < ($bandWidth * 0.22);

        $alternative = null;
        if ($nearEdge) {
            $closerToLower = ($bmi - $lowerBound) < ($distanceToEdge + 0.001) && $index > 0;
            $alternativeIndex = $closerToLower ? $index - 1 : $index + 1;
            if ($alternativeIndex >= 0 && $alternativeIndex < count(self::SIZES)) {
                $alternative = self::SIZES[$alternativeIndex];
            }
        }

        return response()->json([
            'success' => true,
            'data' => [
                'size' => $size0,
                'alternative_size' => $alternative,
                'confidence' => $nearEdge ? 'medium' : 'high',
                'bmi' => $bmi,
            ],
        ]);
    }
}
