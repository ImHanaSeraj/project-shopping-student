<?php

namespace App\Events;

use App\Models\ChatConversation;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Queue\SerializesModels;

// Broadcasts a conversation's status/assignment to two audiences at once:
// - the admin support queue (private "admin.chat" channel), so every admin's
//   inbox updates live when a chat is escalated, claimed, or closed;
// - the customer's own widget (public "chat.{session_id}" channel), so they
//   see "منتظر پاسخ اپراتور..." / "یک اپراتور به گفتگو پیوست" without polling.
class ChatConversationUpdated implements ShouldBroadcastNow
{
    use InteractsWithSockets, SerializesModels;

    public function __construct(public ChatConversation $conversation)
    {
    }

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel('admin.chat'),
            new Channel('chat.' . $this->conversation->session_id),
        ];
    }

    public function broadcastAs(): string
    {
        return 'conversation.updated';
    }

    public function broadcastWith(): array
    {
        $c = $this->conversation;

        return [
            'id' => $c->id,
            'status' => $c->status,
            'customer_name' => $c->customerLabel(),
            'assigned_admin' => $c->assignedAdmin->name ?? null,
            'escalated_at' => $c->escalated_at?->toIso8601String(),
            'last_message' => $c->messages()->latest()->value('content'),
        ];
    }
}
