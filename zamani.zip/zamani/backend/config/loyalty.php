<?php

return [
    // Amounts are in the same unit as product/order prices in ZAMANI (تومان).
    'point_value' => (int) env('LOYALTY_POINT_VALUE', 1000),
    'earn_threshold' => (int) env('LOYALTY_EARN_THRESHOLD', 10000),
    'hold_hours' => (int) env('LOYALTY_HOLD_HOURS', 24),
];
