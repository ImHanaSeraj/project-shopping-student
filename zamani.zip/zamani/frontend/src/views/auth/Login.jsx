import React, { useEffect, useRef, useState } from 'react';
import Link from '../../components/SafeLink';
import {useNavigate} from '../../utils/routerCompat';
import api from '../../services/api';
import { requestLoginOtp, verifyLoginOtp } from '../../services/otp';
import { useAuth } from '../../context/AuthContext';

const RESEND_SECONDS = 60;

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [mode, setMode] = useState('password'); // 'password' | 'otp'

  // Password login
  const [form, setForm] = useState({ login: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // OTP login
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [otpStep, setOtpStep] = useState('phone'); // 'phone' | 'code'
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpError, setOtpError] = useState('');
  const [otpInfo, setOtpInfo] = useState('');
  const [cooldown, setCooldown] = useState(0);
  const timerRef = useRef(null);

  useEffect(() => () => clearInterval(timerRef.current), []);

  const startCooldown = () => {
    setCooldown(RESEND_SECONDS);
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setCooldown((prev) => {
        if (prev <= 1) { clearInterval(timerRef.current); return 0; }
        return prev - 1;
      });
    }, 1000);
  };

  const switchMode = (next) => {
    setMode(next);
    setError('');
    setOtpError('');
    setOtpInfo('');
  };

  const change = (e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await api.post('/auth/login', form);
      login(response.data.user, response.data.token);
      navigate('/profile', { replace: true });
    } catch (err) {
      if (!err.response) {
        setError('ارتباط با سرویس فروشگاه برقرار نشد. لطفاً دوباره تلاش کنید.');
      } else if (err.response.status === 401) {
        setError('ایمیل/شماره موبایل یا رمز عبور اشتباه است.');
      } else if (err.response.status === 422) {
        setError('اطلاعات ورود را کامل و صحیح وارد کنید.');
      } else {
        setError(err.response.data?.message || `خطایی در ورود رخ داد. (کد ${err.response.status})`);
      }
    } finally {
      setLoading(false);
    }
  };

  const sendOtp = async (e) => {
    e.preventDefault();
    setOtpError('');
    setOtpInfo('');
    if (!phone.trim()) { setOtpError('شماره موبایل را وارد کنید.'); return; }
    setOtpLoading(true);
    try {
      const { data } = await requestLoginOtp(phone.trim());
      setOtpInfo(data?.message || 'کد تایید ارسال شد.');
      setOtpStep('code');
      startCooldown();
    } catch (err) {
      if (err.response?.status === 429) setOtpError(err.response.data?.message || 'کمی صبر کنید و دوباره تلاش کنید.');
      else if (!err.response) setOtpError('ارتباط با سرویس فروشگاه برقرار نشد.');
      else setOtpError(err.response.data?.message || 'ارسال کد تایید انجام نشد.');
    } finally {
      setOtpLoading(false);
    }
  };

  const resendOtp = async () => {
    if (cooldown > 0 || otpLoading) return;
    setOtpError('');
    setOtpLoading(true);
    try {
      const { data } = await requestLoginOtp(phone.trim());
      setOtpInfo(data?.message || 'کد تایید دوباره ارسال شد.');
      startCooldown();
    } catch (err) {
      setOtpError(err.response?.data?.message || 'ارسال دوباره کد انجام نشد.');
    } finally {
      setOtpLoading(false);
    }
  };

  const verifyOtp = async (e) => {
    e.preventDefault();
    setOtpError('');
    if (!code.trim()) { setOtpError('کد تایید را وارد کنید.'); return; }
    setOtpLoading(true);
    try {
      const { data } = await verifyLoginOtp(phone.trim(), code.trim());
      login(data.user, data.token);
      navigate('/profile', { replace: true });
    } catch (err) {
      if (!err.response) setOtpError('ارتباط با سرویس فروشگاه برقرار نشد.');
      else setOtpError(err.response.data?.message || 'کد وارد شده نامعتبر یا منقضی شده است.');
    } finally {
      setOtpLoading(false);
    }
  };

  return (
    <div className="auth">
      <form onSubmit={mode === 'password' ? submit : (otpStep === 'phone' ? sendOtp : verifyOtp)} noValidate>
        <h1>ZAMANI</h1>
        <p className="auth-subtitle">ورود به حساب کاربری</p>

        <div className="auth-tabs" role="tablist">
          <button type="button" role="tab" aria-selected={mode === 'password'} className={mode === 'password' ? 'active' : ''} onClick={() => switchMode('password')}>رمز عبور</button>
          <button type="button" role="tab" aria-selected={mode === 'otp'} className={mode === 'otp' ? 'active' : ''} onClick={() => switchMode('otp')}>کد تایید پیامکی</button>
        </div>

        {mode === 'password' ? (
          <>
            {error && <div className="auth-error" role="alert">{error}</div>}
            <input name="login" value={form.login} onChange={change} placeholder="ایمیل یا شماره موبایل" autoComplete="username" required />
            <input name="password" value={form.password} onChange={change} type="password" placeholder="رمز عبور" autoComplete="current-password" required />
            <button type="submit" disabled={loading}>{loading ? 'در حال ورود...' : 'ورود'}</button>
          </>
        ) : (
          <>
            {otpError && <div className="auth-error" role="alert">{otpError}</div>}
            {otpInfo && !otpError && <div className="auth-success">{otpInfo}</div>}

            {otpStep === 'phone' ? (
              <>
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="شماره موبایل"
                  inputMode="tel"
                  autoComplete="tel"
                  required
                />
                <button type="submit" disabled={otpLoading}>{otpLoading ? 'در حال ارسال کد...' : 'ارسال کد تایید'}</button>
              </>
            ) : (
              <>
                <p className="auth-subtitle" style={{ margin: '-4px 0 14px' }}>کد ۵ رقمی ارسال‌شده به {phone} را وارد کنید.</p>
                <input
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="کد تایید"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  autoFocus
                  required
                />
                <button type="submit" disabled={otpLoading}>{otpLoading ? 'در حال بررسی...' : 'ورود'}</button>
                <div className="auth-otp-actions">
                  <button type="button" className="text-link" disabled={cooldown > 0 || otpLoading} onClick={resendOtp}>
                    {cooldown > 0 ? `ارسال مجدد کد (${cooldown} ثانیه)` : 'ارسال مجدد کد'}
                  </button>
                  <button type="button" className="text-link" onClick={() => { setOtpStep('phone'); setCode(''); setOtpError(''); setOtpInfo(''); }}>
                    تغییر شماره موبایل
                  </button>
                </div>
              </>
            )}
          </>
        )}

        <div className="auth-links">
          <Link href="/register">حساب کاربری ندارید؟ <strong>ثبت‌نام کنید</strong></Link>
          <Link href="/forgot-password">رمز عبور را فراموش کرده‌اید؟</Link>
          <Link href="/">بازگشت به فروشگاه</Link>
        </div>
      </form>
    </div>
  );
}
