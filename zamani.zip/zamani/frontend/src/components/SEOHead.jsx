import { useEffect } from 'react';

const SITE_NAME = 'کالکشن زمانی | ZAMANI';
const DEFAULT_DESCRIPTION = 'پوشاک زنانه زمانی؛ انتخابی از لباس‌های زنانه با طراحی مینیمال، کیفیت و اصالت.';
const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000').replace(/\/$/, '');
const MAX_TITLE_LENGTH = 60;
const MAX_DESCRIPTION_LENGTH = 160;

function trimMeta(value, maxLength) {
  const text = String(value || '').replace(/\s+/g, ' ').trim();
  if (!text) return '';
  return text.length <= maxLength ? text : `${text.slice(0, maxLength - 1).trim()}…`;
}

function absoluteUrl(value) {
  if (!value) return '';
  if (/^https?:\/\//i.test(value)) return value;
  return `${SITE_URL}/${String(value).replace(/^\//, '')}`;
}

function setMeta(attribute, key, content) {
  if (!content) return;
  let node = document.head.querySelector(`meta[${attribute}="${CSS.escape(key)}"]`);
  if (!node) {
    node = document.createElement('meta');
    node.setAttribute('meta', 'true');
    node.setAttribute(attribute, key);
    document.head.appendChild(node);
  }
  node.setAttribute('content', content);
}

function removeMeta(attribute, key) {
  document.head.querySelectorAll(`meta[${attribute}="${CSS.escape(key)}"]`).forEach(node => node.remove());
}

function setLink(rel, href) {
  let node = document.head.querySelector(`link[rel="${rel}"]`);
  if (!node) {
    node = document.createElement('link');
    node.setAttribute('rel', rel);
    document.head.appendChild(node);
  }
  node.setAttribute('href', href);
}

export default function SEOHead({
  title,
  description = DEFAULT_DESCRIPTION,
  path,
  image,
  type = 'website',
  noindex = false,
  schema,
}) {
  useEffect(() => {
    const canonicalPath = path || window.location.pathname;
    const normalizedPath = canonicalPath === '/' ? '/' : `/${String(canonicalPath).replace(/^\/+|\/+$/g, '')}`;
    const canonical = `${SITE_URL}${normalizedPath}`;
    const fullTitle = trimMeta(title ? `${title} | ZAMANI` : SITE_NAME, MAX_TITLE_LENGTH);
    const metaDescription = trimMeta(description || DEFAULT_DESCRIPTION, MAX_DESCRIPTION_LENGTH);
    const ogImage = absoluteUrl(image);

    document.title = fullTitle;
    document.documentElement.lang = 'fa';
    document.documentElement.dir = 'rtl';

    setMeta('name', 'description', metaDescription);
    setMeta('name', 'robots', noindex ? 'noindex,nofollow' : 'index,follow');
    setMeta('name', 'googlebot', noindex ? 'noindex,nofollow' : 'index,follow');
    setMeta('property', 'og:title', fullTitle);
    setMeta('property', 'og:description', metaDescription);
    setMeta('property', 'og:type', type);
    setMeta('property', 'og:url', canonical);
    setMeta('property', 'og:site_name', SITE_NAME);
    setMeta('property', 'og:locale', 'fa_IR');
    setMeta('name', 'twitter:card', ogImage ? 'summary_large_image' : 'summary');
    setMeta('name', 'twitter:title', fullTitle);
    setMeta('name', 'twitter:description', metaDescription);

    if (ogImage) {
      setMeta('property', 'og:image', ogImage);
      setMeta('name', 'twitter:image', ogImage);
    } else {
      removeMeta('property', 'og:image');
      removeMeta('name', 'twitter:image');
    }

    setLink('canonical', canonical);

    const oldSchema = document.head.querySelector('script[data-zamani-schema="true"]');
    if (oldSchema) oldSchema.remove();
    if (schema && !noindex) {
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.dataset.zamaniSchema = 'true';
      script.textContent = JSON.stringify(schema);
      document.head.appendChild(script);
    }

    return () => {
      const currentSchema = document.head.querySelector('script[data-zamani-schema="true"]');
      if (currentSchema) currentSchema.remove();
    };
  }, [title, description, path, image, type, noindex, schema]);

  return null;
}

export { SITE_URL, absoluteUrl, DEFAULT_DESCRIPTION, trimMeta };
