import { useEffect, useRef } from 'react';

/**
 * افکت «ابر چرخان»: چند تکه ابر طلاییِ محو که پشت هر دایرهٔ دسته‌بندی،
 * به‌صورت پیوسته و چرخشی (orbit) در گردش هستند — با جاوااسکریپت خالص
 * (requestAnimationFrame) پیاده‌سازی شده تا مسیر، سرعت و عمق نمایش
 * (جلو/پشت رفتن ابرها) کاملاً قابل کنترل باشد.
 *
 * استفاده: <CloudOrbit /> را داخل یک والد با position:relative بگذارید؛
 * اندازه‌اش به‌صورت خودکار از اندازهٔ همان والد خوانده می‌شود، پس با
 * تغییر سایز دایره در حالت موبایل هم هماهنگ می‌ماند.
 */
export default function CloudOrbit({ puffCount = 4, speed = 0.01 }) {
  const rootRef = useRef(null);
  const angleRef = useRef(Math.random() * Math.PI * 2);
  const rafRef = useRef(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return undefined;

    const puffs = Array.from(root.querySelectorAll('.cloud-puff'));
    if (!puffs.length) return undefined;

    // احترام به تنظیم کاهش انیمیشن سیستم کاربر
    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) return undefined;

    function tick() {
      const host = root.parentElement;
      const size = (host && host.clientWidth) || root.clientWidth || 112;
      const radius = size * 0.56;

      angleRef.current += speed;

      puffs.forEach((puff, i) => {
        const offset = (Math.PI * 2 * i) / puffs.length;
        const a = angleRef.current + offset;
        const depth = (Math.sin(a) + 1) / 2; // ۰=پشتِ دایره ، ۱=جلوی دایره
        const x = Math.cos(a) * radius;
        const y = Math.sin(a) * radius * 0.82; // مسیر کمی بیضی برای حس عمق

        puff.style.transform = `translate(${x}px, ${y}px) scale(${0.65 + depth * 0.45})`;
        puff.style.opacity = String(0.28 + depth * 0.5);
        puff.style.zIndex = depth > 0.5 ? '2' : '0';
      });

      rafRef.current = requestAnimationFrame(tick);
    }

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [speed]);

  return (
    <div ref={rootRef} className="cloud-orbit" aria-hidden="true">
      {Array.from({ length: puffCount }).map((_, i) => (
        <span className="cloud-puff" key={i} />
      ))}
    </div>
  );
}
