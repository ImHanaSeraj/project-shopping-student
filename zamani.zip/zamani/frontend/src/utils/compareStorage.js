// Client-side "compare products" list.
// Mirrors the wishlist pattern (zamani_wishlist in localStorage +
// a window event so the header/badges/pages can stay in sync) but keeps
// everything local — comparison is a transient browsing aid, not something
// that needs to live in the database or survive across devices.

export const COMPARE_KEY = 'zamani_compare';
export const COMPARE_LIMIT = 4;
export const COMPARE_EVENT = 'zamani-compare-updated';

export function getCompareIds() {
  try {
    const ids = JSON.parse(localStorage.getItem(COMPARE_KEY) || '[]');
    return Array.isArray(ids) ? ids.map(Number).filter((id) => Number.isFinite(id)) : [];
  } catch {
    return [];
  }
}

function persist(ids) {
  localStorage.setItem(COMPARE_KEY, JSON.stringify(ids));
  window.dispatchEvent(new Event(COMPARE_EVENT));
  return ids;
}

export function isInCompare(productId) {
  return getCompareIds().includes(Number(productId));
}

// Returns { ids, added, limitReached } so callers (buttons, toasts) can
// react without re-reading localStorage themselves.
export function addToCompare(productId) {
  const id = Number(productId);
  const ids = getCompareIds();
  if (ids.includes(id)) return { ids, added: false, limitReached: false };
  if (ids.length >= COMPARE_LIMIT) return { ids, added: false, limitReached: true };
  return { ids: persist([...ids, id]), added: true, limitReached: false };
}

export function removeFromCompare(productId) {
  const id = Number(productId);
  return persist(getCompareIds().filter((existing) => existing !== id));
}

export function toggleCompare(productId) {
  return isInCompare(productId) ? { ids: removeFromCompare(productId), added: false, limitReached: false } : addToCompare(productId);
}

export function clearCompare() {
  return persist([]);
}
