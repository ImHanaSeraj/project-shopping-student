const BACKEND_API=(process.env.NEXT_PUBLIC_API_URL||'http://127.0.0.1:8000/api').replace(/\/$/,'');
export default async function handler(req,res){
 if(!['PUT','DELETE'].includes(req.method)){res.setHeader('Allow','PUT, DELETE');return res.status(405).json({success:false,error:{message:'Method Not Allowed'}})}
 try{const headers={Accept:'application/json'};if(req.headers.authorization)headers.Authorization=req.headers.authorization;let body;if(req.method==='PUT'){body=JSON.stringify(req.body||{});headers['Content-Type']='application/json';}
 const r=await fetch(`${BACKEND_API}/admin/brands/${encodeURIComponent(req.query.id)}`,{method:req.method,headers,body,cache:'no-store'});const t=await r.text();let p;try{p=JSON.parse(t)}catch{p={success:false,error:{message:'پاسخ نامعتبر از سرور'}}}return res.status(r.status).json(p)}catch{return res.status(502).json({success:false,error:{message:'ارتباط با سرور فروشگاه برقرار نشد.'}})}
}
