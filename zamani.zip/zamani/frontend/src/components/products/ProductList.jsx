import React from 'react';
import ProductCard from './ProductCard';
export default function ProductList({products=[]}){return products.map(p=><ProductCard key={p.id} product={p}/>)}
