import ForgotPassword from '../views/auth/ForgotPassword';
import GuestRoute from '../guards/GuestRoute';
export default function ForgotPasswordPage(){ return <GuestRoute><ForgotPassword/></GuestRoute>; }
