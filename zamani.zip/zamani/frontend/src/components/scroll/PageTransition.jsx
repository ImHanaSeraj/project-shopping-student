import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

/**
 * Lightweight route transition for the existing Next.js pages.
 * It only animates opacity/transform, so it does not affect layout dimensions.
 */
export default function PageTransition({ children }) {
  const router = useRouter();
  const [state, setState] = useState('enter');

  useEffect(() => {
    let enterTimer;

    const handleStart = () => {
      window.clearTimeout(enterTimer);
      setState('exit');
    };

    const handleComplete = () => {
      setState('enter');
      enterTimer = window.setTimeout(() => setState('idle'), 420);
    };

    router.events.on('routeChangeStart', handleStart);
    router.events.on('routeChangeComplete', handleComplete);
    router.events.on('routeChangeError', handleComplete);

    return () => {
      window.clearTimeout(enterTimer);
      router.events.off('routeChangeStart', handleStart);
      router.events.off('routeChangeComplete', handleComplete);
      router.events.off('routeChangeError', handleComplete);
    };
  }, [router.events]);

  return (
    <div className={`page-transition page-transition--${state}`}>
      {children}
    </div>
  );
}
