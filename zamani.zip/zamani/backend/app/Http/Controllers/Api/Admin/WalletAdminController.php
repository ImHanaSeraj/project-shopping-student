<?php
namespace App\Http\Controllers\Api\Admin;
use App\Models\User;
use App\Services\WalletService;
use Illuminate\Http\Request;
class WalletAdminController extends AdminBaseController {
 public function index(Request $r,WalletService $wallet){$this->guardAdmin($r);$q=User::select('id','name','email','phone','wallet_balance')->withCount('walletTransactions');if($r->filled('search')){$s=trim($r->search);$q->where(fn($x)=>$x->where('name','like','%'.$s.'%')->orWhere('email','like','%'.$s.'%')->orWhere('phone','like','%'.$s.'%'));}return response()->json(['users'=>$q->orderByDesc('wallet_balance')->paginate(15),'total_balance'=>(float)User::sum('wallet_balance')]);}
 public function adjust(Request $r,$id,WalletService $wallet){$this->guardAdmin($r);$d=$r->validate(['amount'=>['required','numeric','not_in:0','between:-500000000,500000000'],'description'=>['required','string','max:255']]);$u=User::findOrFail($id);$amount=(float)$d['amount'];if($amount>0)$wallet->credit($u,$amount,'admin_adjustment',$d['description'],'admin-wallet:'.auth()->id().':'.$u->id.':'.now()->format('YmdHisv'));else{$wallet->debit($u,abs($amount),$d['description'],'admin-wallet:'.auth()->id().':'.$u->id.':'.now()->format('YmdHisv'));}return response()->json(['message'=>'موجودی کیف پول اصلاح شد.','user'=>$u->fresh()->only(['id','name','email','phone','wallet_balance'])]);}
}
