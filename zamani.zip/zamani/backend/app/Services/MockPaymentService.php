<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Support\Str;
use RuntimeException;

class MockPaymentService
{
    public function enabled(): bool
    {
        return (bool) config('payment.mock_enabled') && config('payment.gateway') === 'mock';
    }

    public function initiate(Order $order, Payment $payment): array
    {
        if (!$this->enabled()) {
            throw new RuntimeException('پرداخت آزمایشی فعال نیست.');
        }

        if ($payment->status === 'paid') {
            return ['status' => 'paid'];
        }

        $authority = $payment->authority ?: 'MOCK-AUTH-' . Str::upper(Str::random(24));
        $transactionId = $payment->transaction_id ?: 'MOCK-TXN-' . Str::upper(Str::random(20));
        $payment->forceFill([
            'gateway' => 'mock',
            'status' => 'initiated',
            'authority' => $authority,
            'transaction_id' => $transactionId,
        ])->save();

        $url = rtrim((string) config('payment.mock_frontend_url'), '/')
            . '?order=' . $order->id
            . '&payment=' . $payment->id
            . '&token=' . urlencode($authority);

        return [
            'status' => 'redirect',
            'payment_url' => $url,
            'authority' => $authority,
            'transaction_id' => $transactionId,
        ];
    }

    public function assertCallbackToken(Payment $payment, string $token): void
    {
        if (!$payment->authority || !hash_equals((string) $payment->authority, $token)) {
            throw new RuntimeException('توکن پرداخت آزمایشی معتبر نیست.');
        }
    }

    public function referenceId(): string
    {
        return 'MOCK-REF-' . now()->format('YmdHis') . '-' . Str::upper(Str::random(8));
    }
}
