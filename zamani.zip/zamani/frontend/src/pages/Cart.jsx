import OptimizedImage from '../components/OptimizedImage';
import { useEffect, useMemo, useState } from 'react';
import { Link } from '../utils/routerCompat';
import Icon from '../components/Icon';
import { cartTotals, formatPrice, readCart, writeCart, fetchCart, updateCartItem, removeCartItem, clearCart } from '../services/cart';
import { useAuth } from '../context/AuthContext';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { confirmAction, notify } from '../components/UXFeedback';

function CartItem({ item, onChange, onRemove }) {
  const selections = item.selections || {};
  const variantText = [selections.color && `رنگ: ${selections.color}`, selections.size && `سایز: ${selections.size}`, selections.model && `مدل: ${selections.model}`].filter(Boolean);
  return <article className="cart-item">
    <Link to={`/products/${item.slug || item.productSlug || item.productId}`} className="cart-item-media">
      {item.image ? <img src={item.image} alt={item.name} /> : <span>ZAMANI</span>}
    </Link>
    <div className="cart-item-main">
      <div className="cart-item-heading"><div><span className="eyebrow">{item.brand || 'ZAMANI'}</span><Link to={`/products/${item.slug || item.productSlug || item.productId}`}><h3>{item.name}</h3></Link></div><button className="cart-remove" onClick={() => onRemove(item.id || item.key)} aria-label="حذف محصول"><Icon name="trash" size={17}/></button></div>
      {variantText.length > 0 && <div className="cart-variants">{variantText.map(v => <span key={v}>{v}</span>)}</div>}
      {item.SKU && <small className="cart-sku">SKU: {item.SKU}</small>}
      <div className="cart-item-bottom"><div className="quantity-control cart-quantity"><button onClick={() => onChange(item.id || item.key, -1)} aria-label="کاهش"><Icon name="minus" size={14}/></button><strong>{new Intl.NumberFormat('fa-IR').format(item.quantity)}</strong><button onClick={() => onChange(item.id || item.key, 1)} aria-label="افزایش"><Icon name="plus" size={14}/></button></div><strong className="cart-item-price">{formatPrice(Number(item.price) * Number(item.quantity))}</strong></div>
    </div>
  </article>;
}

export default function Cart() {
  useDocumentTitle('سبد خرید | زمانی');
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState('loading');
  const [error, setError] = useState('');
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        if (!user) { setItems(readCart()); }
        else { setItems(await fetchCart()); }
        if (!cancelled) setStatus('ready');
      } catch { if (!cancelled) { setError('امکان بارگذاری سبد خرید وجود ندارد.'); setStatus('error'); } }
    };
    load();
    return () => { cancelled = true; };
  }, [user]);
  const totals = useMemo(() => cartTotals(items), [items]);
  const update = async (id, delta) => {
    const item = items.find(x => (user ? x.id : x.key) === id);
    if (!item) return;
    const quantity = Math.max(1, Number(item.quantity || 1) + delta);
    try {
      if (user) {
        const { item: updated } = await updateCartItem(item.id, quantity).then(r => r);
        setItems(current => current.map(x => x.id === item.id ? updated : x));
      } else {
        setItems(current => { const next=current.map(x => x.key===id ? {...x, quantity} : x); writeCart(next); return next; });
      }
      window.dispatchEvent(new Event('zamani-cart-updated'));
    } catch (e) { notify(e?.response?.data?.message || 'تعداد انتخاب‌شده از موجودی بیشتر است.'); }
  };
  const remove = async id => {
    const item = items.find(x => (user ? x.id : x.key) === id);
    const ok = await confirmAction(`«${item?.name || 'این محصول'}» از سبد خرید حذف شود؟`, 'حذف از سبد خرید');
    if (!ok) return;
    try {
      if (user) await removeCartItem(item.id); else writeCart(items.filter(x => x.key !== id));
      setItems(current => current.filter(x => (user ? x.id : x.key) !== id));
      window.dispatchEvent(new Event('zamani-cart-updated'));
      notify('محصول از سبد خرید حذف شد.');
    } catch { notify('حذف محصول انجام نشد.'); }
  };
  const clear = async () => {
    const ok = await confirmAction('تمام محصولات سبد خرید حذف شوند؟', 'حذف همه محصولات');
    if (!ok) return;
    try { if (user) await clearCart(); else writeCart([]); setItems([]); window.dispatchEvent(new Event('zamani-cart-updated')); notify('سبد خرید خالی شد.'); }
    catch { notify('خالی کردن سبد خرید انجام نشد.'); }
  };

  if (status === 'loading') return <div className="cart-page container"><div className="cart-state"><div className="cart-spinner"/><strong>در حال بارگذاری سبد خرید...</strong></div></div>;
  if (status === 'error') return <div className="cart-page container"><div className="cart-state"><Icon name="x" size={26}/><strong>{error}</strong><button className="btn btn-primary" onClick={() => window.location.reload()}>تلاش مجدد</button></div></div>;
  if (!items.length) return <div className="cart-page container"><div className="cart-breadcrumb"><Link to="/">خانه</Link><span>/</span><span>سبد خرید</span></div><div className="cart-empty"><div className="cart-empty-icon"><Icon name="bag" size={30}/></div><span className="eyebrow">YOUR SHOPPING BAG</span><h1>سبد خرید شما خالی است</h1><p>محصولات مورد علاقه‌تان را انتخاب کنید و برای ادامه خرید به فروشگاه برگردید.</p><Link className="btn btn-primary" to="/products">مشاهده محصولات <Icon name="arrow" size={15}/></Link></div></div>;
  return <div className="cart-page container">
    <div className="cart-breadcrumb"><Link to="/">خانه</Link><span>/</span><span>سبد خرید</span></div>
    <div className="cart-head"><div><span className="eyebrow">SHOPPING BAG</span><h1>سبد خرید</h1><p>{new Intl.NumberFormat('fa-IR').format(items.reduce((s,x)=>s+Number(x.quantity||0),0))} عدد محصول در سبد شماست.</p></div><button className="text-link cart-clear" onClick={clear}>حذف همه</button></div>
    <div className="cart-layout"><section className="cart-list">{items.map(item => <CartItem key={item.key || item.id} item={item} onChange={update} onRemove={remove}/>)}</section>
      <aside className="cart-summary"><div className="summary-heading"><span className="eyebrow">ORDER SUMMARY</span><h2>خلاصه سفارش</h2></div><div className="summary-row"><span>جمع محصولات</span><strong>{formatPrice(totals.subtotal)}</strong></div>{totals.discount>0 && <div className="summary-row discount"><span>تخفیف</span><strong>- {formatPrice(totals.discount)}</strong></div>}<div className="summary-row"><span>ارسال</span><strong>{totals.shipping===0?'رایگان':formatPrice(totals.shipping)}</strong></div><div className="summary-divider"/><div className="summary-row total"><span>مبلغ نهایی</span><strong>{formatPrice(totals.total)}</strong></div><Link className="btn btn-primary checkout-btn" to="/checkout">ادامه و ثبت سفارش <Icon name="arrow" size={15}/></Link><p className="shipping-note"><Icon name="truck" size={15}/> ارسال رایگان برای سفارش‌های بالای ۴ میلیون تومان</p></aside>
    </div>
  </div>;
}
