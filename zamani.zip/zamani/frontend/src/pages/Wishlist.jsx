import OptimizedImage from '../components/OptimizedImage';
import { animateToCart } from '../components/cart/CartAnimation';
import { useEffect, useState } from 'react';
import { Link, useNavigate } from '../utils/routerCompat';
import Icon from '../components/Icon';
import { getWishlist, removeFromWishlist } from '../services/wishlist';
import { readCart, writeCart, formatPrice } from '../services/cart';

function ProductPlaceholder() { return <div className="wishlist-placeholder"><span>ZAMANI</span><small>PRODUCT IMAGE</small></div>; }

export default function Wishlist() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [adding, setAdding] = useState(null);
  const [page, setPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);

  const load = async (targetPage = 1) => {
    setLoading(true); setError('');
    try {
      const response = await getWishlist(targetPage);
      const payload = response?.data;
      setItems(payload?.data || []);
      setPage(payload?.current_page || targetPage);
      setLastPage(payload?.last_page || 1);
    } catch (e) {
      if (e?.response?.status === 401) { navigate('/login', { state: { from: { pathname: '/wishlist' } } }); return; }
      setError('دریافت علاقه‌مندی‌ها با خطا مواجه شد.');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const remove = async (id) => {
    const previous = items;
    setItems(previous.filter(item => Number(item.id) !== Number(id)));
    try { await removeFromWishlist(id); window.dispatchEvent(new Event('zamani-wishlist-updated')); }
    catch { setItems(previous); setError('حذف محصول انجام نشد.'); }
  };

  const addCart = (product) => {
    setAdding(product.id);
    const items = readCart();
    const key = `${product.id}-wishlist`;
    const price = Number(product.discount_price || product.price || 0);
    const existing = items.find(item => item.key === key);
    const next = existing ? items.map(item => item.key === key ? { ...item, quantity: Number(item.quantity || 0) + 1 } : item) : [...items, { key, productId: product.id, name: product.name, image: product.image || product.images?.[0]?.image || '', price, originalPrice: Number(product.price || price), discount: Math.max(0, Number(product.price || 0) - price), quantity: 1, selections: {} }];
    writeCart(next); window.dispatchEvent(new Event('zamani-wishlist-updated')); animateToCart(document.activeElement, product.image || product.images?.[0]?.image || product.images?.[0]?.path); setTimeout(() => setAdding(null), 300);
  };

  if (loading) return <main className="wishlist-page container"><div className="wishlist-state"><div className="wishlist-spinner"/><strong>در حال بارگذاری علاقه‌مندی‌ها...</strong></div></main>;
  if (error && !items.length) return <main className="wishlist-page container"><div className="wishlist-state"><Icon name="heart" size={30}/><strong>{error}</strong><button className="btn btn-primary" onClick={() => load(page)}>تلاش دوباره</button></div></main>;

  return <main className="wishlist-page container">
    <div className="wishlist-breadcrumb"><Link to="/">خانه</Link><Icon name="arrow" size={11}/><span>علاقه‌مندی‌ها</span></div>
    <header className="wishlist-head"><div><h1 className="wishlist-title products-title-gradient">علاقه‌مندی‌ها</h1><p>{items.length ? `${new Intl.NumberFormat('fa-IR').format(items.length)} محصول در لیست شما` : 'محصولات مورد علاقه‌تان را اینجا نگه دارید.'}</p></div></header>
    {error && <div className="wishlist-inline-error">{error}</div>}
    {!items.length ? <div className="wishlist-empty"><div className="wishlist-empty-icon"><Icon name="heart" size={28}/></div><span className="eyebrow">YOUR WISHLIST</span><h2>لیست علاقه‌مندی‌ها خالی است</h2><p>محصولاتی که دوست دارید را به علاقه‌مندی‌ها اضافه کنید تا بعداً راحت‌تر آن‌ها را پیدا کنید.</p><Link className="btn btn-primary" to="/products">مشاهده محصولات <Icon name="arrow" size={14}/></Link></div> : <>
      <div className="wishlist-grid">{items.map(product => { const price = Number(product.discount_price || product.price || 0); const discount = product.discount_price && Number(product.discount_price) < Number(product.price) ? Math.round((1 - price / Number(product.price)) * 100) : 0; return <article className="wishlist-card" key={product.id}>
        <div className="wishlist-media">{product.image ? <OptimizedImage src={product.image} alt={product.name} /> : <ProductPlaceholder/>}{discount > 0 && <span className="product-badge">{discount}٪</span>}<button className="wishlist-remove" onClick={() => remove(product.id)} aria-label="حذف از علاقه‌مندی"><Icon name="heart" size={18}/></button><Link className="wishlist-view" to={`/products/${product.slug || product.id}`}>مشاهده محصول <Icon name="arrow" size={13}/></Link></div>
        <div className="wishlist-info"><span className="product-category">{product.brand?.name || 'ZAMANI'}</span><Link to={`/products/${product.slug || product.id}`}><h3>{product.name}</h3></Link><div className="wishlist-price"><strong>{formatPrice(price)}</strong>{discount > 0 && <del>{formatPrice(product.price)}</del>}</div><button className="btn btn-outline wishlist-cart" disabled={adding === product.id} onClick={() => addCart(product)}>{adding === product.id ? 'اضافه شد' : 'افزودن به سبد'} <Icon name="bag" size={14}/></button></div>
      </article>})}</div>
      {lastPage > 1 && <div className="wishlist-pagination"><button disabled={page <= 1} onClick={() => load(page - 1)}>قبلی</button><span>صفحه {page} از {lastPage}</span><button disabled={page >= lastPage} onClick={() => load(page + 1)}>بعدی</button></div>}
    </>}
  </main>;
}
