import { useEffect, useState } from 'react';
import Link from '../components/SafeLink';
import {useSearchParams} from '../utils/routerCompat';
import Icon from '../components/Icon';
import { startPayment } from '../services/payment';
import { writeCart } from '../services/cart';
import useDocumentTitle from '../hooks/useDocumentTitle';

export default function PaymentResult(){
  useDocumentTitle('نتیجه پرداخت | زمانی');
  const [params] = useSearchParams();
  const status = params.get('status');
  const success = status === 'success';
  const cancelled = status === 'cancelled';
  const orderId = params.get('order');
  const orderNumber = params.get('order_number');
  const transactionId = params.get('transaction_id');
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState('');

  useEffect(() => {
    if (success) writeCart([]);
  }, [success]);
  const retry=async()=>{setLoading(true);setError('');try{const {data}=await startPayment(orderId);if(data.payment_url) window.location.assign(data.payment_url);else throw new Error('درگاه پرداخت در دسترس نیست.')}catch(e){setError(e?.response?.data?.message||e.message||'امکان شروع دوباره پرداخت وجود ندارد.')}finally{setLoading(false)}};
  return <main className="payment-result container"><div className={`payment-result-card ${success?'is-success':cancelled?'is-cancelled':'is-failed'}`}>
    <div className="payment-result-icon"><Icon name={success?'check':'x'} size={34}/></div><span className="eyebrow">PAYMENT RESULT</span>
    <h1>{success?'پرداخت با موفقیت انجام شد':cancelled?'پرداخت لغو شد':'پرداخت ناموفق بود'}</h1>
    <p>{success?'سفارش شما با موفقیت پرداخت و ثبت نهایی شد.':cancelled?'پرداخت توسط شما لغو شد؛ سفارش برای پرداخت مجدد آماده است.':'تراکنش تأیید نشد. می‌توانید دوباره پرداخت را امتحان کنید.'}</p>
    {orderNumber&&<div className="payment-result-meta"><span>شماره سفارش</span><strong>{orderNumber}</strong></div>}{transactionId&&<div className="payment-result-meta"><span>شناسه تراکنش</span><strong>{transactionId}</strong></div>}
    {error&&<div className="checkout-alert">{error}</div>}
    <div className="payment-result-actions">{!success&&orderId&&<button className="btn btn-primary" onClick={retry} disabled={loading}>{loading?'در حال انتقال...':'پرداخت مجدد'}</button>}<Link className="btn btn-secondary" href={success?'/products':'/'}>{success?'ادامه خرید':'صفحه اصلی'}</Link></div>
  </div></main>
}
