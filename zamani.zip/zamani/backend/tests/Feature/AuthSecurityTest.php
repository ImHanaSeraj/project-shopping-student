<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AuthSecurityTest extends TestCase
{
    use RefreshDatabase;

    public function test_registration_hashes_password_and_returns_token(): void
    {
        $response = $this->postJson('/api/auth/register', [
            'name' => 'کاربر تست',
            'phone' => '09120000001',
            'email' => 'test@example.com',
            'password' => 'StrongPass123!',
            'password_confirmation' => 'StrongPass123!',
        ]);

        $response->assertCreated()->assertJsonStructure(['user', 'token']);
        $user = User::where('email', 'test@example.com')->firstOrFail();
        $this->assertTrue(Hash::check('StrongPass123!', $user->password));
        $this->assertNotSame('StrongPass123!', $user->password);
    }

    public function test_login_rejects_inactive_user(): void
    {
        $user = User::create([
            'name' => 'Inactive',
            'email' => 'inactive@example.com',
            'phone' => '09120000002',
            'password' => 'StrongPass123!',
            'status' => false,
        ]);

        $this->postJson('/api/auth/login', [
            'login' => $user->email,
            'password' => 'StrongPass123!',
        ])->assertUnauthorized();
    }

    public function test_inactive_token_cannot_use_protected_endpoints(): void
    {
        $user = User::create([
            'name' => 'Inactive',
            'email' => 'inactive2@example.com',
            'phone' => '09120000003',
            'password' => 'StrongPass123!',
            'status' => false,
        ]);

        Sanctum::actingAs($user);

        $this->getJson('/api/profile')
            ->assertForbidden();
    }

    public function test_customer_cannot_access_admin_api(): void
    {
        $user = User::create([
            'name' => 'Customer',
            'email' => 'customer@example.com',
            'phone' => '09120000004',
            'password' => 'StrongPass123!',
            'role' => 'customer',
            'status' => true,
        ]);

        Sanctum::actingAs($user);

        $this->getJson('/api/admin/dashboard')->assertForbidden();
    }

    public function test_customer_cannot_view_another_customers_order(): void
    {
        $owner = User::create([
            'name' => 'Owner', 'email' => 'owner@example.com', 'phone' => '09120000005',
            'password' => 'StrongPass123!', 'status' => true,
        ]);
        $attacker = User::create([
            'name' => 'Attacker', 'email' => 'attacker@example.com', 'phone' => '09120000006',
            'password' => 'StrongPass123!', 'status' => true,
        ]);
        $address = Address::create([
            'user_id' => $owner->id,
            'receiver_name' => $owner->name,
            'phone' => $owner->phone,
            'province' => 'تهران',
            'city' => 'تهران',
            'address' => 'آدرس تست',
            'postal_code' => '1111111111',
        ]);
        $order = Order::create([
            'user_id' => $owner->id,
            'address_id' => $address->id,
            'order_number' => 'ZM-SEC-0001',
            'total' => 100000,
            'final_total' => 100000,
        ]);

        Sanctum::actingAs($attacker);

        $this->getJson('/api/orders/' . $order->id)->assertNotFound();
    }

    public function test_customer_can_only_use_own_addresses_endpoint(): void
    {
        $user = User::create([
            'name' => 'Customer', 'email' => 'address@example.com', 'phone' => '09120000007',
            'password' => 'StrongPass123!', 'status' => true,
        ]);
        Address::create([
            'user_id' => $user->id,
            'receiver_name' => 'گیرنده',
            'phone' => $user->phone,
            'province' => 'تهران',
            'city' => 'تهران',
            'address' => 'آدرس تست',
            'postal_code' => '1111111111',
        ]);

        Sanctum::actingAs($user);

        $this->getJson('/api/checkout/addresses')
            ->assertOk()
            ->assertJsonCount(1);
    }
}
