<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::table('users', function(Blueprint $t){ $t->decimal('wallet_balance',14,2)->default(0)->after('loyalty_points_balance'); }); }
 public function down(): void { Schema::table('users', fn(Blueprint $t)=>$t->dropColumn('wallet_balance')); }
};
