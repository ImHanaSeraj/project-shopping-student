import Link from 'next/link';
import Icon from '../components/Icon';
import ProductCard from '../components/products/ProductCard';
import { useEffect, useMemo, useState } from 'react';
import { getCategories, getProducts } from '../services/productApi';
import SEOHead, { absoluteUrl } from '../components/SEOHead';

const formatPrice = n => new Intl.NumberFormat('fa-IR').format(Number(n || 0));

function PageHero({ title, text, image }) {
  const style = image
    ? { backgroundImage: `linear-gradient(180deg, rgba(8,8,8,.45), rgba(8,8,8,.75) 65%, rgba(8,8,8,.9)), url(${image})` }
    : {};
  return <section className={`inner-page-hero container${image ? ' has-image' : ''}`} style={style}>
    <div className="hero-content">
      <h1 className="page-title-gradient">{title}</h1>
      <p>{text}</p>
    </div>
  </section>;
}

export function About() {
  return <div className="inner-page about-page">
    <SEOHead title="درباره زمانی" description="درباره فروشگاه پوشاک زنانه زمانی، فلسفه طراحی و اصول انتخاب محصولات." path="/about" />
    <PageHero title="درباره زمانی" image="/images/banners/about.png" text="زمانی برای زنانی ساخته شده که کیفیت، ظرافت و انتخاب آگاهانه را بخشی از سبک زندگی خود می‌دانند." />
    <section className="container editorial-story">
      <div className="story-mark"><img src="/images/branding/logo-zamani.png" alt="کالکشن زمانی" /></div>
      <div><span className="eyebrow">فلسفه زمانی</span><h2>کمتر، دقیق‌تر، ماندگارتر.</h2><p>ما در زمانی تلاش می‌کنیم مجموعه‌ای از پوشاک زنانه را انتخاب کنیم که فراتر از ترندهای کوتاه‌مدت باشند. فرم‌های تمیز، رنگ‌های قابل استفاده و کیفیت دوخت، سه اصل اصلی انتخاب ما هستند.</p><p>هدف ما ساخت تجربه‌ای آرام و مطمئن از انتخاب تا تحویل است؛ تجربه‌ای که در آن هر قطعه لباس، دلیل مشخصی برای حضور در کمد شما داشته باشد.</p></div>
    </section>
    <section className="container values-grid">
      {[["کیفیت","انتخاب دقیق پارچه و توجه به جزئیات"],["اصالت","محصولی که با خیال راحت انتخاب می‌کنید"],["سادگی","طراحی‌هایی که با زمان از مد نمی‌افتند"]].map(([t,d]) => <article key={t}><h3>{t}</h3><p>{d}</p></article>)}
    </section>
  </div>;
}

export function SizeGuide() {
  const table = [
    ['S', '36', '80-84', '62-66', '88-92'],
    ['M', '38', '85-89', '67-71', '93-97'],
    ['L', '40', '90-94', '72-76', '98-102'],
    ['XL', '42', '95-99', '77-81', '103-107'],
  ];
  return <div className="inner-page">
    <SEOHead title="راهنمای خرید" description="راهنمای انتخاب سایز و نکات خرید محصولات پوشاک زنانه زمانی." path="/guide" />
    <PageHero title="راهنمای خرید" image="/images/banners/guide.png" text="برای اینکه بهترین انتخاب را داشته باشید، جدول سایزبندی و نکات اندازه‌گیری زمانی را مطالعه کنید." />
    <section className="container policy-content">
      <div className="policy-block">
        <span className="eyebrow">STEP 01</span>
        <h2>چطور سایز مناسب را اندازه بگیریم؟</h2>
        <p>با یک متر نواری، دور سینه، دور کمر و دور باسن خود را در حالت ایستاده و بدون فشردن متر اندازه بگیرید. سپس عدد به‌دست‌آمده را با جدول سایزبندی زیر مقایسه کنید تا نزدیک‌ترین سایز به بدن خود را پیدا کنید.</p>
      </div>
      <div className="table-wrap">
        <table className="size-table">
          <thead><tr><th>سایز</th><th>سایز ایرانی</th><th>دور سینه</th><th>دور کمر</th><th>دور باسن</th></tr></thead>
          <tbody>{table.map(row => <tr key={row[0]}>{row.map((cell, i) => <td key={i}>{cell}</td>)}</tr>)}</tbody>
        </table>
      </div>
      <div className="policy-block">
        <span className="eyebrow">STEP 02</span>
        <h2>نکات تکمیلی انتخاب سایز</h2>
        <p>اگر اندازه شما بین دو سایز قرار می‌گیرد، برای لباس‌های رسمی سایز کوچک‌تر و برای لباس‌های روزمره و راحت سایز بزرگ‌تر را انتخاب کنید. توضیحات هر محصول شامل جنس پارچه و میزان کشسانی آن است که در انتخاب سایز مؤثر است.</p>
        <p>در صورت هرگونه تردید، پیش از ثبت سفارش با پشتیبانی زمانی از طریق <Link href="/contact" className="text-link">صفحه تماس با ما <Icon name="arrow" size={13}/></Link> در ارتباط باشید تا شما را در انتخاب دقیق‌تر راهنمایی کنیم.</p>
      </div>
    </section>
  </div>;
}

export function Shipping() {
  const items = [
    ['۱', 'ارسال به سراسر کشور', 'سفارش‌های شما از طریق پست پیشتاز و تیپاکس به تمام نقاط ایران ارسال می‌شود.'],
    ['۲', 'هزینه و زمان ارسال', 'برای سفارش‌های بالای ۴ میلیون تومان ارسال رایگان است. زمان ارسال معمولاً ۱ تا ۳ روز کاری در تهران و ۲ تا ۵ روز کاری برای سایر شهرها خواهد بود.'],
    ['۳', 'پیگیری مرسوله', 'پس از خروج سفارش از انبار، کد رهگیری از طریق پیامک برای شما ارسال می‌شود و می‌توانید وضعیت مرسوله را از بخش «سفارش‌های من» پیگیری کنید.'],
  ];
  return <div className="inner-page">
    <SEOHead title="شرایط ارسال" description="شرایط، هزینه و زمان ارسال سفارش‌های پوشاک زنانه زمانی." path="/shipping" />
    <PageHero title="شرایط ارسال" image="/images/banners/shipping.png" text="اطلاعات کامل درباره روش، هزینه و زمان تحویل سفارش‌های زمانی." />
    <section className="container values-grid policy-grid">
      {items.map(([n, t, d]) => <article key={n}><span>{n}</span><h3>{t}</h3><p>{d}</p></article>)}
    </section>
  </div>;
}

export function Terms() {
  const sections = [
    ['شرایط استفاده', 'استفاده از فروشگاه زمانی به‌معنای پذیرش کامل قوانین و مقررات این وب‌سایت است. اطلاعات درج‌شده برای محصولات از نظر رنگ و جنس ممکن است بسته به تنظیمات نمایشگر شما اندکی متفاوت باشد.'],
    ['حریم خصوصی', 'اطلاعات هویتی و مالی مشتریان نزد زمانی محفوظ است و صرفاً برای پردازش سفارش و ارتباط با مشتری استفاده می‌شود و در اختیار اشخاص ثالث قرار نمی‌گیرد.'],
    ['مرجوعی و بازگشت وجه', 'در صورت وجود ایراد در کالا یا عدم تطابق سایز، تا ۳ روز پس از تحویل امکان مرجوعی وجود دارد. کالای بازگشتی باید بدون استفاده و با برچسب اصلی باشد. مبلغ سفارش پس از تأیید کالا به‌حساب مشتری بازگردانده می‌شود.'],
    ['حقوق مشتری', 'مشتریان زمانی می‌توانند در هر مرحله از خرید، از طریق پشتیبانی، سؤالات و درخواست‌های خود را مطرح کنند و از حق انصراف مطابق قوانین فوق برخوردار هستند.'],
  ];
  return <div className="inner-page">
    <SEOHead title="قوانین و مقررات" description="قوانین، مقررات و شرایط استفاده از فروشگاه پوشاک زنانه زمانی." path="/terms" />
    <PageHero title="قوانین و مقررات" image="/images/banners/terms.png" text="پیش از خرید، قوانین و شرایط استفاده از فروشگاه زمانی را مطالعه کنید." />
    <section className="container policy-content">
      {sections.map(([t, d]) => <div className="policy-block" key={t}><h2>{t}</h2><p>{d}</p></div>)}
    </section>
  </div>;
}

export function Categories({ initialCategories = [], initialCategoryError = '' }) {
  const hasInitial = Array.isArray(initialCategories) && initialCategories.length > 0;
  const [items, setItems] = useState(hasInitial ? initialCategories : []);
  const [loading, setLoading] = useState(!hasInitial && !initialCategoryError);
  const [error, setError] = useState(initialCategoryError || '');

  useEffect(() => {
    // The /categories page receives fresh data from Laravel during SSR.
    // Only fall back to the same-origin API when SSR did not receive data.
    if (hasInitial || initialCategoryError) return;
    let alive = true;
    getCategories()
      .then(r => {
        if (!alive) return;
        const payload = r.data?.data || r.data || [];
        setItems(Array.isArray(payload) ? payload : []);
      })
      .catch(err => {
        if (!alive) return;
        console.error('[Categories] database request failed:', err);
        setError(err?.response?.data?.error?.message || err?.response?.data?.error?.detail || 'دریافت دسته‌بندی‌ها از پایگاه داده انجام نشد.');
      })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [hasInitial, initialCategoryError]);

  const cats = items;
  return <div className="inner-page"><SEOHead title="دسته‌بندی‌ها" image="/images/banners/categories.png" description="دسته‌بندی‌های پوشاک زنانه زمانی را ببینید و محصولات موردنظر خود را پیدا کنید." path="/categories" />
    <PageHero title="دسته‌بندی‌ها" image="/images/banners/categories.png" text="دسته موردنظر خود را انتخاب کنید و مجموعه مرتبط را ببینید." />
    <section className="container category-directory">
      {loading ? <div className="empty-panel">در حال دریافت دسته‌بندی‌ها از پایگاه داده...</div> : null}
      {!loading && error ? <div className="empty-panel">{error}</div> : null}
      {!loading && !error && !cats.length ? <div className="empty-panel">هنوز دسته‌بندی فعالی در پایگاه داده ثبت نشده است.</div> : null}
      {!loading && !error && cats.map((cat, i) => <Link key={cat.id || cat.name} href={`/categories/${cat.slug || cat.id}`} className="directory-card">
        <div className="directory-content">
          <small>{cat.parent_id ? 'SUB-CATEGORY' : 'COLLECTION'}</small>
          <h2>{cat.name}</h2>
          <p>مشاهده محصولات <Icon name="arrow" size={15}/></p>
        </div>
        <div className="directory-media">
          <img src={cat.image ? (cat.image.startsWith('/storage/') ? `${(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api').replace(/\/api\/?$/, '')}${cat.image}` : cat.image) : `/images/categories/categories ${(i % 6) + 1}.png`} alt={cat.name} loading="lazy" />
        </div>
      </Link>)}
    </section>
  </div>;
}

function CollectionPage({ type }) {
  const [products, setProducts] = useState([]);
  useEffect(() => { getProducts({ per_page: 20 }).then(r => setProducts(r.data?.data || r.data || [])).catch(() => {}); }, []);
  const title = type === 'latest' ? 'جدیدترین‌ها' : 'پرفروش‌ترین‌ها';
  const description = type === 'latest' ? 'تازه‌ترین انتخاب‌های زمانی، با تمرکز بر فرم‌های امروزی و استفاده روزمره.' : 'محبوب‌ترین انتخاب‌های مشتریان زمانی در یک مجموعه یکپارچه.';
  const list = useMemo(() => type === 'latest' ? products.slice().reverse() : products, [products, type]);
  return <div className="inner-page"><SEOHead title={title} description={description} path={type === 'latest' ? '/latest' : '/bestsellers'} />
    <PageHero title={title} image={type === 'latest' ? "/images/banners/latest.png" : "/images/banners/bestsellers.png"} text={description}/>
    <section className="container collection-toolbar"><span>{formatPrice(list.length)} محصول</span><Link href="/products">مشاهده همه محصولات <Icon name="arrow" size={15}/></Link></section>
    <section className="container collection-grid">{list.length ? list.map(p => <ProductCard key={p.id} product={p}/>) : <div className="empty-panel">در حال دریافت محصولات...</div>}</section>
  </div>;
}

export function Latest() { return <CollectionPage type="latest"/>; }
export function Bestsellers() { return <CollectionPage type="best"/>; }


/* Default export required by React.lazy in AppRouter. */
export default function InfoPages({ kind = "about", initialCategories = [], initialCategoryError = '' }) {
  if (kind === "categories") return <Categories initialCategories={initialCategories} initialCategoryError={initialCategoryError} />;
  if (kind === "latest") return <Latest />;
  if (kind === "bestsellers") return <Bestsellers />;
  if (kind === "guide") return <SizeGuide />;
  if (kind === "shipping") return <Shipping />;
  if (kind === "terms") return <Terms />;
  return <About />;
}
