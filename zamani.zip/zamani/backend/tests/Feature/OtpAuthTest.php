<?php

namespace Tests\Feature;

use App\Contracts\SmsGatewayInterface;
use App\Models\Address;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class OtpAuthTest extends TestCase
{
    use RefreshDatabase;

    /** Captures the last "sent" SMS instead of calling a real gateway, and lets us read the code back out. */
    private function fakeGateway(): object
    {
        $fake = new class implements SmsGatewayInterface {
            public array $sent = [];

            public function send(string $phone, string $message): void
            {
                $this->sent[] = ['phone' => $phone, 'message' => $message];
            }

            public function lastCode(): ?string
            {
                $last = end($this->sent);
                if (!$last) {
                    return null;
                }
                preg_match('/(\d{4,8})/', $last['message'], $m);
                return $m[1] ?? null;
            }
        };

        $this->app->instance(SmsGatewayInterface::class, $fake);

        return $fake;
    }

    public function test_otp_login_request_is_silent_for_unregistered_phone(): void
    {
        $fake = $this->fakeGateway();

        $this->postJson('/api/auth/otp/request', ['phone' => '09120000099'])
            ->assertOk();

        $this->assertCount(0, $fake->sent);
        $this->assertDatabaseCount('otp_codes', 0);
    }

    public function test_otp_login_full_flow_issues_token_and_verifies_phone(): void
    {
        $fake = $this->fakeGateway();

        $user = User::create([
            'name' => 'کاربر پیامکی',
            'email' => 'otp@example.com',
            'phone' => '09120000010',
            'password' => 'StrongPass123!',
            'status' => true,
        ]);

        $this->postJson('/api/auth/otp/request', ['phone' => $user->phone])->assertOk();
        $this->assertDatabaseCount('otp_codes', 1);

        $code = $fake->lastCode();
        $this->assertNotNull($code);

        $response = $this->postJson('/api/auth/otp/verify', [
            'phone' => $user->phone,
            'code' => $code,
        ]);

        $response->assertOk()->assertJsonStructure(['user', 'token']);
        $this->assertNotNull($user->fresh()->phone_verified_at);
    }

    public function test_otp_login_rejects_wrong_code(): void
    {
        $fake = $this->fakeGateway();

        $user = User::create([
            'name' => 'کاربر پیامکی',
            'email' => 'otp2@example.com',
            'phone' => '09120000011',
            'password' => 'StrongPass123!',
            'status' => true,
        ]);

        $this->postJson('/api/auth/otp/request', ['phone' => $user->phone])->assertOk();
        $code = $fake->lastCode();
        $wrong = $code === '00000' ? '11111' : '00000';

        $this->postJson('/api/auth/otp/verify', [
            'phone' => $user->phone,
            'code' => $wrong,
        ])->assertStatus(422);

        $this->assertNull($user->fresh()->phone_verified_at);
    }

    public function test_authenticated_user_can_verify_own_phone(): void
    {
        $fake = $this->fakeGateway();

        $user = User::create([
            'name' => 'کاربر تایید شماره',
            'email' => 'verify@example.com',
            'phone' => '09120000012',
            'password' => 'StrongPass123!',
            'status' => true,
        ]);

        Sanctum::actingAs($user);

        $this->postJson('/api/profile/phone/otp/request')->assertOk();
        $code = $fake->lastCode();

        $this->postJson('/api/profile/phone/otp/verify', ['code' => $code])
            ->assertOk();

        $this->assertNotNull($user->fresh()->phone_verified_at);
    }

    public function test_checkout_can_require_a_verified_phone(): void
    {
        config(['otp.require_for_order' => true]);

        $user = User::create([
            'name' => 'کاربر بدون تایید',
            'email' => 'unverified@example.com',
            'phone' => '09120000013',
            'password' => 'StrongPass123!',
            'status' => true,
        ]);
        $address = Address::create([
            'user_id' => $user->id,
            'receiver_name' => 'کاربر',
            'phone' => $user->phone,
            'province' => 'تهران',
            'city' => 'تهران',
            'address' => 'خیابان آزمایشی',
            'postal_code' => '1234567890',
        ]);

        Sanctum::actingAs($user);

        $response = $this->postJson('/api/checkout', [
            'address_id' => $address->id,
            'shipping_method' => 'standard',
        ]);

        $response->assertStatus(422)->assertJson(['code' => 'PHONE_NOT_VERIFIED']);
    }
}
