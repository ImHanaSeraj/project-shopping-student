const BACKEND_API = (process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api').replace(/\/$/, '');
export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if(req.method!=='POST'){
    res.setHeader('Allow','POST');
    return res.status(405).json({success:false,error:{message:'Method Not Allowed'}});
  }
  try{
    const chunks=[]; for await(const chunk of req) chunks.push(Buffer.from(chunk));
    const body=Buffer.concat(chunks);
    const headers={Accept:'application/json','Content-Type':req.headers['content-type']||'application/octet-stream','Content-Length':String(body.length)};
    if(req.headers.authorization) headers.Authorization=req.headers.authorization;
    const response=await fetch(`${BACKEND_API}/admin/products/upload-image`,{method:'POST',headers,body,cache:'no-store'});
    const text=await response.text(); let payload;
    try{payload=JSON.parse(text)}catch{payload={success:false,error:{message:'پاسخ نامعتبر از سرور'}}}
    return res.status(response.status).json(payload);
  }catch{
    return res.status(502).json({success:false,error:{message:'ارتباط با سرور فروشگاه برقرار نشد.'}});
  }
}
