<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ErrorHandlingTest extends TestCase
{
    use RefreshDatabase;

    public function test_api_errors_use_standard_json_envelope_without_trace(): void
    {
        config(['app.debug' => false]);

        $response = $this->getJson('/api/this-route-does-not-exist');

        $response->assertNotFound()
            ->assertJsonPath('success', false)
            ->assertJsonPath('error.code', 'HTTP_ERROR')
            ->assertJsonMissingPath('trace')
            ->assertJsonMissingPath('exception');
    }

    public function test_validation_error_uses_standard_envelope(): void
    {
        $response = $this->postJson('/api/auth/register', []);

        $response->assertStatus(422)
            ->assertJsonPath('success', false)
            ->assertJsonPath('error.code', 'VALIDATION_ERROR')
            ->assertJsonStructure(['success', 'error' => ['code', 'message', 'details']]);
    }

    public function test_production_mode_does_not_expose_exception_message(): void
    {
        config(['app.debug' => false]);

        $this->app->bind(\App\Http\Controllers\Api\HealthController::class, function () {
            return new class {
                public function __invoke()
                {
                    throw new \RuntimeException('SECRET_PASSWORD_DO_NOT_EXPOSE');
                }
            };
        });

        $response = $this->getJson('/api/health');

        $response->assertStatus(500)
            ->assertJsonPath('success', false)
            ->assertJsonPath('error.code', 'SERVER_ERROR')
            ->assertJsonPath('error.message', 'خطای داخلی سرور رخ داده است.')
            ->assertJsonMissing(['SECRET_PASSWORD_DO_NOT_EXPOSE']);
    }
}
