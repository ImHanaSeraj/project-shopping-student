<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Support\CatalogCache;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $perPage = (int) min(max((int) $request->input('per_page', 12), 1), 48);
        $version = CatalogCache::version();
        $cacheKey = 'public-products:' . sha1($request->fullUrl() . '|pp:' . $perPage) . ':v' . $version;

        $paginator = Cache::remember($cacheKey, now()->addSeconds(15), function () use ($request, $perPage) {
            $q = Product::query()->select([
                'id','name','slug','short_description','price','discount_price','stock','SKU',
                'category_id','brand_id','status','featured','created_at'
            ])->where('status', true)
                ->with([
                    'images' => fn ($i) => $i->select('id','product_id','image','is_primary','sort_order')->orderBy('sort_order'),
                    'category:id,name,slug',
                    'brand:id,name,slug',
                ]);

            if ($request->filled('search')) {
                $search = trim($request->search);
                $q->where(function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('short_description', 'like', "%{$search}%")
                        ->orWhere('SKU', 'like', "%{$search}%")
                        ->orWhereHas('brand', fn ($b) => $b->where('name', 'like', "%{$search}%"))
                        ->orWhereHas('category', fn ($c) => $c->where('name', 'like', "%{$search}%"));
                });
            }

            $this->whereAny($q, $request, 'category', 'category_id');
            $this->whereAny($q, $request, 'brand', 'brand_id');

            if ($request->filled('min_price')) $q->whereRaw('COALESCE(discount_price, price) >= ?', [(float) $request->min_price]);
            if ($request->filled('max_price')) $q->whereRaw('COALESCE(discount_price, price) <= ?', [(float) $request->max_price]);
            if ($request->input('in_stock') === '1') {
                $q->where(function ($query) {
                    $query->where('stock', '>', 0)->orWhereHas('variants', fn ($v) => $v->where('status', true)->where('stock', '>', 0));
                });
            }

            $variantFilters = [];
            foreach (['color', 'size', 'material'] as $variantFilter) {
                if ($request->filled($variantFilter)) {
                    $variantFilters[] = $variantFilter;
                    $values = (array) $request->input($variantFilter);
                    $q->whereHas('variants', function ($variant) use ($values, $variantFilter) {
                        $names = [
                            'color' => ['رنگ', 'color', 'colour'],
                            'size' => ['سایز', 'size'],
                            'material' => ['جنس پارچه', 'جنس', 'material', 'fabric'],
                        ][$variantFilter];
                        $variant->whereIn('value', $values)->whereIn('name', $names);
                    });
                }
            }
            if ($variantFilters) {
                $q->with(['variants' => fn ($v) => $v->where('status', true)->select('id','product_id','name','value','size','color','price','stock','SKU','image','status')]);
            }

            if ($request->input('feature') === 'featured') $q->where('featured', true);
            if ($request->input('feature') === 'discount') $q->whereNotNull('discount_price')->whereColumn('discount_price', '<', 'price');

            switch ($request->input('sort')) {
                case 'price_low': $q->orderByRaw('COALESCE(discount_price, price) asc'); break;
                case 'price_high': $q->orderByRaw('COALESCE(discount_price, price) desc'); break;
                case 'discount': $q->orderByRaw('(price - COALESCE(discount_price, price)) desc'); break;
                case 'popular': $q->orderByDesc('featured')->orderByDesc('created_at'); break;
                default: $q->orderByDesc('created_at');
            }

            return $q->paginate($perPage)->withQueryString();
        });

        return ProductResource::collection($paginator);
    }

    private function whereAny($query, Request $request, string $input, string $column): void
    {
        if (!$request->filled($input)) return;
        $values = array_values(array_filter((array) $request->input($input), fn ($v) => $v !== null && $v !== ''));
        if ($input === 'category') {
            $ids = collect($values)->filter(fn ($v) => ctype_digit((string) $v))->map(fn ($v) => (int) $v);
            $slugs = collect($values)->reject(fn ($v) => ctype_digit((string) $v))->values();
            if ($slugs->isNotEmpty()) {
                $ids = $ids->merge(\App\Models\Category::whereIn('slug', $slugs)->pluck('id'));
            }
            $query->whereIn($column, $ids->unique()->values()->all());
            return;
        }
        $query->whereIn($column, $values);
    }

    public function show($id)
    {
        $query = Product::query();
        $product = (ctype_digit((string) $id) ? $query->whereKey((int) $id) : $query->where('slug', $id))
            ->where('status', true)
            ->firstOrFail();
        $product->load([
            'images:id,product_id,image,is_primary,sort_order',
            'variants' => fn ($v) => $v->where('status', true)->select('id','product_id','name','value','size','color','price','stock','SKU','image','status'),
            'category:id,name,slug','brand:id,name,slug',
            'reviews' => fn ($r) => $r->where('status', 'approved')->with('user:id,name')->latest()
        ]);
        return new ProductResource($product);
    }

    /**
     * Batch fetch for the "compare products" page: GET /products/compare?ids=1,2,3
     * Returns the same shape as show(), for each id, so the frontend can
     * reuse one comparison table for price/size/color/material/stock.
     */
    public function compare(Request $request)
    {
        $ids = collect(explode(',', (string) $request->query('ids', '')))
            ->map(fn ($id) => trim($id))
            ->filter(fn ($id) => ctype_digit($id))
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->take(4)
            ->values();

        if ($ids->isEmpty()) {
            return ProductResource::collection(collect());
        }

        $products = Product::query()
            ->whereIn('id', $ids)
            ->where('status', true)
            ->with([
                'images:id,product_id,image,is_primary,sort_order',
                'variants' => fn ($v) => $v->where('status', true)
                    ->select('id', 'product_id', 'name', 'value', 'size', 'color', 'price', 'stock', 'SKU', 'image', 'status'),
                'category:id,name,slug',
                'brand:id,name,slug',
                'reviews' => fn ($r) => $r->where('status', 'approved')->select('id', 'product_id', 'rating'),
            ])
            ->get()
            ->sortBy(fn ($product) => $ids->search($product->id))
            ->values();

        return ProductResource::collection($products);
    }

    public function related($id)
    {
        $p = ctype_digit((string) $id) ? Product::findOrFail((int) $id) : Product::where('slug', $id)->firstOrFail();
        return ProductResource::collection(Product::select(['id','name','slug','price','discount_price','stock','SKU','category_id','brand_id','status','featured','created_at'])
            ->with(['images:id,product_id,image,is_primary,sort_order','category:id,name,slug','brand:id,name,slug'])
            ->where('status', true)->where('category_id',$p->category_id)->whereKeyNot($p->id)->latest()->limit(8)->get());
    }
}
