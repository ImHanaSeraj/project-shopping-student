import Orders from '../../views/Orders';
import ProtectedRoute from '../../guards/ProtectedRoute';
export default function OrdersPage(){ return <ProtectedRoute><Orders/></ProtectedRoute>; }
