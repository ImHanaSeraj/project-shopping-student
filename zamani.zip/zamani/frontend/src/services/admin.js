import api from './api';
import { invalidateCache } from './requestCache';

// Storefront reads (getProducts/getCategories in productApi.js) are cached
// client-side for a short TTL. Whenever the admin panel changes a product or
// category, that cache needs to be cleared so the storefront reflects the
// change on the very next visit instead of waiting out the TTL.
const clearCatalogCache = () => invalidateCache('');

const adminSimpleFetch = async (url, options={}) => {
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
  const headers = { Accept:'application/json', ...(token ? {Authorization:`Bearer ${token}`} : {}) };
  let body=options.body;
  if (body !== undefined) { headers['Content-Type']='application/json'; body=JSON.stringify(body); }
  const response=await fetch(url,{method:options.method||'GET',headers,body,cache:'no-store'});
  const payload=await response.json().catch(()=>({}));
  if(!response.ok){const error=new Error(payload?.error?.message||payload?.message||'عملیات انجام نشد.');error.response={status:response.status,data:payload};throw error;}
  return {data:payload};
};

const adminProductFetch = async (url, options={}) => {
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
  const headers = { Accept:'application/json', ...(token ? {Authorization:`Bearer ${token}`} : {}) };
  const isForm = typeof FormData !== 'undefined' && options.body instanceof FormData;
  let body = options.body;
  if (body !== undefined && !isForm) { headers['Content-Type']='application/json'; body=JSON.stringify(body); }
  const response = await fetch(url, { method: options.method || 'GET', headers, body, cache:'no-store' });
  const payload = await response.json().catch(()=>({}));
  if (!response.ok) { const error=new Error(payload?.error?.message || payload?.message || 'عملیات محصول انجام نشد.'); error.response={status:response.status,data:payload}; throw error; }
  return { data: payload };
};


export const adminApi = {
  dashboard: () => api.get('/admin/dashboard'),
  discounts: () => api.get('/admin/discounts'),
  discountProducts: () => api.get('/admin/discount-products'),
  createDiscount: data => api.post('/admin/discounts', data),
  deleteDiscount: id => api.delete(`/admin/discounts/${id}`),
  products: async (params={}) => { const q=new URLSearchParams(); Object.entries(params||{}).forEach(([k,v])=>{const vs=Array.isArray(v)?v:[v];vs.forEach(x=>{if(x!==undefined&&x!==null&&x!=='')q.append(k,String(x));});}); return adminProductFetch(`/api/admin/products${q.toString()?`?${q.toString()}`:''}`); },
  product: id => adminProductFetch(`/api/admin/products/${encodeURIComponent(id)}`),
  createProduct: data => adminProductFetch('/api/admin/products',{method:'POST',body:data}).then(r=>{clearCatalogCache();return r;}),
  updateProduct: (id,data) => adminProductFetch(`/api/admin/products/${encodeURIComponent(id)}`,{method:'PUT',body:data}).then(r=>{clearCatalogCache();return r;}),
  deleteProduct: id => adminProductFetch(`/api/admin/products/${encodeURIComponent(id)}`,{method:'DELETE'}).then(r=>{clearCatalogCache();return r;}),
  toggleProduct: id => adminProductFetch(`/api/admin/products/${encodeURIComponent(id)}`,{method:'PATCH'}).then(r=>{clearCatalogCache();return r;}),
  uploadImage: file => { const f=new FormData(); f.append('image',file); return adminProductFetch('/api/admin/products/upload-image',{method:'POST',body:f}); },
  categories: () => fetch('/api/admin/categories', { headers: { Accept: 'application/json', ...(typeof window !== 'undefined' && localStorage.getItem('token') ? { Authorization: `Bearer ${localStorage.getItem('token')}` } : {}) }, cache: 'no-store' }).then(async r => { const data = await r.json(); if (!r.ok) { const e = new Error(data?.error?.message || 'دریافت دسته‌بندی‌ها انجام نشد.'); e.response = { status:r.status, data }; throw e; } return { data }; }),
  createCategory: async data => { const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null; const isForm = typeof FormData !== 'undefined' && data instanceof FormData; const response = await fetch('/api/admin/categories', { method:'POST', headers:{ Accept:'application/json', ...(token ? {Authorization:`Bearer ${token}`} : {}), ...(!isForm ? {'Content-Type':'application/json'} : {}) }, body:isForm ? data : JSON.stringify(data) }); const payload=await response.json().catch(()=>({})); if(!response.ok){ const e=new Error(payload?.error?.message || payload?.message || 'ذخیره دسته‌بندی انجام نشد.'); e.response={status:response.status,data:payload}; throw e;} clearCatalogCache(); return {data:payload}; },
  uploadCategoryImage: async file => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    const form = new FormData();
    form.append('image', file);
    const response = await fetch('/api/admin/categories/upload-image', {
      method: 'POST',
      headers: { Accept: 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: form,
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data?.error?.message || data?.message || 'آپلود تصویر دسته‌بندی انجام نشد.');
      error.response = { status: response.status, data };
      throw error;
    }
    return { data };
  },
  updateCategory: async (id, data) => { const token=typeof window !== 'undefined' ? localStorage.getItem('token') : null; const isForm=typeof FormData !== 'undefined' && data instanceof FormData; const response=await fetch(`/api/admin/categories/${encodeURIComponent(id)}`, {method:'PUT', headers:{Accept:'application/json', ...(token?{Authorization:`Bearer ${token}`}:{ }), ...(!isForm?{'Content-Type':'application/json'}:{})}, body:isForm?data:JSON.stringify(data)}); const payload=await response.json().catch(()=>({})); if(!response.ok){const e=new Error(payload?.error?.message||payload?.message||'ویرایش دسته‌بندی انجام نشد.');e.response={status:response.status,data:payload};throw e;} clearCatalogCache(); return {data:payload}; },
  deleteCategory: async id => { const token=typeof window !== 'undefined' ? localStorage.getItem('token') : null; const response=await fetch(`/api/admin/categories/${encodeURIComponent(id)}`, {method:'DELETE',headers:{Accept:'application/json', ...(token?{Authorization:`Bearer ${token}`}:{})}}); const payload=await response.json().catch(()=>({})); if(!response.ok){const e=new Error(payload?.error?.message||payload?.message||'حذف دسته‌بندی انجام نشد.');e.response={status:response.status,data:payload};throw e;} clearCatalogCache(); return {data:payload}; },
  brands: () => adminSimpleFetch('/api/admin/brands'),
  createBrand: data => adminSimpleFetch('/api/admin/brands',{method:'POST',body:data}),
  updateBrand: (id,data) => adminSimpleFetch(`/api/admin/brands/${encodeURIComponent(id)}`,{method:'PUT',body:data}),
  deleteBrand: id => adminSimpleFetch(`/api/admin/brands/${encodeURIComponent(id)}`,{method:'DELETE'}),
  orders: (params={}) => api.get('/admin/orders',{params}),
  order: id => api.get(`/admin/orders/${id}`),
  updateOrder: (id,data) => api.patch(`/admin/orders/${id}/status`,data),
  users: (params={}) => api.get('/admin/users',{params}),
  user: id => api.get(`/admin/users/${id}`),
  updateUser: (id,data) => api.patch(`/admin/users/${id}`,data),
  reviews: (params={}) => api.get('/admin/reviews',{params}),
  updateReview: (id,status) => api.patch(`/admin/reviews/${id}/status`,{status}),
  deleteReview: id => api.delete(`/admin/reviews/${id}`),
  settings: () => api.get('/admin/settings'),
  saveSetting: data => api.put('/admin/settings', data),
  deleteSetting: key => api.delete(`/admin/settings/${encodeURIComponent(key)}`),
  ai: (path,data) => api.post(`/admin/ai/${path}`,data),
  supportChatInbox: () => api.get('/admin/support-chat'),
  supportChatConversation: id => api.get(`/admin/support-chat/${id}`),
  supportChatClaim: id => api.post(`/admin/support-chat/${id}/claim`),
  supportChatReply: (id,message) => api.post(`/admin/support-chat/${id}/reply`,{message}),
  supportChatClose: id => api.post(`/admin/support-chat/${id}/close`),
};
