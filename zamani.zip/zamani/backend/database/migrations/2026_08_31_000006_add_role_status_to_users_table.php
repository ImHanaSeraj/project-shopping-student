<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (!Schema::hasColumn('users', 'role')) {
                $table->string('role', 30)->default('customer')->after('password');
            }
            if (!Schema::hasColumn('users', 'status')) {
                $table->boolean('status')->default(true)->after('role');
            }
        });

        // Keep the role/status index idempotent for databases created from
        // older revisions of this project.
        if (Schema::hasColumn('users', 'role') && Schema::hasColumn('users', 'status')) {
            try {
                Schema::table('users', fn (Blueprint $table) => $table->index(['role', 'status'], 'users_role_status_index'));
            } catch (\Throwable) {
                // Index may already exist on an upgraded database.
            }
        }
    }

    public function down(): void
    {
        // Do not remove phone: it belongs to the base users schema and may be
        // used by existing installations.
        if (Schema::hasColumn('users', 'role') && Schema::hasColumn('users', 'status')) {
            try {
                Schema::table('users', function (Blueprint $table) {
                    $table->dropIndex('users_role_status_index');
                });
            } catch (\Throwable) {
                // Nothing to roll back if the index was absent.
            }
        }

        Schema::table('users', function (Blueprint $table) {
            if (Schema::hasColumn('users', 'status')) {
                $table->dropColumn('status');
            }
            if (Schema::hasColumn('users', 'role')) {
                $table->dropColumn('role');
            }
        });
    }
};
