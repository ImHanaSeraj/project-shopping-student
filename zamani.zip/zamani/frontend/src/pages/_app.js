import Head from 'next/head';
import { useRouter } from 'next/router';
import MainLayout from '../layouts/MainLayout';
import NotificationProvider from '../components/notifications/NotificationProvider';
import ScrollToTop from '../components/scroll/ScrollToTop';
import ActiveSectionIndicator from '../components/scroll/ActiveSectionIndicator';
import ChartReveal from '../components/scroll/ChartReveal';
import ScrollRevealSystem from '../components/scroll/ScrollRevealSystem';
import ScrollProgressBar from '../components/scroll/ScrollProgressBar';
import PageTransition from '../components/scroll/PageTransition';
import SharedElementTransition from '../components/scroll/SharedElementTransition';
import ScrollAwareHeader from '../components/scroll/ScrollAwareHeader';
import PremiumUX from '../components/scroll/PremiumUX';
import MasterAnimations from '../components/scroll/MasterAnimations';
import SiteLoader from '../components/scroll/SiteLoader';
import AuthProvider from '../context/AuthContext';
import '../index.css';
import '../App.css';
import '../styles/global.css';
import '../styles/responsive-phase18.css';
import '../styles/responsive-phase20.css';
import '../styles/components.css';
import '../styles/auth.css';
import '../styles/wallet.css';
import '../views/admin/admin.css';
import '../views/admin/advanced.css';
import '../styles/notifications.css';
import '../styles/scroll-to-top.css';
import '../styles/page-transition.css';
import '../styles/reveal-effects.css';
import '../styles/trust-bar.css';
import '../styles/chat-widget.css';

const seo = {
  '/': ['فروشگاه پوشاک زنانه', false], '/products': ['محصولات زنانه', false], '/categories': ['دسته‌بندی‌ها', false],
  '/latest': ['جدیدترین‌ها', false], '/special-offers': ['فروش ویژه', false], '/bestsellers': ['پرفروش‌ترین‌ها', false], '/about': ['درباره زمانی', false], '/contact': ['تماس با ما', false],
  '/guide': ['راهنمای خرید', false], '/shipping': ['شرایط ارسال', false], '/terms': ['قوانین و مقررات', false],
  '/search': ['جستجوی محصولات', true], '/compare': ['مقایسه محصولات', true], '/cart': ['سبد خرید', true], '/checkout': ['تسویه حساب', true], '/wishlist': ['علاقه‌مندی‌ها', true],
  '/login': ['ورود', true], '/register': ['ثبت‌نام', true], '/forgot-password': ['بازیابی رمز عبور', true], '/reset-password': ['تنظیم رمز عبور', true],
  '/account': ['حساب کاربری', true], '/profile': ['پروفایل', true], '/orders': ['سفارش‌ها', true], '/admin': ['مدیریت فروشگاه', true],
  '/payment/result': ['نتیجه پرداخت', true], '/payment/mock': ['پرداخت آزمایشی', true]
};

function RouteMeta() {
  const router = useRouter();
  const path = router.pathname;
  const entry = seo[path] || (path.startsWith('/account/') || path.startsWith('/orders/') || path.startsWith('/categories/') || path.startsWith('/products/') ? null : ['صفحه پیدا نشد', true]);
  if (!entry) return null;
  return <Head><title>{`${entry[0]} | ZAMANI`}</title><meta name="robots" content={entry[1] ? 'noindex,nofollow' : 'index,follow'} /><meta name="description" content="کالکشن زمانی، فروشگاه پوشاک زنانه با طراحی مینیمال، کیفیت و اصالت." /><meta name="theme-color" content="#11100f" /></Head>;
}

export default function App({ Component, pageProps }) {
  return <AuthProvider><NotificationProvider><RouteMeta/><SiteLoader/><MainLayout><ScrollProgressBar /><ScrollAwareHeader /><PageTransition><Component {...pageProps} /></PageTransition><ScrollRevealSystem /><SharedElementTransition /><ActiveSectionIndicator /><ChartReveal /><ScrollToTop /><PremiumUX /><MasterAnimations /></MainLayout></NotificationProvider></AuthProvider>;
}
