import InfoPages from '../views/InfoPages';
export default function Terms(){ return <InfoPages kind="terms"/>; }
