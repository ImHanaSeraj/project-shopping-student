<?php
namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'slug' => $this->slug,
            'description' => $this->description,
            'short_description' => $this->short_description,
            'price' => $this->price,
            'discount_price' => $this->discount_price,
            'stock' => $this->stock,
            'SKU' => $this->SKU,
            'category_id' => $this->category_id,
            'brand_id' => $this->brand_id,
            'category' => $this->whenLoaded('category'),
            'brand' => $this->whenLoaded('brand'),
            'featured' => $this->featured,
            'status' => $this->status,
            'image' => $this->images->first()?->image,
            'image_srcset' => $this->images->first()?->image ? $this->responsiveSources($this->images->first()->image) : null,
            'images' => $this->whenLoaded('images'),
            'variants' => $this->whenLoaded('variants', fn () => $this->variants->map(fn ($variant) => [
                'id' => $variant->id,
                'name' => $variant->name,
                'value' => $variant->value,
                'size' => $variant->size,
                'color' => $variant->color,
                'price' => $variant->price,
                'stock' => $variant->stock,
                'SKU' => $variant->SKU,
                'image' => $variant->image,
                'status' => $variant->status,
            ])),
            'rating' => $this->when(isset($this->rating), $this->rating),
            'reviews_count' => $this->whenLoaded('reviews', fn () => $this->reviews->count()),
            'reviews' => $this->whenLoaded('reviews', fn () => $this->reviews->map(fn ($review) => [
                'id' => $review->id,
                'rating' => $review->rating,
                'comment' => $review->comment,
                'created_at' => $review->created_at,
                'user' => $review->relationLoaded('user') ? ['name' => $review->user?->name] : null,
            ])),
            'created_at' => $this->created_at,
        ];
    }

    private function responsiveSources(string $image): ?array
    {
        if (!preg_match('/^(.*?)(?:-1200)?\.webp(\?.*)?$/i', $image, $m)) return null;
        $base = preg_replace('/-(?:480|768|1200)$/i', '', $m[1]);
        $query = $m[2] ?? '';
        return [
            '480' => $base . '-480.webp' . $query,
            '768' => $base . '-768.webp' . $query,
            '1200' => $base . '-1200.webp' . $query,
        ];
    }
}
