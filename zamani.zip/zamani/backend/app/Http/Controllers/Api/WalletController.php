<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\WalletTopup;
use App\Services\WalletService;
use App\Services\ZarinpalService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RuntimeException;
class WalletController extends Controller {
 public function __construct(private WalletService $wallet, private ZarinpalService $zarinpal){}
 public function show(Request $r){$u=$r->user();return response()->json(['balance'=>$this->wallet->balance($u),'available'=>$this->wallet->available($u),'transactions'=>$this->wallet->history($u)]);}
 public function topup(Request $r){$d=$r->validate(['amount'=>['required','numeric','min:10000','max:500000000']]);$u=$r->user();$top=WalletTopup::create(['user_id'=>$u->id,'amount'=>round((float)$d['amount'],2),'status'=>'pending']);
  if(!config('zarinpal.merchant_id')) return response()->json(['message'=>'درگاه پرداخت برای شارژ کیف پول تنظیم نشده است.'],503);
  try{$z=$this->zarinpal->request((int)$top->amount*10,'شارژ کیف پول زمانی',rtrim(config('app.url'),'/').'/api/wallet/callback?wallet_topup='.$top->id,$u->email,$u->phone);$top->update(['authority'=>$z['authority'],'transaction_id'=>$z['authority'],'status'=>'initiated']);return response()->json(['status'=>'redirect','topup'=>$top,'payment_url'=>$z['url']]);}
  catch(\Throwable $e){$top->update(['status'=>'failed']);return response()->json(['message'=>config('app.debug')?$e->getMessage():'ارتباط با درگاه پرداخت با خطا مواجه شد.'],502);}
 }
 public function callback(Request $r){$id=$r->integer('wallet_topup');$authority=(string)$r->query('Authority');$top=WalletTopup::find($id);if(!$top)return redirect()->away(config('zarinpal.frontend_result_url').'?status=failed&reason=wallet_topup_not_found');if($authority===''||$top->authority!==$authority)return redirect()->away(config('zarinpal.frontend_result_url').'?status=failed&reason=wallet_authority');
  if(strtoupper((string)$r->query('Status'))!=='OK'){ $top->update(['status'=>'cancelled']); return redirect()->away(config('zarinpal.frontend_result_url').'?status=cancelled&wallet_topup='.$top->id); }
  try{$verified=$this->zarinpal->verify((int)$top->amount*10,$authority);if(in_array($verified['code'],[100,101],true)){DB::transaction(function()use($top,$verified){$t=WalletTopup::whereKey($top->id)->lockForUpdate()->firstOrFail();if($t->status==='paid')return;$t->update(['status'=>'paid','ref_id'=>(string)$verified['ref_id'],'paid_at'=>now()]);$this->wallet->credit($t->user,(float)$t->amount,'topup','شارژ مستقیم کیف پول','topup:'.$t->id);});return redirect()->away(config('zarinpal.frontend_result_url').'?status=success&wallet_topup='.$top->id);}$top->update(['status'=>'failed']);return redirect()->away(config('zarinpal.frontend_result_url').'?status=failed&wallet_topup='.$top->id);}
  catch(\Throwable $e){$top->update(['status'=>'failed']);return redirect()->away(config('zarinpal.frontend_result_url').'?status=failed&wallet_topup='.$top->id);}
 }
}
