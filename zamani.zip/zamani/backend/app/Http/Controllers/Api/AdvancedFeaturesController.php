<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Order;
use App\Models\User;
use App\Models\Warehouse;
use App\Models\Supplier;
use App\Models\ActivityLog;
use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class AdvancedFeaturesController extends Controller {
 public function dashboard(){return response()->json(['success'=>true,'data'=>['revenue'=>Order::where('payment_status','paid')->sum('final_total'),'products'=>Product::count(),'users'=>User::count(),'low_stock'=>Product::where('stock','<=',5)->count(),'warehouses'=>Warehouse::count(),'suppliers'=>Supplier::count(),'unread_messages'=>ContactMessage::whereNull('read_at')->count()]]);}
 public function warehouses(){return response()->json(['success'=>true,'data'=>Warehouse::withCount('products')->latest()->get()]);}
 public function warehouseStore(Request $r){$d=$r->validate(['name'=>'required|string|max:120','code'=>'nullable|string|max:50','address'=>'nullable|string|max:500']);$w=Warehouse::create($d);return response()->json(['success'=>true,'data'=>$w],201);}
 public function warehouseDelete(Warehouse $warehouse){$warehouse->delete();return response()->json(['success'=>true]);}
 public function suppliers(){return response()->json(['success'=>true,'data'=>Supplier::latest()->get()]);}
 public function supplierStore(Request $r){$d=$r->validate(['name'=>'required|string|max:150','phone'=>'nullable|string|max:50','email'=>'nullable|email|max:150','address'=>'nullable|string|max:500']);$s=Supplier::create($d);return response()->json(['success'=>true,'data'=>$s],201);}
 public function supplierDelete(Supplier $supplier){$supplier->delete();return response()->json(['success'=>true]);}
 public function logs(){return response()->json(['success'=>true,'data'=>ActivityLog::latest()->limit(100)->get()]);}
 public function messages(){return response()->json(['success'=>true,'data'=>ContactMessage::latest()->limit(100)->get()]);}
 public function messageRead(ContactMessage $contactMessage){$contactMessage->update(['read_at'=>now()]);return response()->json(['success'=>true]);}
 public function reports(){return response()->json(['success'=>true,'data'=>['orders_by_status'=>Order::select('status',DB::raw('count(*) as total'))->groupBy('status')->get(),'top_products'=>DB::table('order_items')->select('product_id',DB::raw('SUM(quantity) as sold'))->groupBy('product_id')->orderByDesc('sold')->limit(10)->get(),'inventory'=>Product::select('id','name','stock')->orderBy('stock')->limit(20)->get()]]);}
}
