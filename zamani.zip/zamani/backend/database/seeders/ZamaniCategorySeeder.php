<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class ZamaniCategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'مانتو', 'slug' => 'manto', 'image' => '/images/categories/categories 1.png'],
            ['name' => 'شومیز', 'slug' => 'shomiz', 'image' => '/images/categories/categories 2.png'],
            ['name' => 'پیراهن', 'slug' => 'pirahan', 'image' => '/images/categories/categories 3.png'],
            ['name' => 'شلوار', 'slug' => 'shalvar', 'image' => '/images/categories/categories 4.png'],
            ['name' => 'لباس مجلسی', 'slug' => 'lebas-majlesi', 'image' => '/images/categories/categories 5.png'],
            ['name' => 'ست زنانه', 'slug' => 'set-zananeh', 'image' => '/images/categories/categories 6.png'],
            ['name' => 'لباس زیر و تاپ', 'slug' => 'lebas-zir-top', 'image' => '/images/categories/categories 7.png'],
            ['name' => 'جوراب', 'slug' => 'jorab', 'image' => '/images/categories/categories 8.png'],
        ];

        foreach ($categories as $category) {
            Category::updateOrCreate(
                ['slug' => $category['slug']],
                [
                    'name' => $category['name'],
                    'image' => $category['image'],
                    'parent_id' => null,
                    'status' => true,
                ]
            );
        }
    }
}
