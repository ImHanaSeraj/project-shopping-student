const BACKEND_API = (process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api').replace(/\/$/, '');
export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (!['GET','PUT','DELETE','PATCH'].includes(req.method)) {
    res.setHeader('Allow','GET, PUT, DELETE, PATCH');
    return res.status(405).json({success:false,error:{message:'Method Not Allowed'}});
  }
  try {
    const id=encodeURIComponent(req.query.id);
    const suffix=req.method==='PATCH' ? '/toggle' : '';
    const headers={Accept:'application/json'};
    if(req.headers.authorization) headers.Authorization=req.headers.authorization;
    let body;
    if(req.method==='PUT' || req.method==='PATCH'){
      const chunks=[]; for await(const chunk of req) chunks.push(Buffer.from(chunk));
      body=Buffer.concat(chunks);
      if(req.headers['content-type']) headers['Content-Type']=req.headers['content-type'];
    }
    const response=await fetch(`${BACKEND_API}/admin/products/${id}${suffix}`,{method:req.method,headers,body,cache:'no-store'});
    const text=await response.text(); let payload;
    try{payload=JSON.parse(text)}catch{payload={success:false,error:{message:'پاسخ نامعتبر از سرور'}}}
    return res.status(response.status).json(payload);
  } catch {
    return res.status(502).json({success:false,error:{message:'ارتباط با سرور فروشگاه برقرار نشد.'}});
  }
}
