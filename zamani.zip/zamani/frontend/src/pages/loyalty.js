import Loyalty from '../views/Loyalty';
export default Loyalty;
