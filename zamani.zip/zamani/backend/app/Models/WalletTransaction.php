<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class WalletTransaction extends Model {
 use HasFactory;
 protected $fillable=['user_id','order_id','amount','balance_after','type','description','reference'];
 protected $casts=['amount'=>'decimal:2','balance_after'=>'decimal:2'];
 public function user(){return $this->belongsTo(User::class);} public function order(){return $this->belongsTo(Order::class);}
}
