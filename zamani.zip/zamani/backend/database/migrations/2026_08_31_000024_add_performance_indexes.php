<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('products', function (Blueprint $table) {
            $table->index(['status', 'created_at']);
        });
        Schema::table('orders', function (Blueprint $table) {
            $table->index(['user_id', 'created_at']);
            $table->index(['status', 'created_at']);
        });
        Schema::table('payments', function (Blueprint $table) {
            $table->index(['status', 'created_at']);
        });
    }
    public function down(): void {
        Schema::table('products', fn (Blueprint $table) => $table->dropIndex(['status', 'created_at']));
        Schema::table('orders', function (Blueprint $table) {
            $table->dropIndex(['user_id', 'created_at']);
            $table->dropIndex(['status', 'created_at']);
        });
        Schema::table('payments', fn (Blueprint $table) => $table->dropIndex(['status', 'created_at']));
    }
};
