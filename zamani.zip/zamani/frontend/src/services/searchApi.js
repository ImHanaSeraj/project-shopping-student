import api from './api';

export const searchStore = (query, params = {}) => api.get('/search', { params: { q: query, ...params } });
