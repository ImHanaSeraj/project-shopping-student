import React, { useState } from 'react';
import { Link, useNavigate } from '../utils/routerCompat';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function Register() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ name: '', phone: '', email: '', password: '', password_confirmation: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const change = (e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await api.post('/auth/register', form);
      login(response.data.user, response.data.token);
      navigate('/profile', { replace: true });
    } catch (err) {
      if (!err.response) setError('ارتباط با سرویس فروشگاه برقرار نشد. لطفاً دوباره تلاش کنید.');
      else if (err.response.status === 422) {
        const messages = Object.values(err.response.data?.errors || {}).flat();
        setError(messages[0] || 'اطلاعات ثبت‌نام صحیح نیست.');
      } else setError(err.response.data?.message || 'ثبت‌نام انجام نشد.');
    } finally { setLoading(false); }
  };

  return (
    <div className="auth">
      <form onSubmit={submit} noValidate>
        <h1>ZAMANI</h1>
        <p className="auth-subtitle">ساخت حساب کاربری</p>
        {error && <div className="auth-error" role="alert">{error}</div>}
        <input name="name" value={form.name} placeholder="نام و نام خانوادگی" onChange={change} required />
        <input name="phone" value={form.phone} placeholder="شماره موبایل" onChange={change} required />
        <input name="email" value={form.email} type="email" placeholder="ایمیل" onChange={change} required />
        <input name="password" value={form.password} type="password" placeholder="رمز عبور" onChange={change} autoComplete="new-password" required />
        <input name="password_confirmation" value={form.password_confirmation} type="password" placeholder="تکرار رمز عبور" onChange={change} autoComplete="new-password" required />
        <button type="submit" disabled={loading}>{loading ? 'در حال ثبت‌نام...' : 'ایجاد حساب'}</button>
        <div className="auth-links">
          <Link to="/login">قبلاً حساب دارید؟ <strong>وارد شوید</strong></Link>
          <Link to="/">بازگشت به فروشگاه</Link>
        </div>
      </form>
    </div>
  );
}
