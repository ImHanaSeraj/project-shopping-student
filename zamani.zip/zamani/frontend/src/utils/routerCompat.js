import NextLink from 'next/link';
import { useRouter as useNextRouter } from 'next/router';
import { useCallback, useEffect, useMemo } from 'react';

export function useNavigate() {
  const router = useNextRouter();
  return useCallback((href, options = {}) => {
    const target = typeof href === 'string' ? href : href?.pathname || '/';
    const current = (typeof window !== 'undefined' ? `${window.location.pathname}${window.location.search}` : (router.asPath || '/'));
    const normalize = (value) => {
      const path = String(value || '/').split('#')[0];
      const [pathname, query = ''] = path.split('?');
      const normalizedPath = pathname.length > 1 ? pathname.replace(/\/$/, '') : pathname;
      return `${normalizedPath}${query ? `?${query}` : ''}`;
    };

    // Next.js throws when push/replace is requested for the exact current URL.
    // Match the current URL before navigating so compatibility hooks behave
    // like React Router's navigate without causing a same-URL hard navigation.
    if (normalize(target) === normalize(current)) return Promise.resolve(false);

    if (options?.replace) return router.replace(target);
    return router.push(target);
  }, [router]);
}

export function useLocation() {
  const router = useNextRouter();
  return useMemo(() => {
    const asPath = router.asPath || '/';
    const hashIndex = asPath.indexOf('#');
    const hash = hashIndex >= 0 ? asPath.slice(hashIndex) : '';
    const withoutHash = hashIndex >= 0 ? asPath.slice(0, hashIndex) : asPath;
    const queryIndex = withoutHash.indexOf('?');
    const pathname = queryIndex >= 0 ? withoutHash.slice(0, queryIndex) : withoutHash;
    const search = queryIndex >= 0 ? withoutHash.slice(queryIndex) : '';
    return { pathname, search, hash };
  }, [router.asPath]);
}

export function useParams() {
  const router = useNextRouter();
  return router.query || {};
}

function currentSearchParams(router) {
  const asPath = router.asPath || '';
  const query = asPath.split('?')[1]?.split('#')[0] || '';
  return new URLSearchParams(query);
}

function buildUrl(router, value) {
  if (value instanceof URLSearchParams) {
    const query = value.toString();
    return `${router.pathname}${query ? `?${query}` : ''}`;
  }
  const params = new URLSearchParams();
  Object.entries(value || {}).forEach(([key, val]) => {
    if (val == null || val === '') return;
    if (Array.isArray(val)) val.forEach(v => params.append(key, String(v)));
    else params.set(key, String(val));
  });
  const query = params.toString();
  return `${router.pathname}${query ? `?${query}` : ''}`;
}

export function useSearchParams() {
  const router = useNextRouter();
  const params = useMemo(() => currentSearchParams(router), [router.asPath]);
  const setParams = useCallback((value, options = {}) => {
    const href = buildUrl(router, value);
    if (options?.replace) return router.replace(href, undefined, { shallow: true, scroll: false });
    return router.push(href, undefined, { shallow: true, scroll: false });
  }, [router]);
  return [params, setParams];
}

export function Navigate({ to, replace = false }) {
  const router = useNextRouter();
  const target = typeof to === 'string' ? to : to?.pathname || '/';
  const useReplace = replace || Boolean(to?.replace);

  useEffect(() => {
    const current = typeof window !== 'undefined'
      ? `${window.location.pathname}${window.location.search}`
      : (router.asPath || '/');

    const normalize = (value) => {
      const path = String(value || '/').split('#')[0];
      const [pathname, query = ''] = path.split('?');
      const normalizedPath = pathname.length > 1 ? pathname.replace(/\/$/, '') : pathname;
      return `${normalizedPath}${query ? `?${query}` : ''}`;
    };

    // Never ask Next.js to navigate to the exact URL that is already loaded.
    if (normalize(target) === normalize(current)) return;

    if (useReplace) router.replace(target);
    else router.push(target);
  }, [router, target, useReplace]);
  return null;
}

export function Link({ to, href, replace, children, ...props }) {
  const target = href ?? to ?? '/';
  return <NextLink href={target} replace={replace} {...props}>{children}</NextLink>;
}
