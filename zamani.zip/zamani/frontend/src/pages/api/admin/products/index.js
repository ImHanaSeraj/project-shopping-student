const BACKEND_API = (process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api').replace(/\/$/, '');
export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (!['GET','POST'].includes(req.method)) {
    res.setHeader('Allow','GET, POST');
    return res.status(405).json({success:false,error:{message:'Method Not Allowed'}});
  }
  try {
    const headers = { Accept:'application/json' };
    if (req.headers.authorization) headers.Authorization = req.headers.authorization;
    let body;
    if (req.method === 'POST') {
      const chunks=[];
      for await (const chunk of req) chunks.push(Buffer.from(chunk));
      body=Buffer.concat(chunks);
      if (req.headers['content-type']) headers['Content-Type']=req.headers['content-type'];
    }
    const query = new URLSearchParams();
    Object.entries(req.query || {}).forEach(([key,value]) => {
      const values=Array.isArray(value)?value:[value];
      values.forEach(v=>{if(v!==undefined&&v!==null&&v!=='') query.append(key,String(v));});
    });
    const url=`${BACKEND_API}/admin/products${query.toString()?`?${query.toString()}`:''}`;
    const response=await fetch(url,{method:req.method,headers,body,cache:'no-store'});
    const text=await response.text(); let payload;
    try{payload=JSON.parse(text)}catch{payload={success:false,error:{message:'پاسخ نامعتبر از سرور'}}}
    res.setHeader('Cache-Control','no-store, max-age=0');
    return res.status(response.status).json(payload);
  } catch {
    return res.status(502).json({success:false,error:{message:'ارتباط با سرور فروشگاه برقرار نشد.'}});
  }
}
