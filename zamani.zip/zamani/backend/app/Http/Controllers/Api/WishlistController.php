<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Models\Wishlist;
use Illuminate\Http\Request;

class WishlistController extends Controller
{
    public function index(Request $request)
    {
        $products = $request->user()->wishlistProducts()
            ->with(['images', 'variants', 'category', 'brand'])
            ->where('status', true)
            ->latest('wishlists.created_at')
            ->paginate(12);

        return ProductResource::collection($products);
    }

    public function store(Request $request, $productId)
    {
        $product = Product::where('status', true)->findOrFail($productId);
        Wishlist::firstOrCreate([
            'user_id' => $request->user()->id,
            'product_id' => $product->id,
        ]);

        return response()->json(['message' => 'محصول به علاقه‌مندی‌ها اضافه شد', 'wishlisted' => true]);
    }

    public function destroy(Request $request, $productId)
    {
        Wishlist::where('user_id', $request->user()->id)
            ->where('product_id', $productId)
            ->delete();

        return response()->json(['message' => 'محصول از علاقه‌مندی‌ها حذف شد', 'wishlisted' => false]);
    }

    public function status(Request $request, $productId)
    {
        return response()->json([
            'wishlisted' => Wishlist::where('user_id', $request->user()->id)
                ->where('product_id', $productId)
                ->exists(),
        ]);
    }
}
