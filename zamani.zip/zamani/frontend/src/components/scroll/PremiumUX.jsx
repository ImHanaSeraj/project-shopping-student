import { useEffect } from 'react';

export default function PremiumUX() {
  useEffect(() => {
    if (typeof window === 'undefined') return undefined;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const cleanups = [];

    const observe = (selector, callback, options = {}) => {
      const seen = new WeakSet();
      const scan = (root = document) => {
        root.querySelectorAll?.(selector).forEach(el => {
          if (seen.has(el)) return;
          seen.add(el);
          callback(el);
        });
      };
      scan();
      const mo = new MutationObserver(mutations => mutations.forEach(m => m.addedNodes.forEach(n => {
        if (n.nodeType === 1) { scan(n); scan(); }
      })));
      mo.observe(document.body, { childList: true, subtree: true });
      cleanups.push(() => mo.disconnect());
    };

    // Tables: tiny stagger, intentionally fast for admin workflows.
    observe('.admin-table-wrap tbody', tbody => {
      if (reduce) return;
      [...tbody.children].forEach((row, i) => {
        row.classList.add('admin-row-reveal');
        row.style.setProperty('--row-delay', `${Math.min(i, 10) * 24}ms`);
      });
    });

    // Section transitions for long landing/home pages.
    if (!reduce && 'IntersectionObserver' in window) {
      const sectionObserver = new IntersectionObserver(entries => entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('section-transition-visible');
      }), { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
      document.querySelectorAll('.home-page > section, .home-page > div > section, .section, .editorial-section, .trust-section, .special-offers-section').forEach(el => {
        el.classList.add('section-transition'); sectionObserver.observe(el);
      });
      cleanups.push(() => sectionObserver.disconnect());
    }

    if (!reduce && finePointer) {
      const cursor = document.createElement('div');
      cursor.className = 'luxury-cursor';
      cursor.innerHTML = '<span class="luxury-cursor-dot"></span><span class="luxury-cursor-ring"></span>';
      document.body.appendChild(cursor);
      let mx = -100, my = -100, rx = -100, ry = -100, frame = null;
      const tick = () => {
        frame = null;
        rx += (mx - rx) * 0.18; ry += (my - ry) * 0.18;
        cursor.style.setProperty('--cursor-x', `${mx}px`); cursor.style.setProperty('--cursor-y', `${my}px`);
        cursor.style.setProperty('--ring-x', `${rx}px`); cursor.style.setProperty('--ring-y', `${ry}px`);
      };
      const move = e => { mx = e.clientX; my = e.clientY; if (frame === null) frame = requestAnimationFrame(tick); };
      const over = e => { if (e.target.closest('a,button,[role="button"]')) cursor.classList.add('is-hover'); else cursor.classList.remove('is-hover'); if (e.target.closest('.product-card')) cursor.classList.add('is-product'); else cursor.classList.remove('is-product'); };
      window.addEventListener('mousemove', move, { passive: true }); window.addEventListener('mouseover', over, { passive: true });
      cleanups.push(() => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseover', over); if (frame) cancelAnimationFrame(frame); cursor.remove(); });

      const magnetic = new WeakSet();
      const attachMagnetic = el => {
        if (magnetic.has(el)) return; magnetic.add(el);
        const move = e => { const r = el.getBoundingClientRect(); const dx=(e.clientX-(r.left+r.width/2))*0.10; const dy=(e.clientY-(r.top+r.height/2))*0.10; el.style.setProperty('--mag-x',`${Math.max(-7,Math.min(7,dx))}px`); el.style.setProperty('--mag-y',`${Math.max(-7,Math.min(7,dy))}px`); };
        const leave = () => { el.style.setProperty('--mag-x','0px'); el.style.setProperty('--mag-y','0px'); };
        el.addEventListener('mousemove', move); el.addEventListener('mouseleave', leave); cleanups.push(()=>{el.removeEventListener('mousemove',move);el.removeEventListener('mouseleave',leave)});
      };
      observe('.hero-actions .btn-primary, .admin-top-actions a, .admin-btn.primary, .checkout-submit, .cart-checkout', attachMagnetic);

      const tilt = new WeakSet();
      const attachTilt = el => {
        if (tilt.has(el)) return; tilt.add(el);
        const move = e => { const r=el.getBoundingClientRect(); const x=(e.clientX-r.left)/r.width-.5; const y=(e.clientY-r.top)/r.height-.5; el.style.setProperty('--tilt-x',`${(-y*2.2).toFixed(2)}deg`); el.style.setProperty('--tilt-y',`${(x*2.2).toFixed(2)}deg`); };
        const leave = () => { el.style.setProperty('--tilt-x','0deg'); el.style.setProperty('--tilt-y','0deg'); };
        el.addEventListener('mousemove',move); el.addEventListener('mouseleave',leave); cleanups.push(()=>{el.removeEventListener('mousemove',move);el.removeEventListener('mouseleave',leave)});
      };
      observe('.product-card', attachTilt);

      const parallax = new WeakSet();
      const attachParallax = card => {
        if (parallax.has(card)) return; parallax.add(card);
        const media=card.querySelector('.product-image-swap'); if(!media) return;
        const move=e=>{const r=media.getBoundingClientRect();const x=(e.clientX-r.left)/r.width-.5;const y=(e.clientY-r.top)/r.height-.5;card.style.setProperty('--img-px',`${(x*4).toFixed(2)}px`);card.style.setProperty('--img-py',`${(y*4).toFixed(2)}px`)};
        const leave=()=>{card.style.setProperty('--img-px','0px');card.style.setProperty('--img-py','0px')};
        card.addEventListener('mousemove',move);card.addEventListener('mouseleave',leave);cleanups.push(()=>{card.removeEventListener('mousemove',move);card.removeEventListener('mouseleave',leave)});
      };
      observe('.product-card', attachParallax);
    }

    return () => cleanups.forEach(fn => fn());
  }, []);
  return null;
}
