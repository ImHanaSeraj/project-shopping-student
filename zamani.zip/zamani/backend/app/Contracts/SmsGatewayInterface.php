<?php

namespace App\Contracts;

interface SmsGatewayInterface
{
    /**
     * Send a text message to a phone number.
     *
     * @throws \RuntimeException with a user-safe Persian message when the
     *         message could not be delivered.
     */
    public function send(string $phone, string $message): void;
}
