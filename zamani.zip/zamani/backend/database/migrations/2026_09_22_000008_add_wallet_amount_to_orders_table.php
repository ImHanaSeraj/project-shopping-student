<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::table('orders', function(Blueprint $t){ $t->decimal('wallet_amount',14,2)->default(0)->after('loyalty_discount'); }); }
 public function down(): void { Schema::table('orders', fn(Blueprint $t)=>$t->dropColumn('wallet_amount')); }
};
