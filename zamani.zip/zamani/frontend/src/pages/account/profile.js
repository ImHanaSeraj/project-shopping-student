import Account from '../../views/Account';
import ProtectedRoute from '../../guards/ProtectedRoute';
export default function AccountProfilePage(){ return <ProtectedRoute><Account/></ProtectedRoute>; }
