import Account from '../../views/Account';
import ProtectedRoute from '../../guards/ProtectedRoute';
export default function AccountPasswordPage(){ return <ProtectedRoute><Account/></ProtectedRoute>; }
