<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\InventoryService;
use App\Services\OrderStatusService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        if (!$user) {
            return response()->json(['message' => 'Unauthenticated'], 401);
        }

        $orders = $user->orders()
            ->with(['items.product.images', 'address', 'payment'])
            ->withCount('items')
            ->latest()
            ->paginate(min(max((int) $request->input('per_page', 10), 1), 50));

        return response()->json($orders);
    }

    public function show(Request $request, Order $order)
    {
        abort_unless((int) $order->user_id === (int) $request->user()->id, 404);

        $order->load(['items.product.images', 'items.variant', 'address', 'payment', 'payments']);

        return response()->json([
            'order' => $order,
            'snapshot' => [
                'customer' => [
                    'name' => $order->customer_name,
                    'email' => $order->customer_email,
                    'phone' => $order->customer_phone,
                ],
                'shipping' => [
                    'receiver_name' => $order->receiver_name,
                    'phone' => $order->receiver_phone,
                    'province' => $order->shipping_province,
                    'city' => $order->shipping_city,
                    'address' => $order->shipping_address,
                    'postal_code' => $order->shipping_postal_code,
                    'method' => $order->shipping_method,
                ],
            ],
            'timeline' => $this->timeline($order),
        ]);
    }


    public function requestReturn(Request $request, Order $order, OrderStatusService $statuses)
    {
        abort_unless((int) $order->user_id === (int) $request->user()->id, 404);

        return DB::transaction(function () use ($order, $statuses) {
            $locked = Order::query()->lockForUpdate()->findOrFail($order->id);

            if ($locked->status !== 'delivered' || $locked->payment_status !== 'paid') {
                abort(422, 'فقط سفارش پرداخت‌شده و تحویل‌شده قابل مرجوعی است.');
            }

            $deliveredAt = $locked->delivered_at;
            if (!$deliveredAt) {
                abort(422, 'زمان تحویل سفارش ثبت نشده است.');
            }

            if ($deliveredAt->copy()->addDays(3)->isPast()) {
                abort(422, 'مهلت مرجوعی این سفارش (۳ روز پس از تحویل) به پایان رسیده است.');
            }

            if ($locked->return_requested_at || $locked->status === 'refund_requested') {
                abort(422, 'برای این سفارش قبلاً درخواست مرجوعی ثبت شده است.');
            }

            try {
                $statuses->transition($locked, 'refund_requested');
            } catch (RuntimeException $e) {
                abort(422, $e->getMessage());
            }

            $locked->return_requested_at = now();
            $locked->payment_status = 'refund_requested';
            $locked->save();

            return response()->json([
                'message' => 'درخواست مرجوعی با موفقیت ثبت شد.',
                'order' => $locked->fresh()->load('items', 'payment'),
                'return_deadline' => $deliveredAt->copy()->addDays(3)->toISOString(),
            ]);
        });
    }

    public function cancel(Request $request, Order $order, OrderStatusService $statuses)
    {
        abort_unless((int) $order->user_id === (int) $request->user()->id, 404);

        return DB::transaction(function () use ($order) {
            $locked = Order::query()->lockForUpdate()->findOrFail($order->id);
            if ($locked->payment_status === 'paid') {
                abort(422, 'سفارش پرداخت‌شده بدون فرآیند استرداد قابل لغو نیست.');
            }
            $payment = $locked->payment;
            if ($payment && $payment->status === 'initiated') {
                abort(422, 'تا زمانی که پرداخت در حال انجام است، سفارش قابل لغو نیست.');
            }
            if (!in_array($locked->status, ['pending', 'awaiting_payment'], true)) {
                abort(422, 'این سفارش دیگر قابل لغو نیست.');
            }

            try {
                $statuses->transition($locked, 'cancelled');
            } catch (\RuntimeException $e) {
                abort(422, $e->getMessage());
            }

            app(InventoryService::class)->release($locked);
            $locked->update(['status' => 'cancelled', 'payment_status' => 'cancelled']);

            return response()->json(['message' => 'سفارش لغو شد.', 'order' => $locked->fresh()->load('items', 'payment')]);
        });
    }

    private function timeline(Order $order): array
    {
        $steps = [
            ['key' => 'pending', 'label' => 'در انتظار ایجاد پرداخت'],
            ['key' => 'awaiting_payment', 'label' => 'در انتظار پرداخت'],
            ['key' => 'paid', 'label' => 'پرداخت شده'],
            ['key' => 'processing', 'label' => 'در حال پردازش'],
            ['key' => 'shipped', 'label' => 'ارسال شده'],
            ['key' => 'delivered', 'label' => 'تحویل شده'],
        ];
        $rank = ['pending' => 0, 'awaiting_payment' => 1, 'paid' => 2, 'processing' => 3, 'shipped' => 4, 'delivered' => 5];
        $current = $rank[$order->status] ?? ($order->payment_status === 'paid' ? 1 : 0);

        return array_map(fn ($step, $i) => $step + [
            'completed' => $i <= $current && !in_array($order->payment_status, ['failed', 'cancelled'], true),
            'current' => $i === $current && !in_array($order->payment_status, ['failed', 'cancelled'], true),
        ], $steps, array_keys($steps));
    }
}
