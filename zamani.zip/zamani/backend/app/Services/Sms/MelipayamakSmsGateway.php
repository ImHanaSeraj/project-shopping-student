<?php

namespace App\Services\Sms;

use App\Contracts\SmsGatewayInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;

/**
 * Sends SMS via Melipayamak (https://melipayamak.com), a common Iranian SMS
 * provider. Configure MELIPAYAMAK_USERNAME, MELIPAYAMAK_PASSWORD and
 * MELIPAYAMAK_FROM (an approved sender line number).
 */
class MelipayamakSmsGateway implements SmsGatewayInterface
{
    public function send(string $phone, string $message): void
    {
        $username = config('otp.melipayamak.username');
        $password = config('otp.melipayamak.password');
        $from = config('otp.melipayamak.from');

        if (!$username || !$password || !$from) {
            Log::error('Melipayamak SMS driver selected but is not fully configured.');
            throw new RuntimeException('سرویس پیامک به‌درستی پیکربندی نشده است.');
        }

        $response = Http::asJson()
            ->timeout(15)
            ->post('https://rest.payamak-panel.com/api/SendSMS/SendSMS', [
                'username' => $username,
                'password' => $password,
                'to' => $phone,
                'from' => $from,
                'text' => $message,
                'isflash' => false,
            ]);

        Log::info('Melipayamak SMS send response', [
            'status' => $response->status(),
            'successful' => $response->successful(),
        ]);

        if (!$response->successful()) {
            throw new RuntimeException('ارسال پیامک ناموفق بود. لطفاً بعداً دوباره تلاش کنید.');
        }
    }
}
