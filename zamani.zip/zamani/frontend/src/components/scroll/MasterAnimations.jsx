import { useEffect } from 'react';

const INTERACTIVE = 'button, a, [role="button"], input, select, textarea';
const TILT = [
  '.category-card', '.trust-card', '.directory-card', '.info-card', '.contact-card',
  '.review-card', '.wishlist-card', '.order-card', '.checkout-card', '.account-panel',
  '.entity-card', '.discount-create-card', '.discount-list-card', '.discount-stat',
  '.admin-panel', '.advanced-card', '.advanced-report', '.search-category-item'
].join(',');

function attachTilt(el, cleanups, reduce, finePointer) {
  if (reduce || !finePointer || el.dataset.masterTilt === 'true') return;
  el.dataset.masterTilt = 'true';
  const move = (event) => {
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    el.style.setProperty('--master-tilt-x', `${(-y * 1.6).toFixed(2)}deg`);
    el.style.setProperty('--master-tilt-y', `${(x * 1.6).toFixed(2)}deg`);
    el.style.setProperty('--master-lift', '-4px');
  };
  const leave = () => {
    el.style.setProperty('--master-tilt-x', '0deg');
    el.style.setProperty('--master-tilt-y', '0deg');
    el.style.setProperty('--master-lift', '0px');
  };
  el.addEventListener('mousemove', move, { passive: true });
  el.addEventListener('mouseleave', leave, { passive: true });
  cleanups.push(() => {
    el.removeEventListener('mousemove', move);
    el.removeEventListener('mouseleave', leave);
  });
}

function addReveal(el) {
  if (!el || el.dataset.masterReveal === 'true') return;
  if (el.closest('header, footer, nav, .mobile-drawer, .search-overlay, [role="dialog"], .admin-sidebar')) return;
  el.dataset.masterReveal = 'true';
  el.classList.add('master-reveal');
}

export default function MasterAnimations() {
  useEffect(() => {
    if (typeof window === 'undefined') return undefined;

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const cleanups = [];
    const root = document.querySelector('.main-content');
    if (!root) return undefined;

    const revealSelector = [
      '.main-content > *',
      '.main-content section', '.main-content article',
      '.main-content .category-card', '.main-content .product-card',
      '.main-content .trust-card', '.main-content .review-card',
      '.main-content .wishlist-card', '.main-content .order-card',
      '.main-content .checkout-card', '.main-content .account-panel',
      '.main-content .info-card', '.main-content .contact-card',
      '.main-content .directory-card', '.main-content .policy-block',
      '.main-content .admin-panel', '.main-content .entity-card',
      '.main-content .discount-create-card', '.main-content .discount-list-card',
      '.main-content .discount-stat', '.main-content .admin-table-wrap',
      '.main-content .advanced-card', '.main-content .advanced-report',
      '.main-content .search-category-item', '.main-content .checkout-section',
      '.main-content .cart-item', '.main-content .mini-order',
      '.main-content .address-card', '.main-content .review-admin'
    ].join(',');

    const staggerParents = [
      '.products-grid', '.product-grid', '.categories-grid', '.category-grid',
      '.category-circle-grid', '.wishlist-grid', '.orders-list', '.cart-list',
      '.entity-grid', '.metric-grid', '.discount-stats', '.low-list',
      '.review-admin-list', '.review-list', '.address-list', '.values-grid',
      '.collection-grid', '.contact-grid', '.faq-list', '.search-category-list'
    ].join(',');

    const scan = (scope = root) => {
      if (scope.nodeType !== 1) return;
      if (scope.matches?.(revealSelector)) addReveal(scope);
      scope.querySelectorAll?.(revealSelector).forEach(addReveal);
      scope.querySelectorAll?.(TILT).forEach(el => attachTilt(el, cleanups, reduce, finePointer));
      scope.querySelectorAll?.(`${INTERACTIVE}`).forEach(el => el.classList.add('master-interactive'));
      scope.querySelectorAll?.(staggerParents).forEach(group => {
        Array.from(group.children).forEach((child, index) => {
          if (!child.classList.contains('master-reveal')) addReveal(child);
          child.style.setProperty('--master-delay', `${Math.min(index * 65, 420)}ms`);
        });
      });
    };

    scan();

    let observer;
    let revealObserver;
    if (!reduce && 'IntersectionObserver' in window) {
      revealObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('master-visible');
          revealObserver.unobserve(entry.target);
        });
      }, { threshold: 0.06, rootMargin: '0px 0px -5% 0px' });
      root.querySelectorAll('.master-reveal').forEach(el => revealObserver.observe(el));
    } else {
      root.querySelectorAll('.master-reveal').forEach(el => el.classList.add('master-visible'));
    }

    observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType !== 1) return;
          scan(node);
          if (revealObserver) {
            if (node.classList?.contains('master-reveal')) revealObserver.observe(node);
            node.querySelectorAll?.('.master-reveal').forEach(el => revealObserver.observe(el));
          } else if (reduce) {
            if (node.classList?.contains('master-reveal')) node.classList.add('master-visible');
            node.querySelectorAll?.('.master-reveal').forEach(el => el.classList.add('master-visible'));
          }
        });
      });
    });
    observer.observe(root, { childList: true, subtree: true });

    const clickHandler = (event) => {
      if (reduce) return;
      const target = event.target.closest?.('.master-interactive');
      if (!target || target.closest('[disabled]')) return;
      const rect = target.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.className = 'master-ripple';
      ripple.style.left = `${event.clientX - rect.left}px`;
      ripple.style.top = `${event.clientY - rect.top}px`;
      target.appendChild(ripple);
      window.setTimeout(() => ripple.remove(), 520);
    };
    root.addEventListener('click', clickHandler);
    cleanups.push(() => root.removeEventListener('click', clickHandler));

    return () => {
      observer?.disconnect();
      revealObserver?.disconnect();
      cleanups.forEach(fn => fn());
    };
  }, []);

  return null;
}
