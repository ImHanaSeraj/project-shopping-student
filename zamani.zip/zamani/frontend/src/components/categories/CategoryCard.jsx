import OptimizedImage from '../OptimizedImage';
import { resolveMediaUrl } from '../../utils/media';

export default function CategoryCard({category}){return <div className="category-card"><OptimizedImage src={resolveMediaUrl(category.image)} alt={category.name} /><h3>{category.name}</h3><span>{category.products_count||0} محصول</span></div>}