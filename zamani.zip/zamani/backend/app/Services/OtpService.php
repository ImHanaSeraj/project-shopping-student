<?php

namespace App\Services;

use App\Contracts\SmsGatewayInterface;
use App\Models\OtpCode;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class OtpService
{
    public function __construct(private SmsGatewayInterface $gateway)
    {
    }

    /**
     * Generate, persist and send a one-time code for the given phone/purpose.
     *
     * @throws RuntimeException with a user-safe Persian message when the
     *         request is throttled or delivery fails.
     */
    public function send(string $phone, string $purpose, ?string $ip = null): void
    {
        $resendSeconds = (int) config('otp.resend_seconds', 60);
        $maxPerHour = (int) config('otp.max_requests_per_hour', 5);

        $recent = OtpCode::where('phone', $phone)
            ->where('purpose', $purpose)
            ->latest('id')
            ->first();

        if ($recent && $recent->created_at->gt(now()->subSeconds($resendSeconds))) {
            $wait = max(1, $resendSeconds - now()->diffInSeconds($recent->created_at));
            throw new RuntimeException("لطفاً {$wait} ثانیه دیگر دوباره تلاش کنید.");
        }

        $hourlyCount = OtpCode::where('phone', $phone)
            ->where('purpose', $purpose)
            ->where('created_at', '>=', now()->subHour())
            ->count();

        if ($hourlyCount >= $maxPerHour) {
            throw new RuntimeException('تعداد درخواست‌های شما بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.');
        }

        $length = (int) config('otp.length', 5);
        $code = (string) random_int((int) (10 ** ($length - 1)), (int) (10 ** $length) - 1);
        $ttlSeconds = (int) config('otp.ttl_seconds', 120);

        // The code is only ever persisted if it was actually handed to the
        // gateway successfully, so a failed SMS never leaves a "valid" code
        // the user was never told.
        DB::transaction(function () use ($phone, $purpose, $code, $ttlSeconds, $ip) {
            OtpCode::create([
                'phone' => $phone,
                'purpose' => $purpose,
                'code_hash' => $this->hash($code),
                'attempts' => 0,
                'expires_at' => now()->addSeconds($ttlSeconds),
                'ip_address' => $ip,
            ]);

            $minutes = max(1, (int) round($ttlSeconds / 60));
            $this->gateway->send($phone, "کد تایید کالکشن زمانی: {$code}\nاعتبار: {$minutes} دقیقه");
        });
    }

    /**
     * Verify a code for phone/purpose. Returns true and consumes the code on
     * success. Returns false (never throws) on a wrong/expired/reused code so
     * callers can show one generic "invalid code" message.
     */
    public function verify(string $phone, string $code, string $purpose): bool
    {
        $otp = OtpCode::where('phone', $phone)
            ->where('purpose', $purpose)
            ->whereNull('consumed_at')
            ->latest('id')
            ->first();

        if (!$otp || $otp->expires_at->isPast()) {
            return false;
        }

        $maxAttempts = (int) config('otp.max_attempts', 5);
        if ($otp->attempts >= $maxAttempts) {
            return false;
        }

        if (!hash_equals($otp->code_hash, $this->hash($code))) {
            $otp->increment('attempts');
            return false;
        }

        $otp->update(['consumed_at' => now()]);

        return true;
    }

    private function hash(string $code): string
    {
        return hash_hmac('sha256', $code, (string) config('app.key'));
    }
}
