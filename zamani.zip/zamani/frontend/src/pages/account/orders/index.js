import Orders from '../../../views/Orders';
import ProtectedRoute from '../../../guards/ProtectedRoute';
export default function AccountOrdersPage(){ return <ProtectedRoute><Orders/></ProtectedRoute>; }
