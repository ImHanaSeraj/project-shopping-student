<?php
return [
    'gemini' => [
        'key' => env('GEMINI_API_KEY'),
        'model' => env('GEMINI_MODEL', env('GEMINI_TEXT_MODEL', 'gemini-3.6-flash')),
    ],
];
