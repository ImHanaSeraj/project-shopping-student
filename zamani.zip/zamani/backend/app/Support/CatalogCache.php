<?php

namespace App\Support;

use Illuminate\Support\Facades\Cache;

/**
 * Public product/category listing responses are cached (see CategoryController
 * and ProductController). Because Product/Category writes can happen from the
 * admin panel at any time, those caches need to be invalidated as soon as a
 * product or category is created, updated, deleted, or toggled — otherwise an
 * admin-added product can take up to a few minutes to appear in the storefront
 * category sections.
 *
 * Instead of tracking every individual cache key (not possible with the file
 * cache driver, which doesn't support tags), we keep a single incrementing
 * "catalog version" number. Every cacheable public query includes the current
 * version in its cache key, so bumping the version instantly invalidates all
 * of them without needing to know the exact keys in advance.
 */
class CatalogCache
{
    private const VERSION_KEY = 'catalog_cache_version';

    public static function version(): int
    {
        return (int) Cache::rememberForever(self::VERSION_KEY, fn () => 1);
    }

    public static function bump(): void
    {
        Cache::forever(self::VERSION_KEY, self::version() + 1);
    }
}
