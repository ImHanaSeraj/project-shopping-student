import { useEffect, useState } from 'react';
import Link from '../components/SafeLink';
import SEOHead from '../components/SEOHead';
import Icon from '../components/Icon';
import ProductCard from '../components/products/ProductCard';
import { getProducts, getPublicSettings } from '../services/productApi';

// اگه تنظیم special_offer_end_at در پنل ادمین مقداردهی نشده باشه، این تاریخ پیش‌فرض استفاده میشه.
const DEFAULT_CAMPAIGN_END = '2026-09-21T23:59:59+03:30';

export default function SpecialOffers() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [time, setTime] = useState({ days: '--', hours: '--', minutes: '--', seconds: '--' });

  useEffect(() => {
    let cancelled = false;
    getProducts({ per_page: 24, feature: 'discount', sort: 'discount' }).then(({ data }) => {
      const items = data?.data || data || [];
      if (!cancelled) setProducts(Array.isArray(items) ? items : []);
    }).catch(() => { if (!cancelled) setProducts([]); }).finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let end = new Date(DEFAULT_CAMPAIGN_END).getTime();
    let cancelled = false;
    const format = (n, min = 2) => new Intl.NumberFormat('fa-IR', { minimumIntegerDigits: min, useGrouping: false }).format(n);
    const update = () => {
      const diff = Math.max(0, end - Date.now());
      const total = Math.floor(diff / 1000);
      setTime({
        days: format(Math.floor(total / 86400), 1),
        hours: format(Math.floor((total % 86400) / 3600)),
        minutes: format(Math.floor((total % 3600) / 60)),
        seconds: format(total % 60)
      });
    };
    update();
    const timer = setInterval(update, 1000);

    getPublicSettings().then(({ data }) => {
      const value = data?.data?.special_offer_end_at;
      if (cancelled || !value) return;
      const hasOffset = /[+-]\d{2}:?\d{2}$|Z$/.test(value);
      const parsed = new Date(hasOffset ? value : `${value}:00+03:30`).getTime();
      if (!Number.isNaN(parsed)) { end = parsed; update(); }
    }).catch(() => {});

    return () => { cancelled = true; clearInterval(timer); };
  }, []);

  return <main className="special-offers-page">
    <SEOHead title="فروش ویژه" description="پیشنهادهای زمان‌دار و محصولات تخفیف‌دار فروشگاه زمانی." path="/special-offers" />
    <section className="special-offers-hero container">
      <div className="special-offers-breadcrumb"><Link href="/">خانه</Link><span>/</span><strong>فروش ویژه</strong></div>
      <div className="special-offers-hero-grid">
        <div>
          <h1>فروش ویژه</h1>
          <p>پیشنهادهای منتخب زمانی با تخفیف‌های محدود. این آیتم‌ها تا پایان شمارش معکوس با قیمت ویژه در دسترس هستند.</p>
          <div className="special-countdown" aria-label="زمان باقی‌مانده فروش ویژه">
            <div><strong>{time.days}</strong><span>روز</span></div><i>:</i>
            <div><strong>{time.hours}</strong><span>ساعت</span></div><i>:</i>
            <div><strong>{time.minutes}</strong><span>دقیقه</span></div><i>:</i>
            <div><strong>{time.seconds}</strong><span>ثانیه</span></div>
          </div>
          <div className="special-offers-note"><Icon name="shield" size={16}/> قیمت‌های ویژه تا پایان کمپین معتبرند.</div>
        </div>
        <div className="special-offers-visual"><span>SALE</span><strong>LIMITED</strong><small>SELECTED PIECES</small></div>
      </div>
    </section>

    <section className="section container special-offers-list">
      <div className="section-heading"><div><span className="eyebrow">SPECIAL PRICE</span><h2>پیشنهادهای امروز</h2></div><Link href="/products?feature=discount">همه تخفیف‌ها <Icon name="arrow" size={15}/></Link></div>
      {loading ? <div className="product-grid">{[1,2,3,4,5,6,7,8].map(i => <div className="product-skeleton" key={i}><div className="skeleton-media"/><div className="skeleton-line short"/><div className="skeleton-line"/><div className="skeleton-line price"/></div>)}</div>
        : products.length ? <div className="product-grid">{products.map(product => <ProductCard key={product.id} product={product}/>)}</div>
        : <div className="special-empty"><Icon name="search" size={28}/><h2>فعلاً محصول تخفیف‌داری نداریم</h2><p>به‌زودی پیشنهادهای تازه‌ای برای فروش ویژه اضافه می‌کنیم.</p><Link href="/products" className="btn btn-outline">مشاهده محصولات</Link></div>}
    </section>
  </main>;
}
