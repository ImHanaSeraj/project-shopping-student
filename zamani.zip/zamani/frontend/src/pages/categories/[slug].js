import CategoryDetails from '../../views/CategoryDetails';
export default CategoryDetails;
