import api from './api';
export const getOrders = (params={}) => api.get('/orders', { params });
export const getOrder = (id) => api.get(`/orders/${id}`);
