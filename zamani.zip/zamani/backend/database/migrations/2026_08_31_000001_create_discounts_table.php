<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration{
 public function up(){Schema::create('discounts',function(Blueprint $t){$t->id();$t->foreignId('product_id')->constrained()->cascadeOnDelete();$t->string('type')->default('percent');$t->decimal('value',10,2);$t->date('start_date')->nullable();$t->date('end_date')->nullable();$t->boolean('status')->default(true);$t->timestamps();});}
 public function down(){Schema::dropIfExists('discounts');}
};
