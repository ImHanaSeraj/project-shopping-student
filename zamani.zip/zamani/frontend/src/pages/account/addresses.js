import Account from '../../views/Account';
import ProtectedRoute from '../../guards/ProtectedRoute';
export default function AccountAddressesPage(){ return <ProtectedRoute><Account/></ProtectedRoute>; }
