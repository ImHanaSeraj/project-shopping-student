<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        $categories = [
            7 => [
                'name' => 'لباس زیر و تاپ',
                'slug' => 'lebas-zir-top',
                'image' => '/images/categories/categories 7.png',
            ],
            8 => [
                'name' => 'جوراب',
                'slug' => 'jorab',
                'image' => '/images/categories/categories 8.png',
            ],
        ];

        foreach ($categories as $id => $data) {
            DB::table('categories')->updateOrInsert(
                ['id' => $id],
                array_merge($data, [
                    'parent_id' => null,
                    'status' => 1,
                    'updated_at' => now(),
                    'created_at' => now(),
                ])
            );
        }
    }

    public function down(): void
    {
        DB::table('categories')->whereIn('id', [7, 8])->delete();
    }
};
