import Wishlist from '../views/Wishlist';
import ProtectedRoute from '../guards/ProtectedRoute';
export default function WishlistPage(){ return <ProtectedRoute><Wishlist/></ProtectedRoute>; }
