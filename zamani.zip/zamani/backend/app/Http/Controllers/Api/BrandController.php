<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Illuminate\Support\Facades\Cache;

class BrandController extends Controller
{
    public function index()
    {
        return Cache::remember('public-brands', now()->addMinutes(2), fn () =>
            Brand::select('id','name','slug','logo','description','status')->where('status', true)->withCount('products')->orderBy('name')->get()
        );
    }
}
