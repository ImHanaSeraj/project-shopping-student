<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        $categories = [
            1 => ['name' => 'مانتو', 'slug' => 'manto', 'image' => '/images/categories/categories 1.png'],
            2 => ['name' => 'شومیز', 'slug' => 'shomiz', 'image' => '/images/categories/categories 2.png'],
            3 => ['name' => 'پیراهن', 'slug' => 'pirahan', 'image' => '/images/categories/categories 3.png'],
            4 => ['name' => 'شلوار', 'slug' => 'shalvar', 'image' => '/images/categories/categories 4.png'],
            5 => ['name' => 'لباس مجلسی', 'slug' => 'lebas-majlesi', 'image' => '/images/categories/categories 5.png'],
            6 => ['name' => 'ست زنانه', 'slug' => 'set-zananeh', 'image' => '/images/categories/categories 6.png'],
        ];

        foreach ($categories as $id => $data) {
            DB::table('categories')->updateOrInsert(
                ['id' => $id],
                array_merge($data, [
                    'parent_id' => null,
                    'status' => 1,
                    'updated_at' => now(),
                    'created_at' => now(),
                ])
            );
        }

        // Do not deactivate categories that are not part of this seed list.
        // Admin-created categories live in the same table and must remain active.
    }

    public function down(): void
    {
        DB::table('categories')->whereIn('id', [1,2,3,4,5,6])->delete();
    }
};
