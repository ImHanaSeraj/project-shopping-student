<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\LoyaltyPointTransaction;
use App\Models\User;
use App\Services\LoyaltyService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class LoyaltyAdminController extends AdminBaseController
{
    public function index(Request $request, LoyaltyService $loyalty)
    {
        $this->guardAdmin($request);

        $query = User::query()
            ->select('id', 'name', 'email', 'phone', 'loyalty_points_balance')
            ->withCount(['loyaltyTransactions as loyalty_transactions_count']);

        if ($request->filled('search')) {
            $s = trim($request->input('search'));
            $query->where(fn ($q) => $q
                ->where('name', 'like', "%{$s}%")
                ->orWhere('email', 'like', "%{$s}%")
                ->orWhere('phone', 'like', "%{$s}%"));
        }

        return response()->json([
            'stats' => $loyalty->stats(),
            'rules' => [
                'point_value' => $loyalty->pointValue(),
                'earn_threshold' => $loyalty->earnThreshold(),
            ],
            'users' => $query->orderByDesc('loyalty_points_balance')->paginate(15),
        ]);
    }

    public function adjust(Request $request, $id)
    {
        $this->guardAdmin($request);

        $data = $request->validate([
            'points' => ['required', 'integer', 'not_in:0', 'between:-1000000,1000000'],
            'description' => ['required', 'string', 'max:255'],
        ]);

        return DB::transaction(function () use ($data, $id) {
            $user = User::query()->whereKey($id)->lockForUpdate()->firstOrFail();
            $newBalance = (int) $user->loyalty_points_balance + (int) $data['points'];

            if ($newBalance < 0) {
                throw new RuntimeException('موجودی امتیاز کاربر نمی‌تواند منفی شود.');
            }

            $user->loyalty_points_balance = $newBalance;
            $user->save();

            LoyaltyPointTransaction::create([
                'user_id' => $user->id,
                'type' => 'adjusted',
                'points' => (int) $data['points'],
                'balance_after' => $newBalance,
                'description' => $data['description'],
                'reference' => 'admin:'.auth()->id().':'.now()->format('YmdHisv').':'.$user->id,
            ]);

            return response()->json([
                'message' => 'موجودی امتیاز با موفقیت تغییر کرد.',
                'user' => $user->only(['id','name','email','phone','loyalty_points_balance']),
            ]);
        }, 3);
    }
}
