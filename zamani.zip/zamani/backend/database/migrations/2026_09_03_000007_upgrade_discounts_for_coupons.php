<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::table('discounts', function (Blueprint $table) {
            $table->string('code', 50)->nullable()->after('id');
            $table->decimal('min_purchase', 12, 2)->default(0)->after('end_date');
            $table->decimal('max_discount', 12, 2)->nullable()->after('min_purchase');
            $table->unsignedInteger('usage_limit')->nullable()->after('max_discount');
            $table->unsignedInteger('used_count')->default(0)->after('usage_limit');
            $table->unsignedInteger('per_user_limit')->nullable()->after('used_count');
        });
        Schema::table('discounts', function (Blueprint $table) {
            $table->dropForeign(['product_id']);
            $table->foreignId('product_id')->nullable()->change();
            $table->foreign('product_id')->references('id')->on('products')->nullOnDelete();
            $table->unique('code');
        });
        Schema::create('discount_usages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('discount_id')->constrained('discounts')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->decimal('amount', 12, 2);
            $table->timestamps();
            $table->unique('order_id');
            $table->index(['discount_id','user_id']);
        });
    }
    public function down(): void {
        Schema::dropIfExists('discount_usages');
        Schema::table('discounts', function (Blueprint $table) {
            $table->dropUnique(['code']);
            $table->dropForeign(['product_id']);
            $table->foreignId('product_id')->nullable(false)->change();
            $table->foreign('product_id')->references('id')->on('products')->cascadeOnDelete();
            $table->dropColumn(['code','min_purchase','max_discount','usage_limit','used_count','per_user_limit']);
        });
    }
};
