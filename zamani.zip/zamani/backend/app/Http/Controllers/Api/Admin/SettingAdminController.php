<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Setting;
use Illuminate\Http\Request;

class SettingAdminController extends AdminBaseController
{
    public function index(Request $request)
    {
        $this->guardAdmin($request);

        return response()->json([
            'success' => true,
            'data' => Setting::query()->orderBy('key')->get(['id', 'key', 'value', 'created_at', 'updated_at']),
        ]);
    }

    public function upsert(Request $request)
    {
        $this->guardAdmin($request);

        $validated = $request->validate([
            'key' => ['required', 'string', 'max:100', 'regex:/^[a-zA-Z0-9._-]+$/'],
            'value' => ['nullable', 'string', 'max:10000'],
        ]);

        $setting = Setting::updateOrCreate(
            ['key' => $validated['key']],
            ['value' => $validated['value'] ?? null]
        );

        return response()->json([
            'success' => true,
            'message' => 'تنظیمات با موفقیت ذخیره شد.',
            'data' => $setting,
        ]);
    }

    public function destroy(Request $request, string $key)
    {
        $this->guardAdmin($request);

        $deleted = Setting::where('key', $key)->delete();

        if (!$deleted) {
            return response()->json(['message' => 'تنظیم موردنظر پیدا نشد.'], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'تنظیم با موفقیت حذف شد.',
        ]);
    }
}
