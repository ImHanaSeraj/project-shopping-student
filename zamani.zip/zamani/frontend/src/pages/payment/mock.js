import MockPayment from '../../views/MockPayment';
export default MockPayment;
