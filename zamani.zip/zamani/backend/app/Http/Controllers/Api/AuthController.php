<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Validation\Rules\Password as PasswordRule;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'min:2', 'max:120'],
            'phone' => ['required', 'string', 'max:30', 'unique:users,phone'],
            'email' => ['required', 'email:rfc', 'max:190', 'unique:users,email'],
            'password' => ['required', 'confirmed', PasswordRule::defaults()],
        ]);

        $user = User::create($data);
        $token = $user->createToken($this->tokenName($request))->plainTextToken;

        return response()->json(['user' => $user->fresh(), 'token' => $token], 201);
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'login' => ['required', 'string', 'max:190'],
            'password' => ['required', 'string'],
        ]);

        $user = User::where('email', $data['login'])
            ->orWhere('phone', $data['login'])
            ->first();

        if (!$user || !$user->status || !Hash::check($data['password'], $user->password)) {
            return response()->json(['message' => 'اطلاعات ورود نادرست است.'], 401);
        }

        $token = $user->createToken($this->tokenName($request))->plainTextToken;

        return response()->json(['user' => $user, 'token' => $token]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()?->delete();

        return response()->json(['message' => 'با موفقیت خارج شدید.']);
    }

    public function profile(Request $request)
    {
        return response()->json($request->user());
    }

    public function update(Request $request)
    {
        $user = $request->user();

        $data = $request->validate([
            'name' => ['required', 'string', 'min:2', 'max:120'],
            'phone' => ['required', 'string', 'max:30', 'unique:users,phone,' . $user->id],
            'email' => ['required', 'email:rfc', 'max:190', 'unique:users,email,' . $user->id],
        ]);

        $phoneChanged = $data['phone'] !== $user->phone;

        $user->update($data);

        // The old phone's OTP verification no longer proves ownership of the new number.
        if ($phoneChanged && $user->phone_verified_at) {
            $user->forceFill(['phone_verified_at' => null])->save();
        }

        return response()->json($user->fresh());
    }

    public function password(Request $request)
    {
        $data = $request->validate([
            'current' => ['required', 'string'],
            'password' => ['required', 'confirmed', PasswordRule::defaults()],
        ]);

        $user = $request->user();

        if (!Hash::check($data['current'], $user->password)) {
            return response()->json(['message' => 'رمز عبور فعلی اشتباه است.'], 422);
        }

        $user->update(['password' => $data['password']]);
        $user->tokens()->delete();
        $token = $user->createToken($this->tokenName($request))->plainTextToken;

        return response()->json([
            'message' => 'رمز عبور با موفقیت تغییر کرد.',
            'token' => $token,
        ]);
    }

    public function forgot(Request $request)
    {
        $data = $request->validate(['email' => ['required', 'email:rfc', 'max:190']]);

        $status = Password::sendResetLink(['email' => $data['email']]);

        if ($status === Password::RESET_THROTTLED) {
            return response()->json(['message' => 'اگر اخیراً درخواست داده‌اید، کمی بعد دوباره تلاش کنید.'], 429);
        }

        // Deliberately use the same public response for existing/non-existing emails.
        return response()->json([
            'message' => 'اگر این ایمیل در زمانی ثبت شده باشد، لینک بازیابی برای آن ارسال می‌شود.',
        ]);
    }

    public function reset(Request $request)
    {
        $data = $request->validate([
            'token' => ['required', 'string'],
            'email' => ['required', 'email:rfc', 'max:190'],
            'password' => ['required', 'confirmed', PasswordRule::defaults()],
        ]);

        $status = Password::reset(
            $data,
            function (User $user, string $password) {
                $user->update(['password' => $password]);
                // Invalidate every existing API token after a password reset.
                $user->tokens()->delete();
            }
        );

        if ($status !== Password::PASSWORD_RESET) {
            return response()->json(['message' => 'لینک بازیابی نامعتبر یا منقضی شده است.'], 422);
        }

        return response()->json(['message' => 'رمز عبور با موفقیت تغییر کرد.']);
    }

    private function tokenName(Request $request): string
    {
        return 'web-' . substr(hash('sha256', (string) $request->userAgent()), 0, 16);
    }
}
