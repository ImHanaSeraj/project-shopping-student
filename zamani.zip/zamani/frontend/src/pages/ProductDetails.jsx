import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from '../utils/routerCompat';
import SEOHead, { absoluteUrl } from '../components/SEOHead';
import Icon from '../components/Icon';
import ProductCard from '../components/products/ProductCard';
import { getProduct, getRelatedProducts, submitReview } from '../services/productApi';
import { useAuth } from '../context/AuthContext';
import { addToWishlist, removeFromWishlist, getWishlistStatus } from '../services/wishlist';
import { addCartItem } from '../services/cart';
import { animateToCart } from '../components/cart/CartAnimation';
import { VARIANT_NAMES as variantNames, normalize, variantsByType } from '../utils/variants';
import { isInCompare, toggleCompare, COMPARE_LIMIT } from '../utils/compareStorage';
import { notify } from '../components/UXFeedback';



const formatPrice = value => new Intl.NumberFormat('fa-IR').format(Number(value || 0));

function ProductPlaceholder({ label = 'ZAMANI' }) {
  return <div className="detail-placeholder"><span>{label}</span><small>PRODUCT IMAGE</small></div>;
}

function Stars({ value = 0 }) {
  return <span className="rating-stars" aria-label={`${value} از ۵`}>
    {[1, 2, 3, 4, 5].map(i => <Icon key={i} name="star" size={14} className={i <= Math.round(value) ? 'is-filled' : ''} />)}
  </span>;
}

function Gallery({ images, name }) {
  const [active, setActive] = useState(0);
  const [zoom, setZoom] = useState(false);
  const validImages = (images || []).map(i => typeof i === 'string' ? i : i.image || i.path).filter(Boolean);
  const current = validImages[active];

  useEffect(() => setActive(0), [images]);

  return <div className="product-gallery">
    <div className="gallery-main" data-shared-product-image onClick={() => current && setZoom(true)} role={current ? 'button' : undefined} tabIndex={current ? 0 : undefined} onKeyDown={e => current && e.key === 'Enter' && setZoom(true)}>
      {current ? <img src={current} alt={name} /> : <ProductPlaceholder />}
      {current && <button className="zoom-button" onClick={e => { e.stopPropagation(); setZoom(true); }} aria-label="بزرگ‌نمایی"><Icon name="search" size={18} /></button>}
      <span className="gallery-count">{validImages.length ? `${active + 1} / ${validImages.length}` : 'تصویر محصول'}</span>
    </div>
    <div className="gallery-thumbs">
      {(validImages.length ? validImages : [null, null, null]).map((image, index) => <button key={index} className={`gallery-thumb ${active === index ? 'active' : ''}`} onClick={() => image && setActive(index)} disabled={!image}>
        {image ? <img src={image} alt={`${name} ${index + 1}`} /> : <ProductPlaceholder label="Z" />}
      </button>)}
    </div>
    {zoom && current && <div className="zoom-modal" role="dialog" aria-modal="true" onClick={() => setZoom(false)}>
      <button className="zoom-close" onClick={() => setZoom(false)} aria-label="بستن"><Icon name="x" /></button>
      <img src={current} alt={name} onClick={e => e.stopPropagation()} />
    </div>}
  </div>;
}

export default function ProductDetails() {
  const { slugOrId } = useParams();
  const id = slugOrId;
  const [product, setProduct] = useState(null);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState({});
  const [quantity, setQuantity] = useState(1);
  const { user } = useAuth();
  const [wishlisted, setWishlisted] = useState(false);
  const [wishlistAnimating, setWishlistAnimating] = useState(false);
  const [compared, setCompared] = useState(false);
  const [message, setMessage] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [reviewMessage, setReviewMessage] = useState('');
  const [reviewLoading, setReviewLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (user && id) getWishlistStatus(id).then(r => { if (!cancelled) setWishlisted(Boolean(r?.data?.wishlisted)); }).catch(() => {});
    return () => { cancelled = true; };
  }, [id, user]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    Promise.all([getProduct(id), getRelatedProducts(id).catch(() => ({ data: [] }))])
      .then(([productResponse, relatedResponse]) => {
        if (cancelled) return;
        const raw = productResponse?.data?.data || productResponse?.data || productResponse;
        setProduct(raw || null);
        const rel = relatedResponse?.data?.data || relatedResponse?.data || [];
        setRelated(Array.isArray(rel) ? rel : []);
      })
      .catch(() => {
        if (!cancelled) { setProduct(null); setRelated([]); }
      })
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [id]);

  useEffect(() => {
    if (!product?.id) return;
    setCompared(isInCompare(product.id));
    const sync = () => setCompared(isInCompare(product.id));
    window.addEventListener('zamani-compare-updated', sync);
    return () => window.removeEventListener('zamani-compare-updated', sync);
  }, [product?.id]);

  const handleToggleCompare = () => {
    if (!product?.id) return;
    const { added, limitReached } = toggleCompare(product.id);
    if (limitReached) {
      notify(`حداکثر ${COMPARE_LIMIT} محصول را می‌توانید هم‌زمان مقایسه کنید.`, 'error');
      return;
    }
    setCompared(added);
    notify(added ? 'محصول به مقایسه اضافه شد.' : 'محصول از مقایسه حذف شد.');
  };

  const variants = product?.variants || [];
  const options = useMemo(() => ({
    color: variantsByType(variants, 'color'),
    size: variantsByType(variants, 'size'),
    model: variantsByType(variants, 'model'),
    material: variantsByType(variants, 'material'),
  }), [variants]);

  const reviews = product?.reviews || [];
  const averageRating = reviews.length ? reviews.reduce((sum, r) => sum + Number(r.rating || 0), 0) / reviews.length : Number(product?.rating || 0);
  const hasDiscount = product?.discount_price && Number(product.discount_price) < Number(product.price);
  const discount = hasDiscount ? Math.round((1 - Number(product.discount_price) / Number(product.price)) * 100) : 0;
  // Variants in the database can be stored in either the newer
  // size/color fields or the older name/value format. Normalize both
  // formats here so the selected variant ID is always sent to Laravel.
  const getVariantOption = (variant, type) => {
    if (variant?.[type]) return variant[type];
    const names = variantNames[type] || [];
    return names.includes(normalize(variant?.name)) ? variant?.value : null;
  };

  const modernVariants = variants.filter(v => v.size || v.color);
  const hasModernSelections = Boolean(selected.color || selected.size);
  const matchingModernVariants = modernVariants.filter(v =>
    (!selected.color || normalize(getVariantOption(v, 'color')) === normalize(selected.color)) &&
    (!selected.size || normalize(getVariantOption(v, 'size')) === normalize(selected.size))
  );

  const hasAllModernSelections = modernVariants.length > 0 &&
    ['color', 'size'].every(type => !options[type].length || Boolean(selected[type]));

  // For modern variants, use the exact size/color combination.
  // For legacy variants, use the selected name/value pair instead of
  // sending variant_id=null, which the backend correctly rejects.
  const selectedVariant = modernVariants.length
    ? (hasAllModernSelections ? matchingModernVariants[0] || null : null)
    : (variants.find(v => Object.values(selected).some(value => normalize(v.value) === normalize(value))) ||
       (variants.length === 1 ? variants[0] : null));

  const selectedStock = modernVariants.length
    ? (hasModernSelections
        ? matchingModernVariants.reduce((sum, v) => sum + Number(v.stock || 0), 0)
        : Number(product?.stock || 0))
    : (selectedVariant
        ? Number(selectedVariant.stock || 0)
        : Number(product?.stock || 0));
  const maxQuantity = Math.max(1, selectedStock || 0);

  useEffect(() => { if (quantity > maxQuantity) setQuantity(maxQuantity); }, [maxQuantity, quantity]);

  const choose = (type, value) => setSelected(prev => ({ ...prev, [type]: value }));

  const addToCart = async (event) => {
    if (!user) { window.location.href = `/login?redirect=${encodeURIComponent(`/products/${product.slug || product.id}`)}`; return; }
    const required = ['color', 'size'].filter(type => options[type].length && !selected[type]);
    if (required.length) {
      setMessage('لطفاً گزینه‌های رنگ و سایز را انتخاب کنید.');
      return;
    }
    if (variants.length > 0 && !selectedVariant) {
      setMessage('لطفاً یک تنوع معتبر از محصول را انتخاب کنید.');
      return;
    }
    if (selectedVariant && Number(selectedVariant.stock || 0) <= 0) {
      setMessage('این تنوع محصول ناموجود است.');
      return;
    }
    if (quantity < 1 || quantity > selectedStock) {
      setMessage('تعداد انتخاب‌شده بیشتر از موجودی است.');
      return;
    }
    try {
      await addCartItem(product.id, selectedVariant?.id || null, quantity);
      animateToCart(event?.currentTarget?.closest?.('.detail-actions')?.querySelector?.('.detail-cart-source') || event?.currentTarget, product.image || product.images?.[0]?.image || product.images?.[0]?.path);
      setMessage('محصول با موفقیت به سبد خرید اضافه شد.');
      window.dispatchEvent(new Event('zamani-cart-updated'));
    } catch (e) {
      setMessage(e?.response?.data?.message || 'امکان افزودن محصول به سبد خرید وجود ندارد.');
    }
  };

  const toggleWishlist = async () => {
    if (!user) { window.location.href = `/login?redirect=/products/${product.slug || product.id}`; return; }
    try {
      if (wishlisted) await removeFromWishlist(product.id); else await addToWishlist(product.id);
      setWishlisted(!wishlisted);
      setWishlistAnimating(true);
      window.setTimeout(() => setWishlistAnimating(false), 360);
      const list = JSON.parse(localStorage.getItem('zamani_wishlist') || '[]');
      const next = wishlisted ? list.filter(item => Number(item) !== Number(product.id)) : [...new Set([...list, Number(product.id)])];
      localStorage.setItem('zamani_wishlist', JSON.stringify(next));
      window.dispatchEvent(new Event('zamani-wishlist-updated'));
    } catch (e) { if (e?.response?.status === 401) window.location.href = `/login?redirect=/products/${product.slug || product.id}`; }
  };

  const submit = async e => {
    e.preventDefault();
    setReviewLoading(true); setReviewMessage('');
    try {
      await submitReview(product.id, { rating: reviewRating, comment: reviewText });
      setReviewText(''); setReviewMessage('نظر شما ثبت شد و پس از بررسی نمایش داده می‌شود.');
    } catch (error) {
      setReviewMessage(error?.response?.data?.message || 'برای ثبت نظر ابتدا وارد حساب کاربری شوید.');
    } finally { setReviewLoading(false); }
  };

  if (loading) return <main className="product-details-page"><div className="container detail-loading"><div className="detail-skeleton-media"/><div><div className="detail-skeleton-line long"/><div className="detail-skeleton-line"/><div className="detail-skeleton-line short"/><div className="detail-skeleton-box"/></div></div></main>;
  if (!product) return <main className="container section"><SEOHead title="محصول پیدا نشد" description="محصول موردنظر پیدا نشد." path={`/products/${slugOrId}`} noindex /><div className="empty-panel"><h1>محصول پیدا نشد</h1><p>این محصول حذف شده یا آدرس آن تغییر کرده است.</p><Link className="btn btn-primary" to="/products">بازگشت به محصولات</Link></div></main>;

  const canonicalPath = `/products/${product.slug || product.id}`;
  const canonicalUrl = absoluteUrl(canonicalPath);
  const seoDescription = product.short_description || product.description || `خرید ${product.name} از فروشگاه کالکشن زمانی.`;
  const productPrice = Number(selectedVariant?.price ?? product.discount_price ?? product.price ?? 0);
  const productSchema = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
    description: seoDescription,
    sku: product.SKU || undefined,
    url: canonicalUrl,
    image: (product.images || []).map(img => absoluteUrl(img.image)).filter(Boolean),
    brand: product.brand?.name ? { '@type': 'Brand', name: product.brand.name } : undefined,
    category: product.category?.name || undefined,
    offers: {
      '@type': 'Offer',
      url: canonicalUrl,
      priceCurrency: 'IRR',
      price: Math.round(Number(product.discount_price ?? product.price ?? 0) * 10),
      availability: Number(product.stock || 0) > 0 || variants.some(v => Number(v.stock || 0) > 0)
        ? 'https://schema.org/InStock'
        : 'https://schema.org/OutOfStock',
      seller: { '@type': 'Organization', name: 'ZAMANI' }
    },
    ...(reviews.length ? {
      aggregateRating: { '@type': 'AggregateRating', ratingValue: Number(averageRating.toFixed(1)), reviewCount: reviews.length }
    } : {})
  };
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'خانه', item: absoluteUrl('/') },
      { '@type': 'ListItem', position: 2, name: 'محصولات', item: absoluteUrl('/products') },
      ...(product.category?.name ? [{ '@type': 'ListItem', position: 3, name: product.category.name, item: absoluteUrl(`/products?category=${product.category.id || ''}`) }] : []),
      { '@type': 'ListItem', position: product.category?.name ? 4 : 3, name: product.name, item: canonicalUrl }
    ]
  };

  return <main className="product-details-page">
    <SEOHead title={product.name} description={seoDescription} path={canonicalPath} image={product.image} type="product" schema={{ '@graph': [productSchema, breadcrumbSchema] }} />
    <div className="container">
      <div className="breadcrumb detail-breadcrumb"><Link to="/">خانه</Link><span>/</span><Link to="/products">محصولات</Link><span>/</span><strong>{product.name}</strong></div>
      <section className="product-detail-top">
        <Gallery images={product.images} name={product.name} />
        <div className="product-purchase">
          <div className="detail-kicker">{product.brand?.name || 'ZAMANI'} · {product.category?.name || 'WOMEN'}</div>
          <h1>{product.name}</h1>
          <div className="detail-rating"><Stars value={averageRating} /><strong>{averageRating ? averageRating.toFixed(1) : 'جدید'}</strong><span>({reviews.length} نظر)</span></div>
          <p className="detail-short">{product.short_description || 'طراحی مینیمال، کیفیت دوخت بالا و مناسب برای استایل روزمره و رسمی.'}</p>
          <div className="detail-price"><strong>{formatPrice(productPrice)} <small>تومان</small></strong>{!selectedVariant && hasDiscount && <><del>{formatPrice(product.price)} تومان</del><span>{discount}٪ تخفیف</span></>}{selectedVariant?.price != null && <span className="variant-price-note">قیمت این تنوع</span>}</div>
          <div className={`stock-status ${selectedStock > 0 ? 'in-stock' : 'out-stock'}`}><i/> {selectedStock > 0 ? `موجود · ${formatPrice(selectedStock)} عدد` : 'ناموجود'}</div>
          <div className="detail-meta"><span>SKU</span><strong>{product.SKU || '—'}</strong></div>

          {['color','size','model'].map(type => options[type].length > 0 && <OptionGroup key={type} type={type} values={options[type]} selected={selected[type]} onSelect={v => choose(type, v)} />)}

          <div className="detail-actions">
            <div className="quantity-control"><button onClick={() => setQuantity(q => Math.max(1, q - 1))}>−</button><strong>{quantity}</strong><button onClick={() => setQuantity(q => Math.min(maxQuantity, q + 1))}>+</button></div>
            <button className="btn btn-primary add-cart detail-cart-source" disabled={!selectedStock} onClick={addToCart}><Icon name="bag" size={18}/> افزودن به سبد خرید</button>
            <button className={`wishlist-detail ${wishlisted ? 'active' : ''} ${wishlistAnimating ? 'wishlist-pulse' : ''}`} onClick={toggleWishlist} aria-label="علاقه‌مندی"><Icon name="heart" size={20}/></button>
            <button className={`wishlist-detail compare-detail ${compared ? 'active' : ''}`} onClick={handleToggleCompare} aria-label={compared ? 'حذف از مقایسه' : 'افزودن به مقایسه'}><Icon name="compare" size={20}/></button>
          </div>
          {message && <div className="detail-message">{message}</div>}
          <div className="detail-promises"><span><Icon name="truck"/> ارسال سریع</span><span><Icon name="shield"/> ضمانت اصالت</span><span><Icon name="card"/> پرداخت امن</span></div>
        </div>
      </section>

      <section className="detail-tabs-section">
        <div className="detail-info-grid">
          <InfoBlock title="توضیحات"><p>{product.description || product.short_description || 'این محصول با تمرکز بر فرم، راحتی و دوام طراحی شده است.'}</p></InfoBlock>
          <InfoBlock title="مشخصات"><SpecList product={product}/></InfoBlock>
          <InfoBlock title="نحوه شست‌وشو / نگهداری"><ul className="care-list"><li>شست‌وشوی ملایم و ترجیحاً با آب سرد</li><li>از سفیدکننده استفاده نشود</li><li>در سایه خشک و با حرارت کم اتوکشی شود</li></ul></InfoBlock>
        </div>
        <SizeGuideBlock />
      </section>

      <section className="reviews-section">
        <div className="section-heading"><div><span className="eyebrow">CUSTOMER VOICES</span><h2>نظرات مشتریان</h2></div><span className="reviews-count">{reviews.length} نظر</span></div>
        <div className="reviews-layout">
          <div className="rating-summary"><strong>{averageRating ? averageRating.toFixed(1) : '—'}</strong><Stars value={averageRating}/><span>بر اساس {reviews.length} نظر</span><div className="rating-bars">{[5,4,3,2,1].map(star => { const count = reviews.filter(r => Number(r.rating) === star).length; const width = reviews.length ? (count / reviews.length) * 100 : 0; return <div key={star}><span>{star}</span><i><b style={{width: `${width}%`}}/></i><small>{count}</small></div>; })}</div></div>
          <div className="review-list">{reviews.length ? reviews.map(review => <article className="review-card" key={review.id}><div className="review-head"><strong>{review.user?.name || 'مشتری زمانی'}</strong><Stars value={review.rating}/><time>{review.created_at ? new Date(review.created_at).toLocaleDateString('fa-IR') : ''}</time></div><p>{review.comment || 'بدون متن'}</p></article>) : <div className="no-reviews"><Icon name="star" size={24}/><strong>هنوز نظری ثبت نشده است</strong><span>اولین نفری باشید که تجربه خود را درباره این محصول ثبت می‌کند.</span></div>}</div>
        </div>
        <form className="review-form" onSubmit={submit}><div><span className="eyebrow">WRITE A REVIEW</span><h3>نظر خود را ثبت کنید</h3></div><div className="review-rating-input"><span>امتیاز شما</span>{[1,2,3,4,5].map(i => <button type="button" key={i} className={i <= reviewRating ? 'active' : ''} onClick={() => setReviewRating(i)}><Icon name="star" size={20}/></button>)}</div><textarea value={reviewText} onChange={e => setReviewText(e.target.value)} placeholder="تجربه شما از این محصول..." required/><button className="btn btn-primary" disabled={reviewLoading}>{reviewLoading ? 'در حال ثبت...' : 'ثبت نظر'}</button>{reviewMessage && <p className="review-message">{reviewMessage}</p>}</form>
      </section>

      <section className="related-section"><div className="section-heading"><div><span className="eyebrow">YOU MAY ALSO LIKE</span><h2>محصولات مشابه</h2></div><Link to={`/products?category=${product.category_id || product.category?.id || ''}`}>مشاهده همه <Icon name="arrow" size={15}/></Link></div>{related.length ? <div className="product-grid">{related.slice(0,4).map(item => <ProductCard key={item.id} product={item}/>)}</div> : <div className="related-empty">محصول مشابهی برای نمایش پیدا نشد.</div>}</section>
    </div>
  </main>;
}

function OptionGroup({ type, values, selected, onSelect }) {
  const titles = { color: 'انتخاب رنگ', size: 'انتخاب سایز', model: 'انتخاب مدل' };
  const sizeLabel = value => normalize(value) === 'free size' || normalize(value) === 'free-size' || normalize(value) === 'فری سایز' ? 'Free Size' : value;
  return <div className="option-group"><div className="option-title"><strong>{titles[type]}</strong><span>{selected || 'انتخاب کنید'}</span></div><div className={`option-values ${type === 'color' ? 'color-options' : ''}`}>{values.map(v => <button key={v.value} className={selected === v.value ? 'selected' : ''} onClick={() => onSelect(v.value)}>{type === 'color' && <i className={`swatch swatch-${normalize(v.value)}`}/>}<span>{type === 'size' ? sizeLabel(v.value) : v.value}</span></button>)}</div></div>;
}

function InfoBlock({ title, children }) { return <article className="info-block"><h3>{title}</h3>{children}</article>; }
function SpecList({ product }) { return <dl className="spec-list"><div><dt>برند</dt><dd>{product.brand?.name || '—'}</dd></div><div><dt>دسته</dt><dd>{product.category?.name || '—'}</dd></div><div><dt>SKU</dt><dd>{product.SKU || '—'}</dd></div><div><dt>وضعیت</dt><dd>{Number(product.stock || 0) > 0 ? 'موجود' : 'ناموجود'}</dd></div></dl>; }
function SizeGuideBlock() {
  const table = [
    ['S', '36', '80-84', '62-66', '88-92'],
    ['M', '38', '85-89', '67-71', '93-97'],
    ['L', '40', '90-94', '72-76', '98-102'],
    ['XL', '42', '95-99', '77-81', '103-107'],
  ];
  return <div className="size-table-wrap">
    <div className="section-heading"><div><span className="eyebrow">SIZE & FIT</span><h2>راهنمای خرید</h2></div></div>
    <div className="policy-block">
      <h2>چطور سایز مناسب را اندازه بگیریم؟</h2>
      <p>با یک متر نواری، دور سینه، دور کمر و دور باسن خود را در حالت ایستاده و بدون فشردن متر اندازه بگیرید. سپس عدد به‌دست‌آمده را با جدول سایزبندی زیر مقایسه کنید تا نزدیک‌ترین سایز به بدن خود را پیدا کنید.</p>
    </div>
    <div className="table-wrap">
      <table className="size-table">
        <thead><tr><th>سایز</th><th>سایز ایرانی</th><th>دور سینه</th><th>دور کمر</th><th>دور باسن</th></tr></thead>
        <tbody>{table.map(row => <tr key={row[0]}>{row.map((cell, i) => <td key={i}>{cell}</td>)}</tr>)}</tbody>
      </table>
    </div>
    <div className="policy-block">
      <h2>نکات تکمیلی انتخاب سایز</h2>
      <p>اگر اندازه شما بین دو سایز قرار می‌گیرد، برای لباس‌های رسمی سایز کوچک‌تر و برای لباس‌های روزمره و راحت سایز بزرگ‌تر را انتخاب کنید. توضیحات هر محصول شامل جنس پارچه و میزان کشسانی آن است که در انتخاب سایز مؤثر است.</p>
      <p>در صورت هرگونه تردید، پیش از ثبت سفارش با پشتیبانی زمانی از طریق <Link to="/contact" className="text-link">صفحه تماس با ما <Icon name="arrow" size={13}/></Link> در ارتباط باشید تا شما را در انتخاب دقیق‌تر راهنمایی کنیم.</p>
    </div>
  </div>;
}
