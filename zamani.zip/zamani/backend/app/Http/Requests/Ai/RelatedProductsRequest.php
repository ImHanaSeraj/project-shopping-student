<?php

namespace App\Http\Requests\Ai;

use Illuminate\Foundation\Http\FormRequest;






class RelatedProductsRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'product' => ['required', 'array'],
            'product.id' => ['required'],
            'product.title' => ['required', 'string', 'max:255'],
            'product.category' => ['nullable', 'string', 'max:255'],
            'product.price' => ['nullable'],

            'catalog' => ['required', 'array', 'min:1', 'max:200'],
            'catalog.*.id' => ['required'],
            'catalog.*.title' => ['required', 'string', 'max:255'],
            'catalog.*.category' => ['nullable', 'string', 'max:255'],
            'catalog.*.price' => ['nullable'],

            'limit' => ['nullable', 'integer', 'min:1', 'max:8'],
        ];
    }

    public function messages(): array
    {
        return [
            'product.required' => 'اطلاعات محصول جاری ارسال نشده است.',
            'catalog.required' => 'فهرست محصولات برای مقایسه ارسال نشده است.',
        ];
    }
}
