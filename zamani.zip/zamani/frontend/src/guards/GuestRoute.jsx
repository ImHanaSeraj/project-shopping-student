import { Navigate } from '../utils/routerCompat';
import { useAuth } from "../context/AuthContext";
export default function GuestRoute({children}){
 const {user,loading}=useAuth();
 if(loading) return <div className="auth-loading">در حال بررسی حساب کاربری...</div>;
 return user ? <Navigate to="/profile" replace/> : children;
}
