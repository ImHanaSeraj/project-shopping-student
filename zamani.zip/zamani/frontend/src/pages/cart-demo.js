import CartDemo from '../views/CartDemo';

export default function CartDemoPage() {
  return <CartDemo />;
}
