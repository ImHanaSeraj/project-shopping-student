import { useEffect } from 'react';
import { useRouter } from 'next/router';

const STORAGE_KEY = 'zamani_shared_product_image';

function getPayload() {
  try { return JSON.parse(sessionStorage.getItem(STORAGE_KEY) || 'null'); } catch { return null; }
}

function clearPayload() {
  try { sessionStorage.removeItem(STORAGE_KEY); } catch {}
}

export function startSharedProductImage(event, product, image) {
  if (!image || typeof window === 'undefined') return;
  const clicked = event?.currentTarget;
  const target = clicked?.closest?.('.product-media') || clicked?.closest?.('.product-card')?.querySelector?.('.product-media') || clicked;
  const img = target?.querySelector?.('img');
  if (!img) return;
  const rect = img.getBoundingClientRect();
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({
      image,
      rect: { left: rect.left, top: rect.top, width: rect.width, height: rect.height },
      productId: product?.id || null,
    }));
  } catch {}
}

export default function SharedElementTransition() {
  const router = useRouter();

  useEffect(() => {
    let cancelled = false;
    let cleanupTimer;

    const animate = () => {
      const payload = getPayload();
      if (!payload?.image || !payload?.rect) return;
      clearPayload();

      const source = payload.rect;
      const target = document.querySelector('[data-shared-product-image]');
      if (!target || cancelled) return;

      const targetImg = target.querySelector('img');
      if (!targetImg) return;
      const targetRect = target.getBoundingClientRect();

      const clone = document.createElement('img');
      clone.src = payload.image;
      clone.alt = '';
      clone.setAttribute('aria-hidden', 'true');
      clone.className = 'shared-product-image-clone';
      Object.assign(clone.style, {
        left: `${source.left}px`,
        top: `${source.top}px`,
        width: `${source.width}px`,
        height: `${source.height}px`,
        opacity: '1',
        borderRadius: '0px',
      });
      document.body.appendChild(clone);

      targetImg.style.visibility = 'hidden';
      target.style.overflow = 'hidden';

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (cancelled) return;
          clone.classList.add('is-moving');
          clone.style.left = `${targetRect.left}px`;
          clone.style.top = `${targetRect.top}px`;
          clone.style.width = `${targetRect.width}px`;
          clone.style.height = `${targetRect.height}px`;
          clone.style.borderRadius = getComputedStyle(target).borderRadius || '0px';
        });
      });

      cleanupTimer = window.setTimeout(() => {
        if (clone.parentNode) clone.parentNode.removeChild(clone);
        targetImg.style.visibility = '';
      }, 560);
    };

    const handleComplete = () => window.setTimeout(animate, 35);
    router.events.on('routeChangeComplete', handleComplete);
    animate();

    return () => {
      cancelled = true;
      window.clearTimeout(cleanupTimer);
      router.events.off('routeChangeComplete', handleComplete);
      document.querySelectorAll('.shared-product-image-clone').forEach(el => el.remove());
    };
  }, [router.events]);

  return null;
}
