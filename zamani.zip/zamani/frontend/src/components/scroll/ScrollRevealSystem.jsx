import { useEffect } from 'react';

const REVEAL_SELECTOR = [
  '.main-content > section',
  '.main-content > article',
  '.main-content > .page-section',
  '.main-content > .section',
  '.main-content > .home-page',
  '.main-content > .products-page',
  '.main-content > .product-details-page',
  '.main-content > .search-page',
  '.main-content > .cart-page',
  '.main-content > .wishlist-page',
  '.main-content > .checkout-page',
  '.main-content > .account-page',
  '.main-content > .orders-page',
  '.main-content > .contact-page',
  '.main-content > .inner-page',
  '.main-content > .payment-result',
  '.main-content > .not-found-page',
  '.main-content > .auth',
  '.main-content > .admin-login',
  '.main-content > .advanced-page',
  '.main-content > .products-page > *',
  '.main-content > .account-page > *',
  '.main-content > .checkout-page > *',
  '.main-content > .cart-page > *',
  '.main-content > .wishlist-page > *',
  '.main-content > .orders-page > *',
  '.main-content > .contact-page > *',
  '.main-content > .search-page > *',
  '.main-content > .product-details-page > *',
  '.main-content .hero-content',
  '.main-content .hero-art',
  '.main-content .hero-image',
  '.main-content .hero-slider',
  '.main-content .section-title',
  '.main-content .section-heading',
  '.main-content .inner-page-hero',
  '.main-content .editorial-story',
  '.main-content .policy-block',
  '.main-content .values-grid',
  '.main-content .collection-grid',
  '.main-content .contact-grid',
  '.main-content .faq-section',
  '.main-content .faq-item',
  '.main-content .payment-result-card',
  '.main-content .advanced-card',
  '.main-content .advanced-report',
  '.main-content .section-head',
  '.main-content .categories-grid',
  '.main-content .category-grid',
  '.main-content .category-card',
  '.main-content .products-grid',
  '.main-content .product-grid',
  '.main-content .product-card',
  '.main-content .product-detail-media',
  '.main-content .product-detail-info',
  '.main-content .product-gallery',
  '.main-content .cart-item',
  '.main-content .wishlist-item',
  '.main-content .order-card',
  '.main-content .order-item',
  '.main-content .checkout-section',
  '.main-content form',
  '.main-content .auth-card',
  '.main-content .auth-panel',
  '.main-content .info-card',
  '.main-content .info-section',
  '.main-content .contact-card',
  '.main-content .admin-page .admin-section',
  '.main-content .admin-page .metric',
  '.main-content .admin-page .admin-panel',
  '.main-content .admin-page .discount-stat',
  '.main-content .admin-page .discount-create-card',
  '.main-content .admin-page .discount-list-card',
  '.main-content .admin-page .entity-card',
  '.main-content .admin-page .admin-table-wrap',
  '.main-content .admin-page .admin-toolbar',
  '.main-content .admin-page .admin-loading',
].join(',');

const IMAGE_REVEAL_SELECTOR = [
  '.main-content .product-card .product-media img',
  '.main-content .product-card img',
  '.main-content .product-detail-media img',
  '.main-content .product-gallery img',
  '.main-content .hero-image-main',
  '.main-content .hero-media img',
  '.main-content .editorial-image img',
  '.main-content .banner-image img',
].join(',');

const TEXT_REVEAL_SELECTOR = [
  '.main-content .hero-content h1',
  '.main-content .hero-content h2',
  '.main-content .section-title h1',
  '.main-content .section-title h2',
  '.main-content .section-heading h1',
  '.main-content .section-heading h2',
  '.main-content .section-head h1',
  '.main-content .section-head h2',
  '.main-content .inner-page-hero h1',
  '.main-content .inner-page-hero h2',
  '.main-content .checkout-head h1',
  '.main-content .cart-head h1',
  '.main-content .orders-page h1',
  '.main-content .contact-page h1',
  '.main-content .search-page h1',
  '.main-content .admin-top h1',
  '.main-content .advanced-head h2',
  '.main-content .discounts-intro h2',
].join(',');

const STAGGER_GROUPS = [
  '.categories-grid',
  '.category-grid',
  '.products-grid',
  '.product-grid',
  '.entity-grid',
  '.metric-grid',
  '.discount-stats',
  '.low-list',
];

function isExcluded(element) {
  return element.closest('header, nav, footer, .mobile-drawer, .search-overlay, [role="dialog"], .admin-sidebar') !== null;
}

function markRevealTargets(root) {
  if (!root || root.nodeType !== 1) return [];
  const found = [];
  if (root.matches?.(REVEAL_SELECTOR) && !isExcluded(root)) found.push(root);
  root.querySelectorAll?.(REVEAL_SELECTOR).forEach((element) => {
    if (!isExcluded(element)) found.push(element);
  });

  found.forEach((element) => {
    if (element.dataset.scrollRevealReady === 'true') return;
    element.dataset.scrollRevealReady = 'true';
    element.classList.add('scroll-reveal');
  });
  return found;
}

function setStaggerDelays(root) {
  STAGGER_GROUPS.forEach((selector) => {
    root.querySelectorAll?.(selector).forEach((group) => {
      const children = Array.from(group.children).filter((child) => child.classList.contains('scroll-reveal'));
      children.forEach((child, index) => {
        child.style.setProperty('--scroll-reveal-delay', `${Math.min(index * 55, 330)}ms`);
      });
    });
  });
}


function markImageRevealTargets(root) {
  const found = [];
  if (root.matches?.(IMAGE_REVEAL_SELECTOR) && !isExcluded(root)) found.push(root);
  root.querySelectorAll?.(IMAGE_REVEAL_SELECTOR).forEach((element) => {
    if (!isExcluded(element)) found.push(element);
  });
  found.forEach((element) => {
    if (element.dataset.imageRevealReady === 'true') return;
    element.dataset.imageRevealReady = 'true';
    element.classList.add('image-reveal');

    const revealLoadedImage = () => {
      // A failed image must never stay clipped, so the browser/fallback can remain visible.
      element.classList.add('is-revealed');
    };

    if (element.complete) {
      if (element.naturalWidth > 0) {
        // Let IntersectionObserver handle the normal reveal when possible.
      } else {
        revealLoadedImage();
      }
    } else {
      element.addEventListener('load', revealLoadedImage, { once: true, passive: true });
      element.addEventListener('error', revealLoadedImage, { once: true, passive: true });
    }
  });
  return found;
}

function splitTextNode(node, heading) {
  const text = node.nodeValue || '';
  if (!text.trim()) return;
  const fragment = document.createDocumentFragment();
  const parts = text.split(/(\s+)/);
  parts.forEach((part) => {
    if (/^\s+$/.test(part)) {
      fragment.appendChild(document.createTextNode(part));
      return;
    }
    const word = document.createElement('span');
    word.className = 'text-reveal-word';
    word.textContent = part;
    fragment.appendChild(word);
  });
  node.parentNode.replaceChild(fragment, node);
}

function splitHeadingText(heading) {
  if (!heading || heading.dataset.textRevealReady === 'true') return false;
  if (!heading.textContent.trim()) return false;
  const walker = document.createTreeWalker(heading, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue?.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement?.closest('.text-reveal-word')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    },
  });
  const nodes = [];
  let current;
  while ((current = walker.nextNode())) nodes.push(current);
  nodes.forEach((node) => splitTextNode(node, heading));
  if (!nodes.length) return false;
  heading.dataset.textRevealReady = 'true';
  heading.classList.add('text-reveal');
  return true;
}

function markTextRevealTargets(root) {
  const found = [];
  if (root.matches?.(TEXT_REVEAL_SELECTOR) && !isExcluded(root)) found.push(root);
  root.querySelectorAll?.(TEXT_REVEAL_SELECTOR).forEach((element) => {
    if (!isExcluded(element)) found.push(element);
  });
  found.forEach(splitHeadingText);
  return found.filter((element) => element.dataset.textRevealReady === 'true');
}

export default function ScrollRevealSystem() {
  useEffect(() => {
    if (typeof window === 'undefined' || typeof IntersectionObserver === 'undefined') return undefined;

    const root = document.querySelector('.main-content');
    if (!root) return undefined;

    const targets = markRevealTargets(root);
    const imageTargets = markImageRevealTargets(root);
    const textTargets = markTextRevealTargets(root);
    setStaggerDelays(root);

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        const element = entry.target;
        if (entry.isIntersecting) {
          element.classList.add('is-visible');
          if (element.classList.contains('image-reveal')) element.classList.add('is-revealed');
          if (element.classList.contains('text-reveal')) element.classList.add('is-revealed');
          observer.unobserve(element);
        }
      });
    }, {
      root: null,
      rootMargin: '0px 0px -7% 0px',
      threshold: 0.08,
    });

    [...targets, ...imageTargets, ...textTargets].forEach((element) => observer.observe(element));

    const mutationObserver = new MutationObserver((mutations) => {
      let changed = false;
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === 1) {
            const added = markRevealTargets(node);
            const addedImages = markImageRevealTargets(node);
            const addedText = markTextRevealTargets(node);
            [...added, ...addedImages, ...addedText].forEach((element) => observer.observe(element));
            if (added.length || addedImages.length || addedText.length) changed = true;
          }
        });
      });
      if (changed) setStaggerDelays(root);
    });

    mutationObserver.observe(root, { childList: true, subtree: true });

    // Scroll parallax is applied to inner visual layers, not reveal wrappers.
    // This keeps the existing layout dimensions and reveal transforms untouched.
    const parallaxItems = [
      ...root.querySelectorAll('.hero-image-main'),
      ...root.querySelectorAll('.hero-image-bg'),
      ...root.querySelectorAll('.hero-copy > *'),
      ...root.querySelectorAll('.hero-art-frame, .hero-art-rack'),
      ...root.querySelectorAll('.category-circle img'),
      ...root.querySelectorAll('.editorial-image img, .banner-image img, .hero-media img'),
      ...root.querySelectorAll('[data-scroll-parallax]'),
    ];

    const uniqueParallaxItems = Array.from(new Set(parallaxItems));
    uniqueParallaxItems.forEach((element) => {
      if (!element.dataset.scrollParallaxFactor) {
        const isBackground = element.classList.contains('hero-image-bg');
        const isCopy = element.closest('.hero-copy');
        const isCategory = element.closest('.category-circle');
        element.dataset.scrollParallaxFactor = element.dataset.scrollParallax || (
          isBackground ? '0.018' : isCopy ? '0.012' : isCategory ? '0.022' : '0.032'
        );
      }
    });

    let ticking = false;
    const updateParallax = () => {
      ticking = false;
      const viewportCenter = window.innerHeight * 0.5;
      uniqueParallaxItems.forEach((element) => {
        const rect = element.getBoundingClientRect();
        if (rect.bottom < -120 || rect.top > window.innerHeight + 120) return;
        const factor = Number(element.dataset.scrollParallaxFactor || 0.025);
        const distance = (rect.top + rect.height * 0.5 - viewportCenter) * -factor;
        const limit = element.closest('.hero-copy') ? 8 : 18;
        element.style.setProperty('--scroll-parallax-y', `${Math.max(-limit, Math.min(limit, distance))}px`);
      });
    };
    const onScroll = () => {
      if (!ticking) {
        ticking = true;
        window.requestAnimationFrame(updateParallax);
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    updateParallax();

    return () => {
      observer.disconnect();
      mutationObserver.disconnect();
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  return null;
}
