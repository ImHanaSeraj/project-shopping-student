<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ClothingProductVariantTest extends TestCase
{
    use RefreshDatabase;

    private function admin(): User
    {
        return User::create([
            'name' => 'Admin',
            'email' => 'clothing-admin-' . uniqid() . '@example.com',
            'phone' => '09' . random_int(100000000, 999999999),
            'password' => 'StrongPass123!',
            'role' => 'admin',
            'status' => true,
        ]);
    }

    public function test_admin_can_create_real_clothing_variants_without_seed_data(): void
    {
        Sanctum::actingAs($this->admin());
        $category = Category::create(['name' => 'تیشرت', 'slug' => 'tshirt-test-' . uniqid()]);

        $response = $this->postJson('/api/admin/products', [
            'name' => 'تیشرت تست',
            'slug' => 'tshirt-' . uniqid(),
            'description' => 'محصول تستی برای بررسی Variant.',
            'price' => 500000,
            'discount_price' => null,
            'stock' => 0,
            'SKU' => 'ZM-TEST-' . strtoupper(substr(uniqid(), -6)),
            'category_id' => $category->id,
            'brand_id' => null,
            'status' => true,
            'featured' => false,
            'variants' => [
                ['size' => 'S', 'color' => 'مشکی', 'SKU' => 'ZM-V-S-BLK-' . strtoupper(substr(uniqid(), -5)), 'stock' => 2, 'price' => null, 'status' => true],
                ['size' => 'M', 'color' => 'مشکی', 'SKU' => 'ZM-V-M-BLK-' . strtoupper(substr(uniqid(), -5)), 'stock' => 3, 'price' => null, 'status' => true],
            ],
            'images' => [],
        ])->assertCreated();

        $product = Product::with('variants')->findOrFail($response->json('data.id'));
        $this->assertSame(5, $product->stock);
        $this->assertCount(2, $product->variants);
        $this->assertTrue($product->variants->contains(fn ($v) => $v->size === 'M' && $v->color === 'مشکی' && $v->stock === 3));
    }

    public function test_public_product_exposes_only_active_clothing_variants(): void
    {
        $category = Category::create(['name' => 'پیراهن', 'slug' => 'dress-test-' . uniqid()]);
        $product = Product::create([
            'name' => 'پیراهن تست', 'slug' => 'dress-' . uniqid(), 'price' => 800000,
            'SKU' => 'ZM-P-' . strtoupper(substr(uniqid(), -6)), 'category_id' => $category->id,
            'status' => true, 'stock' => 2,
        ]);
        ProductVariant::create(['product_id' => $product->id, 'name' => 'لباس', 'value' => 'مشکی / M', 'size' => 'M', 'color' => 'مشکی', 'stock' => 2, 'SKU' => 'ZM-A-' . strtoupper(substr(uniqid(), -5)), 'status' => true]);
        ProductVariant::create(['product_id' => $product->id, 'name' => 'لباس', 'value' => 'سفید / L', 'size' => 'L', 'color' => 'سفید', 'stock' => 4, 'SKU' => 'ZM-I-' . strtoupper(substr(uniqid(), -5)), 'status' => false]);

        $this->getJson('/api/products/' . $product->id)
            ->assertSuccessful()
            ->assertJsonCount(1, 'data.variants')
            ->assertJsonPath('data.variants.0.size', 'M')
            ->assertJsonPath('data.variants.0.color', 'مشکی');
    }


    public function test_free_size_variant_can_be_created_and_exposed(): void
    {
        Sanctum::actingAs($this->admin());
        $category = Category::create(['name' => 'شومیز', 'slug' => 'free-size-test-' . uniqid()]);

        $response = $this->postJson('/api/admin/products', [
            'name' => 'شومیز فری سایز', 'slug' => 'free-size-' . uniqid(), 'price' => 650000,
            'stock' => 0, 'SKU' => 'ZM-FS-' . strtoupper(substr(uniqid(), -6)), 'category_id' => $category->id,
            'status' => true, 'variants' => [
                ['size' => 'Free Size', 'color' => 'مشکی', 'SKU' => 'ZM-FS-BLK-' . strtoupper(substr(uniqid(), -5)), 'stock' => 2, 'status' => true],
            ],
        ])->assertCreated();

        $product = Product::with('variants')->findOrFail($response->json('data.id'));
        $this->assertSame(2, $product->stock);
        $this->assertTrue($product->variants->contains(fn ($v) => $v->size === 'Free Size' && $v->color === 'مشکی'));

        $this->getJson('/api/products/' . $product->id)
            ->assertSuccessful()
            ->assertJsonPath('data.variants.0.size', 'Free Size')
            ->assertJsonPath('data.variants.0.color', 'مشکی');
    }

    public function test_duplicate_size_color_combination_is_rejected(): void
    {
        Sanctum::actingAs($this->admin());
        $category = Category::create(['name' => 'هودی', 'slug' => 'hoodie-test-' . uniqid()]);

        $this->postJson('/api/admin/products', [
            'name' => 'هودی تست', 'slug' => 'hoodie-' . uniqid(), 'price' => 900000,
            'stock' => 0, 'SKU' => 'ZM-H-' . strtoupper(substr(uniqid(), -6)), 'category_id' => $category->id,
            'status' => true, 'variants' => [
                ['size' => 'M', 'color' => 'مشکی', 'SKU' => 'ZM-H-1-' . strtoupper(substr(uniqid(), -5)), 'stock' => 1, 'status' => true],
                ['size' => 'M', 'color' => 'مشکی', 'SKU' => 'ZM-H-2-' . strtoupper(substr(uniqid(), -5)), 'stock' => 1, 'status' => true],
            ],
        ])->assertUnprocessable();
    }
}
