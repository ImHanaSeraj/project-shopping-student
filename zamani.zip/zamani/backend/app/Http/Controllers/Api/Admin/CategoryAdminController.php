<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class CategoryAdminController extends AdminBaseController
{
    private function imagePath(?string $value): ?string
    {
        if (!$value) return null;
        $value = trim($value);
        if ($value === '') return null;
        $pos = stripos($value, '/storage/');
        if ($pos !== false) return '/storage/' . ltrim(substr($value, $pos + 9), '/');
        if (preg_match('#^storage/(.+)$#i', ltrim($value, '/'), $m)) return '/storage/' . $m[1];
        return $value;
    }

    private function rules(?Category $category = null): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            // Uniqueness is handled after validation so a duplicate or Persian
            // slug can never prevent an otherwise valid category from saving.
            'slug' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            // Do not use the strict `image` rule here. Some valid browser images
            // are rejected by PHP's image detector although their MIME/extension
            // is valid. mimes + size is enough for this upload endpoint.
            'image' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'parent_id' => ['nullable', 'integer', 'exists:categories,id'],
            'status' => ['nullable', 'boolean'],
        ];
    }

    private function validateCategory(Request $request, ?Category $category = null): array
    {
        // FormData arrives as strings. Normalize these fields before Laravel's
        // boolean/integer validation so both JSON and multipart requests behave
        // identically.
        $status = $request->input('status', '1');
        $request->merge([
            'status' => filter_var($status, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE),
            'parent_id' => blank($request->input('parent_id')) ? null : (int) $request->input('parent_id'),
        ]);

        $rules = $this->rules($category);
        // A category may keep an existing image path when edited, or receive
        // a new uploaded file. Validate the two representations separately.
        $rules['image'] = $request->hasFile('image')
            ? ['nullable', 'file', 'mimes:jpg,jpeg,png,webp', 'max:5120']
            : ['nullable', 'string', 'max:2048'];

        try {
            return $request->validate($rules);
        } catch (ValidationException $e) {
            // The global API handler intentionally uses a generic message. Add
            // field-level details here so the admin UI can tell the real cause.
            throw $e;
        }
    }

    private function makeUniqueSlug(string $name, ?Category $except = null): string
    {
        $base = Str::slug($name);
        if ($base === '') $base = 'category';
        $slug = $base;
        $counter = 2;
        while (Category::where('slug', $slug)
            ->when($except, fn ($q) => $q->where('id', '!=', $except->id))
            ->exists()) {
            $slug = $base . '-' . $counter++;
        }
        return $slug;
    }

    private function present(Category $category): Category
    {
        $category->image = $this->imagePath($category->image);
        if ($category->relationLoaded('children')) {
            $category->setRelation('children', $category->children->map(function ($child) {
                $child->image = $this->imagePath($child->image);
                return $child;
            })->values());
        }
        return $category;
    }

    public function index(Request $request)
    {
        $this->guardAdmin($request);
        return Category::query()
            ->with('parent')
            ->withCount('products')
            ->orderBy('id')
            ->get()
            ->map(fn ($category) => $this->present($category))
            ->values();
    }

    public function uploadImage(Request $request)
    {
        $this->guardAdmin($request);
        $request->validate(['image' => ['required', 'file', 'mimes:jpg,jpeg,png,webp', 'max:5120']]);
        $path = $request->file('image')->store('categories', 'public');
        return response()->json(['url' => '/storage/' . ltrim($path, '/'), 'path' => $path], 201);
    }

    public function store(Request $request): JsonResponse
    {
        $this->guardAdmin($request);
        $data = $this->validateCategory($request);

        // Empty or already-used slugs are generated automatically. The admin
        // should not lose an otherwise valid category merely because a slug is
        // duplicated.
        if (blank($data['slug'] ?? null) || Category::where('slug', $data['slug'])->exists()) {
            $data['slug'] = $this->makeUniqueSlug($data['name']);
        }
        $data['status'] = $data['status'] ?? true;
        $data['parent_id'] = $data['parent_id'] ?? null;

        $uploadedPath = null;
        try {
            $category = DB::transaction(function () use ($request, &$data, &$uploadedPath) {
                if ($request->hasFile('image')) {
                    $uploadedPath = $request->file('image')->store('categories', 'public');
                    $data['image'] = '/storage/' . ltrim($uploadedPath, '/');
                } else {
                    $data['image'] = $this->imagePath($data['image'] ?? null);
                }
                return Category::create($data);
            });
        } catch (\Throwable $e) {
            if ($uploadedPath) Storage::disk('public')->delete($uploadedPath);
            throw $e;
        }

        return response()->json($this->present($category->fresh()->load('parent')), 201);
    }

    public function update(Request $request, $id): JsonResponse
    {
        $this->guardAdmin($request);
        $category = Category::findOrFail($id);
        $data = $this->validateCategory($request, $category);

        if (blank($data['slug'] ?? null) || Category::where('slug', $data['slug'])->where('id', '!=', $category->id)->exists()) {
            $data['slug'] = $this->makeUniqueSlug($data['name'], $category);
        }
        $data['status'] = $data['status'] ?? true;
        $data['parent_id'] = $data['parent_id'] ?? null;

        $oldImage = $category->image;
        $uploadedPath = null;
        try {
            DB::transaction(function () use ($request, &$data, &$uploadedPath, $category) {
                if ($request->hasFile('image')) {
                    $uploadedPath = $request->file('image')->store('categories', 'public');
                    $data['image'] = '/storage/' . ltrim($uploadedPath, '/');
                } else {
                    $data['image'] = $this->imagePath($data['image'] ?? null);
                }
                $category->update($data);
            });
        } catch (\Throwable $e) {
            if ($uploadedPath) Storage::disk('public')->delete($uploadedPath);
            throw $e;
        }

        if ($uploadedPath && $oldImage && preg_match('#^/?storage/(.+)$#i', $oldImage, $m)) {
            Storage::disk('public')->delete($m[1]);
        }

        return response()->json($this->present($category->fresh()->load('parent')));
    }

    public function destroy(Request $request, $id)
    {
        $this->guardAdmin($request);
        $category = Category::findOrFail($id);
        if ($category->products()->exists() || $category->children()->exists()) {
            return response()->json(['message' => 'این دسته دارای محصول یا زیرمجموعه است.'], 422);
        }
        $image = $category->image;
        $category->delete();
        if ($image && preg_match('#^/?storage/(.+)$#i', $image, $m)) Storage::disk('public')->delete($m[1]);
        return ['message' => 'دسته حذف شد.'];
    }
}
