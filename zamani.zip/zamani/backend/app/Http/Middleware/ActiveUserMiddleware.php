<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ActiveUserMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!$request->user() || !$request->user()->status) {
            return response()->json(['message' => 'حساب کاربری غیرفعال است.'], 403);
        }

        return $next($request);
    }
}
