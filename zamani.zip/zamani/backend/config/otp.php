<?php

return [
    // Which gateway actually sends the SMS. 'log' (default) just writes the
    // message to the log so OTP flows work out of the box in local/dev
    // environments without any SMS provider account.
    'driver' => env('SMS_DRIVER', 'log'),

    'sender' => env('SMS_SENDER_NUMBER'),

    // Digits in a generated code.
    'length' => (int) env('OTP_LENGTH', 5),

    // How long a code stays valid after it's sent.
    'ttl_seconds' => (int) env('OTP_TTL_SECONDS', 120),

    // Minimum time a phone/purpose must wait before requesting another code.
    'resend_seconds' => (int) env('OTP_RESEND_SECONDS', 60),

    // Wrong-code attempts allowed against a single generated code.
    'max_attempts' => (int) env('OTP_MAX_ATTEMPTS', 5),

    // OTP requests allowed per phone/purpose per rolling hour.
    'max_requests_per_hour' => (int) env('OTP_MAX_REQUESTS_PER_HOUR', 5),

    // When true, /api/checkout refuses to create an order until the user's
    // phone has been verified via OTP. Off by default so existing
    // integrations/tests keep working until this is deliberately enabled.
    'require_for_order' => filter_var(env('OTP_REQUIRE_FOR_ORDER', false), FILTER_VALIDATE_BOOL),

    'kavenegar' => [
        'api_key' => env('KAVENEGAR_API_KEY'),
    ],

    'melipayamak' => [
        'username' => env('MELIPAYAMAK_USERNAME'),
        'password' => env('MELIPAYAMAK_PASSWORD'),
        'from' => env('MELIPAYAMAK_FROM'),
    ],
];
