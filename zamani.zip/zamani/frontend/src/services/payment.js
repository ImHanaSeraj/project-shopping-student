import api from './api';
export const startPayment = (orderId) => api.post(`/payments/${orderId}/pay`);
export const getPaymentStatus = (orderId) => api.get(`/payments/${orderId}`);
