<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

return new class extends Migration {
    /**
     * دسته‌های ۱ تا ۸ که قبلاً به عکس‌های استاتیک فرانت‌اند
     * (/images/categories/categories N.png) اشاره می‌کردن رو
     * به همون مسیر استوریج لاراول (storage/app/public/categories)
     * وصل می‌کنه؛ یعنی همون مکانیزمی که آپلود از پنل ادمین استفاده می‌کنه.
     *
     * قبل از اجرای این مایگریشن:
     * 1) فایل‌های category-1.png ... category-8.png رو در
     *    backend/storage/app/public/categories/ قرار بده.
     * 2) مطمئن شو که `php artisan storage:link` قبلاً اجرا شده.
     */
    public function up(): void
    {
        $map = [
            1 => 'category-1.png',
            2 => 'category-2.png',
            3 => 'category-3.png',
            4 => 'category-4.png',
            5 => 'category-5.png',
            6 => 'category-6.png',
            7 => 'category-7.png',
            8 => 'category-8.png',
        ];

        foreach ($map as $id => $filename) {
            $path = 'categories/' . $filename;

            // اگه فایل هنوز کپی نشده، این ردیف رو نادیده می‌گیریم
            // تا مایگریشن با خطا متوقف نشه.
            if (!Storage::disk('public')->exists($path)) {
                continue;
            }

            DB::table('categories')->where('id', $id)->update([
                'image' => Storage::disk('public')->url($path),
                'updated_at' => now(),
            ]);
        }
    }

    public function down(): void
    {
        // برگشت معنادار نیست چون مسیر قدیمی فرانت‌اند دیگه منبع اصلی نیست.
    }
};
