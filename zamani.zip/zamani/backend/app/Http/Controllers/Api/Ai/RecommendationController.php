<?php

namespace App\Http\Controllers\Api\Ai;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;







class RecommendationController extends Controller
{
    public function forUser(Request $request)
    {
        $user = $request->user();

        $categoryIds = Product::query()
            ->whereIn('id', function ($q) use ($user) {
                $q->select('product_id')->from('order_items')
                    ->whereIn('order_id', $user->orders()->pluck('id'));
            })
            ->pluck('category_id')
            ->merge($user->wishlists()->with('product')->get()->pluck('product.category_id'))
            ->unique();

        $recommendations = Product::whereIn('category_id', $categoryIds)
            ->where('status', true)
            ->whereNotIn('id', $user->orders()->with('items')->get()->pluck('items.*.product_id')->flatten())
            ->withCount('wishlistedBy')
            ->orderByDesc('wishlisted_by_count')
            ->limit(12)
            ->with('images')
            ->get();

        return response()->json($recommendations);
    }
}
