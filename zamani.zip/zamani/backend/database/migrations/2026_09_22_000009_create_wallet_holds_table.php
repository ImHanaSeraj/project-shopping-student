<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::create('wallet_holds', function(Blueprint $t){$t->id();$t->foreignId('user_id')->constrained()->cascadeOnDelete();$t->foreignId('order_id')->unique()->constrained()->cascadeOnDelete();$t->decimal('amount',14,2);$t->string('status',20)->default('held');$t->timestamp('expires_at')->nullable();$t->timestamp('consumed_at')->nullable();$t->timestamp('released_at')->nullable();$t->timestamps();$t->index(['user_id','status']);}); }
 public function down(): void {Schema::dropIfExists('wallet_holds');}
};
