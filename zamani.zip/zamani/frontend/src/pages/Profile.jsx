export default function Profile(){
 return <div className="luxury-card"><h1>ZAMANI ACCOUNT</h1><p>Profile</p></div>
}
