import InfoPages from '../views/InfoPages';
export default function Shipping(){ return <InfoPages kind="shipping"/>; }
