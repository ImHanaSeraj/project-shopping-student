<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::create('files', function(Blueprint $t){$t->id();$t->string('name');$t->string('path');$t->string('disk')->default('public');$t->string('mime_type')->nullable();$t->unsignedBigInteger('size')->default(0);$t->string('collection')->nullable();$t->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();$t->timestamps();});
  Schema::create('notifications', function(Blueprint $t){$t->uuid('id')->primary();$t->string('type');$t->morphs('notifiable');$t->text('data');$t->timestamp('read_at')->nullable();$t->timestamps();$t->index(['notifiable_type','notifiable_id','read_at']);});
 }
 public function down(): void {Schema::dropIfExists('notifications');Schema::dropIfExists('files');}
};
