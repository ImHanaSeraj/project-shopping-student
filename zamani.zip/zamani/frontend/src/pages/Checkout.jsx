import OptimizedImage from '../components/OptimizedImage';
import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from '../utils/routerCompat';
import Icon from '../components/Icon';
import { useAuth } from '../context/AuthContext';
import { cartTotals, formatPrice, readCart, writeCart, fetchCart } from '../services/cart';
import { createAddress, createOrder, getAddresses, getCheckoutSummary, validateDiscount } from '../services/checkout';
import { startPayment } from '../services/payment';
import useDocumentTitle from '../hooks/useDocumentTitle';

const emptyAddress = { receiver_name:'', phone:'', province:'', city:'', address:'', postal_code:'' };

export default function Checkout() {
  useDocumentTitle('تسویه حساب | زمانی');
  const { user } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState(() => readCart());
  const [addresses, setAddresses] = useState([]);
  const [addressId, setAddressId] = useState('');
  const [showNew, setShowNew] = useState(false);
  const [address, setAddress] = useState(emptyAddress);
  const [shipping, setShipping] = useState('standard');
  const [discountCode, setDiscountCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [discountMessage, setDiscountMessage] = useState('');
  const [serverTotals, setServerTotals] = useState(null);
  const [loading, setLoading] = useState(true);
  const [savingAddress, setSavingAddress] = useState(false);
  const [applyingDiscount, setApplyingDiscount] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [order, setOrder] = useState(null);

  useEffect(() => {
    if (!user) { navigate('/login?redirect=/checkout', { replace:true }); return; }
    let cancelled = false;
    fetchCart().then(current => {
      if (cancelled) return;
      setItems(current);
      if (!current.length) { navigate('/cart', { replace:true }); return; }
      return getAddresses();
    }).then(result => {
      if (cancelled || !result) return;
      const {data} = result;
      const list = data?.data || data || [];
      setAddresses(list);
      if (list[0]) setAddressId(String(list[0].id)); else setShowNew(true);
    }).catch(() => { if (!cancelled) setError('امکان دریافت سبد خرید یا آدرس‌ها وجود ندارد.'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [user, navigate]);

  const baseTotals = useMemo(() => cartTotals(items), [items]);
  const shippingCost = serverTotals ? Number(serverTotals.shipping || 0) : (shipping === 'express' ? 149000 : 89000);
  const displayedSubtotal = serverTotals ? Number(serverTotals.subtotal || 0) : baseTotals.subtotal;
  const displayedDiscount = serverTotals ? Number(serverTotals.discount || 0) : discount;
  const finalTotal = serverTotals ? Number(serverTotals.total || 0) : Math.max(0, displayedSubtotal - displayedDiscount + shippingCost);

  useEffect(() => {
    if (!user || !items.length) return;
    let cancelled = false;
    getCheckoutSummary(shipping, discountCode.trim() || null).then(({data}) => {
      if (!cancelled) { setServerTotals(data); setDiscount(Number(data.discount || 0)); }
    }).catch(() => { if (!cancelled) setServerTotals(null); });
    return () => { cancelled = true; };
  }, [user, items, shipping, discountCode]);

  const setField = (key, value) => setAddress(prev => ({...prev, [key]:value}));

  const saveAddress = async (e) => {
    e.preventDefault(); setSavingAddress(true); setError('');
    try {
      const {data} = await createAddress(address);
      const created = data?.data || data;
      setAddresses(prev => [created, ...prev]); setAddressId(String(created.id)); setShowNew(false); setAddress(emptyAddress);
    } catch (e) { setError(e?.response?.data?.message || 'اطلاعات آدرس را کامل کنید.'); } finally { setSavingAddress(false); }
  };

  const applyDiscount = async () => {
    if (!discountCode.trim()) return;
    setApplyingDiscount(true); setDiscountMessage('');
    try { const {data} = await validateDiscount(discountCode, shipping); setDiscount(Number(data.discount || 0)); setDiscountMessage(data.message || 'کد تخفیف بررسی شد.'); setServerTotals(null); }
    catch (e) { setDiscount(0); setDiscountMessage(e?.response?.data?.message || 'کد تخفیف معتبر نیست.'); }
    finally { setApplyingDiscount(false); }
  };

  const submit = async () => {
    if (!addressId) { setError('لطفاً یک آدرس انتخاب کنید.'); return; }
    setSubmitting(true); setError('');
    try {
      const {data} = await createOrder({ address_id:Number(addressId), shipping_method:shipping, discount_code:discountCode.trim() || null });
      const createdOrder = data.order;
      const paymentResponse = await startPayment(createdOrder.id);
      if (paymentResponse.data?.payment_url) { window.location.assign(paymentResponse.data.payment_url); return; }
      if (paymentResponse.data?.status === 'paid') { setOrder(createdOrder); writeCart([]); setItems([]); return; }
      throw new Error('آدرس درگاه پرداخت دریافت نشد.');
    } catch (e) { setError(e?.response?.data?.message || 'ثبت سفارش انجام نشد. لطفاً دوباره تلاش کنید.'); }
    finally { setSubmitting(false); }
  };

  if (loading) return <main className="checkout-page container"><div className="checkout-state"><div className="cart-spinner"/><strong>در حال آماده‌سازی تسویه حساب...</strong></div></main>;
  if (order) return <main className="checkout-page container"><div className="checkout-success"><div className="checkout-success-icon"><Icon name="check" size={30}/></div><span className="eyebrow">ORDER CREATED</span><h1>سفارش شما ثبت شد</h1><p>شماره سفارش: <strong>{order.order_number}</strong></p><p>پس از انتقال به درگاه زرین‌پال، پرداخت را تکمیل کنید.</p><Link className="btn btn-primary" to="/products">ادامه خرید <Icon name="arrow" size={15}/></Link></div></main>;

  return <main className="checkout-page container">
    <div className="breadcrumb checkout-breadcrumb"><Link to="/">خانه</Link><span>/</span><Link to="/cart">سبد خرید</Link><span>/</span><strong>تسویه حساب</strong></div>
    <div className="checkout-head"><div><span className="eyebrow">CHECKOUT</span><h1>تکمیل سفارش</h1><p>اطلاعات ارسال و روش تحویل را انتخاب کنید.</p></div></div>
    {error && <div className="checkout-alert"><Icon name="x" size={16}/>{error}</div>}
    <div className="checkout-layout">
      <div className="checkout-main">
        <section className="checkout-card"><div className="checkout-section-title"><span>01</span><div><span className="eyebrow">CUSTOMER INFORMATION</span><h2>اطلاعات مشتری</h2></div></div><div className="customer-mini"><strong>{user?.name || 'کاربر'}</strong><span>{user?.phone || user?.email || 'اطلاعات حساب کاربری'}</span></div></section>

        <section className="checkout-card"><div className="checkout-section-title"><span>02</span><div><span className="eyebrow">DELIVERY ADDRESS</span><h2>آدرس تحویل</h2></div><button className="text-link" onClick={() => setShowNew(v=>!v)}>{showNew ? 'انتخاب آدرس ذخیره‌شده' : '+ آدرس جدید'}</button></div>
          {!showNew && addresses.length > 0 ? <div className="address-list">{addresses.map(a => <label className={`address-option ${String(a.id)===String(addressId)?'selected':''}`} key={a.id}><input type="radio" name="address" checked={String(a.id)===String(addressId)} onChange={() => setAddressId(String(a.id))}/><span className="address-radio"/><div><strong>{a.receiver_name}</strong><p>{a.province}، {a.city}، {a.address}</p><small>{a.phone} · کد پستی {a.postal_code}</small></div></label>)}</div> : <form className="address-form" onSubmit={saveAddress}><div className="form-grid"><label>نام گیرنده<input required value={address.receiver_name} onChange={e=>setField('receiver_name',e.target.value)} /></label><label>شماره تماس<input required inputMode="tel" value={address.phone} onChange={e=>setField('phone',e.target.value)} /></label><label>استان<input required value={address.province} onChange={e=>setField('province',e.target.value)} /></label><label>شهر<input required value={address.city} onChange={e=>setField('city',e.target.value)} /></label><label className="full">آدرس کامل<textarea required rows="3" value={address.address} onChange={e=>setField('address',e.target.value)} /></label><label>کد پستی<input required inputMode="numeric" value={address.postal_code} onChange={e=>setField('postal_code',e.target.value)} /></label></div><button className="btn btn-secondary" disabled={savingAddress}>{savingAddress ? 'در حال ذخیره...' : 'ذخیره آدرس'}</button></form>}
        </section>

        <section className="checkout-card"><div className="checkout-section-title"><span>03</span><div><span className="eyebrow">SHIPPING METHOD</span><h2>روش ارسال</h2></div></div><div className="shipping-options"><label className={shipping==='standard'?'selected':''}><input type="radio" name="shipping" checked={shipping==='standard'} onChange={()=>setShipping('standard')}/><span><strong>ارسال استاندارد</strong><small>تحویل ۲ تا ۴ روز کاری</small></span><b>{shippingCostFor('standard', displayedSubtotal, discount)}</b></label><label className={shipping==='express'?'selected':''}><input type="radio" name="shipping" checked={shipping==='express'} onChange={()=>setShipping('express')}/><span><strong>ارسال سریع</strong><small>تحویل ۱ تا ۲ روز کاری</small></span><b>۱۴۹٬۰۰۰ تومان</b></label></div></section>

        <section className="checkout-card"><div className="checkout-section-title"><span>04</span><div><span className="eyebrow">DISCOUNT CODE</span><h2>کد تخفیف</h2></div></div><div className="coupon-row"><input value={discountCode} onChange={e=>setDiscountCode(e.target.value)} placeholder="کد تخفیف را وارد کنید"/><button className="btn btn-secondary" onClick={applyDiscount} disabled={applyingDiscount}>{applyingDiscount?'بررسی...':'اعمال کد'}</button></div>{discountMessage && <small className={`coupon-message ${discount?'success':''}`}>{discountMessage}</small>}<small className="coupon-hint">مبلغ نهایی فقط توسط سرور محاسبه می‌شود.</small></section>
      </div>

      <aside className="checkout-summary"><div className="checkout-summary-inner"><div className="checkout-summary-title"><span className="eyebrow">ORDER SUMMARY</span><h2>خلاصه سفارش</h2></div><div className="checkout-items">{items.map(item=><div className="checkout-item" key={item.key || item.id}><div className="checkout-thumb">{item.image?<OptimizedImage src={item.image} alt="" />:<span>Z</span>}<b>{item.quantity}</b></div><div><strong>{item.name}</strong><small>{[item.selections?.color,item.selections?.size,item.selections?.model].filter(Boolean).join(' / ') || 'محصول'}</small></div><strong>{formatPrice(Number(item.price)*Number(item.quantity))}</strong></div>)}</div><div className="summary-row"><span>جمع محصولات</span><strong>{formatPrice(displayedSubtotal)}</strong></div>{discount>0&&<div className="summary-row discount"><span>تخفیف</span><strong>- {formatPrice(discount)}</strong></div>}<div className="summary-row"><span>ارسال</span><strong>{shippingCost===0?'رایگان':formatPrice(shippingCost)}</strong></div><div className="summary-divider"/><div className="summary-row total"><span>مبلغ نهایی</span><strong>{formatPrice(finalTotal)}</strong></div><button className="btn btn-primary checkout-payment" onClick={submit} disabled={submitting || !addressId}>{submitting?'در حال ثبت سفارش...':<>پرداخت و ثبت نهایی سفارش <Icon name="arrow" size={15}/></>}</button><div className="secure-payment"><Icon name="shield" size={15}/> پرداخت امن و محافظت‌شده</div></div></aside>
    </div>
    <div className="checkout-mobile-total"><div><span>مبلغ نهایی</span><strong>{formatPrice(finalTotal)}</strong></div><button className="btn btn-primary" onClick={submit} disabled={submitting || !addressId}>{submitting?'...':'پرداخت'}</button></div>
  </main>;
}

function shippingCostFor(type, subtotal, discount) { return type === 'express' ? '۱۴۹٬۰۰۰ تومان' : (subtotal-discount >= 4000000 ? 'رایگان' : '۸۹٬۰۰۰ تومان'); }
