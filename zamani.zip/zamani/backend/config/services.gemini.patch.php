<?php
// Add this entry to config/services.php under the returned array:
// 'gemini' => ['key' => env('GEMINI_API_KEY'), 'model' => env('GEMINI_MODEL', 'gemini-3.6-flash')],
