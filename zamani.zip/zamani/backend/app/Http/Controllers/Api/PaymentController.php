<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Services\ZarinpalService;
use App\Services\InventoryService;
use App\Services\OrderStatusService;
use App\Services\MockPaymentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

class PaymentController extends Controller
{
    public function __construct(private ZarinpalService $zarinpal, private InventoryService $inventory, private OrderStatusService $statuses, private MockPaymentService $mock) {}

    public function pay(Request $request, Order $order)
    {
        abort_unless($order->user_id === $request->user()->id, 403);

        if (config('payment.gateway') === 'mock') {
            if (!$this->mock->enabled()) {
                return response()->json(['message' => 'پرداخت آزمایشی فعال نیست.'], 503);
            }
            try {
                return DB::transaction(function () use ($order) {
                    $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
                    if ($locked->payment_status === 'paid') {
                        return response()->json(['status' => 'paid', 'message' => 'این سفارش قبلاً پرداخت شده است.', 'payment' => $locked->payment]);
                    }
                    if (in_array($locked->status, ['cancelled', 'refunded'], true)) {
                        return response()->json(['message' => 'این سفارش قابل پرداخت نیست.'], 422);
                    }
                    if ($locked->inventory_status === InventoryService::RELEASED) {
                        $this->inventory->reserve($locked->load('items'));
                    }
                    $payment = $locked->payments()->whereIn('status', ['pending', 'initiated'])->latest()->lockForUpdate()->first();
                    if (!$payment) {
                        $payment = $locked->payments()->create(['amount' => $locked->final_total, 'status' => 'pending', 'gateway' => 'mock']);
                    }
                    if ($locked->status === 'pending') {
                        $this->statuses->transition($locked, 'awaiting_payment');
                        $locked->save();
                    }
                    $result = $this->mock->initiate($locked, $payment);
                    return response()->json($result);
                });
            } catch (RuntimeException $e) {
                return response()->json(['message' => $e->getMessage()], 422);
            }
        }
        if (!config('zarinpal.merchant_id')) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'PAYMENT_GATEWAY_NOT_CONFIGURED',
                    'message' => 'درگاه پرداخت هنوز فعال نشده است.',
                ],
            ], 503);
        }

        $result = DB::transaction(function () use ($order) {
            $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
            if ($locked->payment_status === 'paid') return ['already_paid' => true, 'payment' => $locked->payment];
            $payment = $locked->payments()->whereIn('status', ['pending','initiated'])->latest()->lockForUpdate()->first();
            if (!$payment) $payment = $locked->payments()->create(['amount'=>$locked->final_total,'status'=>'pending','gateway'=>'zarinpal']);
            if ($payment->status === 'initiated' && ($payment->authority || $payment->transaction_id)) return ['already_started'=>true,'payment'=>$payment];
            $payment->update(['gateway'=>'zarinpal','status'=>'initiated']);
            if ($locked->status === 'pending') {
                $this->statuses->transition($locked, 'awaiting_payment');
                $locked->save();
            }
            return ['payment'=>$payment];
        });
        if (!empty($result['already_paid'])) return response()->json(['status'=>'paid','message'=>'این سفارش قبلاً پرداخت شده است.','payment'=>$result['payment']]);
        if (!empty($result['already_started'])) {
            $payment = $result['payment'];
            return response()->json(['status'=>'redirect','authority'=>$payment->transaction_id,'payment_url'=>config('zarinpal.start_url').$payment->transaction_id]);
        }
        $payment = $result['payment'];
        try {
            $z = $this->zarinpal->request((int)$payment->amount * 10, 'پرداخت سفارش '.$order->order_number, config('zarinpal.callback_url').'?order='.$order->id, $request->user()->email, $request->user()->phone);
            $payment->update(['authority'=>$z['authority'],'transaction_id'=>$z['authority'],'status'=>'initiated']);
            return response()->json(['status'=>'redirect','authority'=>$z['authority'],'payment_url'=>$z['url']]);
        } catch (Throwable $e) {
            DB::transaction(function () use ($order, $payment) {
                $payment->update(['status'=>'failed']);
                $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
                if ($locked->payment_status !== 'paid') {
                    $locked->payment_status = 'failed';
                if ($locked->status !== 'pending') {
                    $this->statuses->transition($locked, 'pending');
                }
                $locked->save();
                    $this->inventory->release($locked);
                }
            });
            return response()->json(['success'=>false,'error'=>['code'=>'PAYMENT_GATEWAY_ERROR','message'=>config('app.debug') ? $e->getMessage() : 'ارتباط با درگاه پرداخت با خطا مواجه شد.']], 502);
        }
    }

    public function mockCallback(Request $request)
    {
        if (!$this->mock->enabled()) {
            return response()->json(['message' => 'پرداخت آزمایشی فعال نیست.'], 404);
        }

        $data = $request->validate([
            'payment' => ['required', 'integer'],
            'token' => ['required', 'string'],
            'outcome' => ['required', 'in:success,failed'],
        ]);

        try {
            return DB::transaction(function () use ($data) {
                $payment = Payment::query()->lockForUpdate()->findOrFail($data['payment']);
                $order = Order::query()->lockForUpdate()->findOrFail($payment->order_id);
                $this->mock->assertCallbackToken($payment, $data['token']);

                // The payable amount is a server-side invariant: callbacks never supply it.
                if ((float) $payment->amount !== (float) $order->final_total) {
                    throw new RuntimeException('مبلغ پرداخت با مبلغ سفارش مطابقت ندارد.');
                }

                // Repeated callbacks are deliberately idempotent.
                if ($payment->status === 'paid' && $order->payment_status === 'paid') {
                    return response()->json([
                        'status' => 'success', 'idempotent' => true,
                        'ref_id' => $payment->ref_id, 'order_status' => $order->status,
                        'payment_status' => $order->payment_status,
                    ]);
                }
                if ($payment->status === 'failed' && $order->payment_status === 'failed' && $data['outcome'] === 'failed') {
                    return response()->json([
                        'status' => 'failed', 'idempotent' => true,
                        'order_status' => $order->status, 'payment_status' => $order->payment_status,
                    ]);
                }

                if ($data['outcome'] === 'success') {
                    if ($order->inventory_status !== InventoryService::RESERVED) {
                        throw new RuntimeException('رزرو موجودی این سفارش معتبر نیست.');
                    }
                    $this->inventory->commit($order);
                    $refId = $payment->ref_id ?: $this->mock->referenceId();
                    $payment->forceFill(['status' => 'paid', 'ref_id' => $refId, 'paid_at' => now()])->save();
                    $order->payment_status = 'paid';
                    $this->statuses->transition($order, 'paid');
                    $order->save();
                    return response()->json([
                        'status' => 'success', 'idempotent' => false, 'ref_id' => $refId,
                        'order_status' => $order->status, 'payment_status' => $order->payment_status,
                        'inventory_status' => $order->inventory_status,
                    ]);
                }

                $payment->forceFill(['status' => 'failed'])->save();
                $order->payment_status = 'failed';
                if ($order->status !== 'pending') {
                    $this->statuses->transition($order, 'pending');
                }
                $order->save();
                $this->inventory->release($order);
                return response()->json([
                    'status' => 'failed', 'idempotent' => false,
                    'order_status' => $order->status, 'payment_status' => $order->payment_status,
                    'inventory_status' => $order->inventory_status,
                ]);
            });
        } catch (RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }
    }

    public function callback(Request $request)
    {
        $orderId = $request->integer('order');
        $authority = (string) $request->query('Authority');
        $order = Order::find($orderId);
        if (!$order) return redirect()->away(config('zarinpal.frontend_result_url').'?status=failed&reason=order_not_found');
        if ($authority === '') return redirect()->away(config('zarinpal.frontend_result_url').'?status=failed&order='.$order->id.'&reason=missing_authority');

        // Never use the latest Payment blindly. The gateway callback must identify
        // the exact Payment belonging to this Order by its Authority.
        $payment = Payment::query()
            ->where('order_id', $order->id)
            ->where('authority', $authority)
            ->first();
        if (!$payment) return redirect()->away($this->resultUrl($order, 'failed', new Payment(['transaction_id' => $authority])));
        if ((float) $payment->amount !== (float) $order->final_total) {
            return redirect()->away($this->resultUrl($order, 'failed', $payment, null).'&reason=amount_mismatch');
        }
        if ($order->payment_status === 'paid' || $payment->status === 'paid') {
            return redirect()->away($this->resultUrl($order, 'success', $payment, $payment->ref_id));
        }
        if (strtoupper((string)$request->query('Status')) !== 'OK') {
            DB::transaction(function () use ($order, $payment) {
                $payment->update(['status'=>'cancelled']);
                $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
                $locked->update(['status'=>'pending_payment','payment_status'=>'pending']);
                $this->inventory->release($locked);
            });
            return redirect()->away($this->resultUrl($order, 'cancelled', $payment));
        }
        try {
            $verified = $this->zarinpal->verify((int)$payment->amount * 10, (string)$request->query('Authority'));
            if (in_array($verified['code'], [100,101], true)) {
                DB::transaction(function () use ($order, $payment, $verified) {
                    $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
                    $p = Payment::whereKey($payment->id)->lockForUpdate()->firstOrFail();

                    if ($p->order_id !== $locked->id) {
                        throw new RuntimeException('پرداخت به این سفارش تعلق ندارد.');
                    }
                    if ((float) $p->amount !== (float) $locked->final_total) {
                        throw new RuntimeException('مبلغ پرداخت با مبلغ سفارش مطابقت ندارد.');
                    }
                    if ($locked->payment_status !== 'paid' && $p->status !== 'paid') {
                        $this->inventory->commit($locked);
                        $p->update(['status'=>'paid','ref_id'=>(string)$verified['ref_id'],'paid_at'=>now()]);
                        $locked->payment_status = 'paid';
                        $this->statuses->transition($locked, 'paid');
                        $locked->save();
                    }
                });
                return redirect()->away($this->resultUrl($order, 'success', $payment, $verified['ref_id']));
            }
            DB::transaction(function () use ($order, $payment) {
                $payment->update(['status'=>'failed']);
                $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
                $locked->payment_status = 'failed';
                if ($locked->status !== 'pending') {
                    $this->statuses->transition($locked, 'pending');
                }
                $locked->save();
                $this->inventory->release($locked);
            });
            return redirect()->away($this->resultUrl($order, 'failed', $payment));
        } catch (Throwable $e) {
            DB::transaction(function () use ($order, $payment) {
                $payment->update(['status'=>'failed']);
                $locked = Order::whereKey($order->id)->lockForUpdate()->firstOrFail();
                $locked->payment_status = 'failed';
                if ($locked->status !== 'pending') {
                    $this->statuses->transition($locked, 'pending');
                }
                $locked->save();
                $this->inventory->release($locked);
            });
            return redirect()->away($this->resultUrl($order, 'failed', $payment));
        }
    }

    public function status(Request $request, Order $order)
    {
        abort_unless($order->user_id === $request->user()->id, 403);
        return ['order'=>$order->load('payment')];
    }

    private function resultUrl(Order $order, string $status, Payment $payment, $refId=null): string
    {
        return config('zarinpal.frontend_result_url').'?status='.$status.'&order='.$order->id.'&order_number='.urlencode($order->order_number).'&transaction_id='.urlencode((string)($payment->ref_id ?: $payment->transaction_id)).'&ref_id='.urlencode((string)$refId);
    }
}
