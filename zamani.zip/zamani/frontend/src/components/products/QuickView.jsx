import React, { useEffect } from 'react';
import Link from '../SafeLink';
import Icon from '../Icon';
import OptimizedImage from '../OptimizedImage';

const formatPrice = (value) => new Intl.NumberFormat('fa-IR').format(Number(value || 0));

export default function QuickView({ product, open, onClose }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && onClose();
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', onKey);
    return () => { document.body.style.overflow = previous; document.removeEventListener('keydown', onKey); };
  }, [open, onClose]);
  if (!open || !product) return null;
  const images = (product.images || []).map(x => typeof x === 'string' ? x : x?.image || x?.path || x?.url).filter(Boolean);
  const image = product.image || images[0] || '';
  const price = product.discount_price || product.price;
  const hasDiscount = product.discount_price && Number(product.discount_price) < Number(product.price);
  return <>
    <button className="quick-view-backdrop" onClick={onClose} aria-label="بستن پیش‌نمایش" />
    <div className="quick-view-modal" role="dialog" aria-modal="true" aria-label="پیش‌نمایش محصول">
      <button className="quick-view-close" onClick={onClose} aria-label="بستن"><Icon name="x" /></button>
      <div className="quick-view-media">{image ? <OptimizedImage src={image} alt={product.name} /> : <span>ZAMANI</span>}</div>
      <div className="quick-view-content">
        <span className="eyebrow">QUICK VIEW · ZAMANI</span>
        <h2>{product.name}</h2>
        {product.brand?.name && <span className="quick-view-brand">{product.brand.name}</span>}
        <div className="quick-view-price"><strong>{formatPrice(price)} تومان</strong>{hasDiscount && <del>{formatPrice(product.price)} تومان</del>}</div>
        {product.description && <p>{String(product.description).replace(/<[^>]+>/g, '').slice(0, 260)}{String(product.description).length > 260 ? '…' : ''}</p>}
        <div className="quick-view-meta">
          {product.category?.name && <span>دسته: {product.category.name}</span>}
          {product.stock != null && <span>{Number(product.stock) > 0 ? 'موجود' : 'ناموجود'}</span>}
        </div>
        <Link href={`/products/${product.slug || product.id}`} className="btn btn-primary quick-view-detail" onClick={onClose}>مشاهده جزئیات کامل <Icon name="arrow" size={14}/></Link>
      </div>
    </div>
  </>;
}
