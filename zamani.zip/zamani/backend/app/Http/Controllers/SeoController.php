<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cache;

class SeoController extends Controller
{
    public function robots(): Response
    {
        $frontend = rtrim((string) config('app.frontend_url', config('app.url')), '/');
        $sitemap = $frontend . '/sitemap.xml';
        $body = implode("\n", [
            'User-agent: *',
            'Allow: /',
            'Disallow: /admin',
            'Disallow: /account',
            'Disallow: /profile',
            'Disallow: /orders',
            'Disallow: /checkout',
            'Disallow: /cart',
            'Disallow: /wishlist',
            'Disallow: /search',
            'Disallow: /login',
            'Disallow: /register',
            'Disallow: /forgot-password',
            'Disallow: /reset-password',
            'Disallow: /payment/',
            'Sitemap: ' . $sitemap,
            '',
        ]);

        return response($body, 200)->header('Content-Type', 'text/plain; charset=UTF-8');
    }

    public function sitemap(): Response
    {
        $frontend = rtrim((string) config('app.frontend_url', config('app.url')), '/');
        $cacheKey = 'seo:sitemap:v2:' . sha1($frontend);
        $xml = Cache::remember($cacheKey, now()->addMinutes(10), function () use ($frontend) {
            $urls = [
                ['loc' => $frontend . '/', 'changefreq' => 'daily', 'priority' => '1.0'],
                ['loc' => $frontend . '/products', 'changefreq' => 'daily', 'priority' => '0.9'],
                ['loc' => $frontend . '/categories', 'changefreq' => 'weekly', 'priority' => '0.8'],
                ['loc' => $frontend . '/latest', 'changefreq' => 'daily', 'priority' => '0.8'],
                ['loc' => $frontend . '/bestsellers', 'changefreq' => 'weekly', 'priority' => '0.7'],
                ['loc' => $frontend . '/about', 'changefreq' => 'monthly', 'priority' => '0.5'],
                ['loc' => $frontend . '/contact', 'changefreq' => 'monthly', 'priority' => '0.5'],
            ];

            Category::query()->where('status', true)->select('slug', 'updated_at')->get()->each(function ($category) use (&$urls, $frontend) {
                if (!$category->slug) return;
                $urls[] = [
                    'loc' => $frontend . '/categories/' . rawurlencode($category->slug),
                    'lastmod' => optional($category->updated_at)->toAtomString(),
                    'changefreq' => 'weekly',
                    'priority' => '0.7',
                ];
            });

            Product::query()->where('status', true)->whereNotNull('slug')->select('slug', 'updated_at')->get()->each(function ($product) use (&$urls, $frontend) {
                $urls[] = [
                    'loc' => $frontend . '/products/' . rawurlencode($product->slug),
                    'lastmod' => optional($product->updated_at)->toAtomString(),
                    'changefreq' => 'weekly',
                    'priority' => '0.8',
                ];
            });

            $lines = [
                '<?xml version="1.0" encoding="UTF-8"?>',
                '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
            ];
            foreach ($urls as $url) {
                $lines[] = '  <url><loc>' . htmlspecialchars($url['loc'], ENT_XML1) . '</loc>'
                    . (isset($url['lastmod']) ? '<lastmod>' . htmlspecialchars($url['lastmod'], ENT_XML1) . '</lastmod>' : '')
                    . '<changefreq>' . $url['changefreq'] . '</changefreq><priority>' . $url['priority'] . '</priority></url>';
            }
            $lines[] = '</urlset>';
            return implode("\n", $lines);
        });

        return response($xml, 200)->header('Content-Type', 'application/xml; charset=UTF-8');
    }
}
