const BACKEND_API = (() => {
  const value = process.env.BACKEND_API_URL || process.env.NEXT_PUBLIC_API_URL;
  return (value && /^https?:\/\//i.test(value) ? value : 'http://127.0.0.1:8000/api').replace(/\/$/, '');
})();

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ success:false, error:{message:'Method Not Allowed'} });
  }
  try {
    const query = new URLSearchParams();
    Object.entries(req.query || {}).forEach(([key, value]) => {
      const values = Array.isArray(value) ? value : [value];
      values.forEach(v => { if (v !== undefined && v !== null && v !== '') query.append(key, String(v)); });
    });
    const url = `${BACKEND_API}/products${query.toString() ? `?${query.toString()}` : ''}`;
    const response = await fetch(url, { headers:{Accept:'application/json'}, cache:'no-store' });
    const text = await response.text();
    let payload;
    try { payload = JSON.parse(text); } catch { payload = {success:false,error:{message:'پاسخ نامعتبر از سرور فروشگاه'}}; }
    res.setHeader('Cache-Control','no-store, max-age=0');
    return res.status(response.status).json(payload);
  } catch (error) {
    return res.status(502).json({
      success:false,
      error:{
        message:'ارتباط با سرور فروشگاه برقرار نشد.',
        detail: process.env.NODE_ENV !== 'production' ? String(error?.message || error) : undefined,
      }
    });
  }
}
