import { useEffect, useState } from 'react';

const slugify = (text, index) => {
  const base = String(text || 'section').trim().toLowerCase().replace(/[^\u0600-\u06FF\w]+/g, '-').replace(/^-+|-+$/g, '');
  return `section-${base || 'item'}-${index}`;
};

export default function ActiveSectionIndicator() {
  const [sections, setSections] = useState([]);
  const [active, setActive] = useState('');

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;
    const refresh = () => {
      const nodes = Array.from(document.querySelectorAll('.main-content main section, .main-content main [data-section]'));
        const items = nodes.map((el, index) => {
          if (!el.id) el.id = slugify(el.querySelector('h1,h2,h3')?.textContent, index);
          const heading = el.querySelector('h1,h2,h3,[data-section-title]');
          const label = heading?.getAttribute('data-section-title') || heading?.textContent?.trim() || `بخش ${index + 1}`;
          return { id: el.id, label };
        }).filter((item, index, arr) => arr.findIndex(x => x.id === item.id) === index);
      setSections(items);
      if (!items.length) setActive('');
    };
    refresh();
    const observer = new MutationObserver(refresh);
    observer.observe(document.querySelector('.main-content') || document.body, { childList: true, subtree: true });
    window.addEventListener('resize', refresh);
    return () => { observer.disconnect(); window.removeEventListener('resize', refresh); };
  }, []);

  useEffect(() => {
    if (!sections.length) return undefined;
    const onScroll = () => {
      const marker = window.scrollY + Math.min(window.innerHeight * 0.34, 260);
      let current = sections[0].id;
      sections.forEach(section => {
        const el = document.getElementById(section.id);
        if (el && el.offsetTop <= marker) current = section.id;
      });
      setActive(current);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [sections]);

  if (sections.length < 2) return null;
  return <nav className="active-section-indicator" aria-label="بخش‌های صفحه">
    {sections.map(section => <button key={section.id} className={active === section.id ? 'is-active' : ''} onClick={() => document.getElementById(section.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })} aria-label={section.label} title={section.label}><span>{section.label}</span><i /></button>)}
  </nav>;
}
