<?php
namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

abstract class AdminBaseController extends Controller
{
    protected function guardAdmin(Request $request): void
    {
        $user = $request->user();
        if (!$user || !in_array($user->role, ['admin', 'manager'], true) || !$user->status) {
            throw new AccessDeniedHttpException('دسترسی مدیر یا مدیر اجرایی لازم است.');
        }
    }
}
