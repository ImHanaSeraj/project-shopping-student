import { Navigate } from '../utils/routerCompat';
import { useAuth } from "../context/AuthContext";

export default function AdminRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="auth-loading">در حال بررسی حساب کاربری...</div>;
  if (!user) return <Navigate to="/login" replace />;
  const canAccessAdmin = user.role === "admin" || user.role === "manager" || user.is_admin === true;
  if (!canAccessAdmin) return <Navigate to="/" replace />;
  return children;
}
