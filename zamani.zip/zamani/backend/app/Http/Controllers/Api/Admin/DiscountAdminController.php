<?php
namespace App\Http\Controllers\Api\Admin;
use App\Models\Discount;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
class DiscountAdminController extends AdminBaseController {
    public function index(Request $request) {
        $this->guardAdmin($request);
        return response()->json(Discount::with('product')->latest()->paginate(20));
    }
    public function store(Request $request) {
        $this->guardAdmin($request);
        $data = $this->validateDiscount($request);
        $data['code'] = strtoupper(trim($data['code']));
        return response()->json(Discount::create($data), 201);
    }
    public function update(Request $request, $id) {
        $this->guardAdmin($request);
        $discount = Discount::findOrFail($id);
        $data = $this->validateDiscount($request, $discount->id);
        $data['code'] = strtoupper(trim($data['code']));
        $discount->update($data);
        return response()->json($discount->fresh('product'));
    }
    public function destroy(Request $request, $id) {
        $this->guardAdmin($request);
        Discount::findOrFail($id)->delete();
        return response()->json(['ok' => true]);
    }
    public function products(Request $request) {
        $this->guardAdmin($request);
        return Product::select('id','name','price','discount_price')->latest()->paginate(50);
    }
    private function validateDiscount(Request $request, ?int $ignoreId = null): array {
        $data = $request->validate([
            'code' => ['required','string','max:50','regex:/^[A-Za-z0-9_-]+$/', Rule::unique('discounts','code')->ignore($ignoreId)],
            'product_id' => ['nullable','integer','exists:products,id'],
            'type' => ['required', Rule::in(['percent','fixed'])],
            'value' => ['required','numeric','gt:0'],
            'start_date' => ['nullable','date'],
            'end_date' => ['nullable','date','after_or_equal:start_date'],
            'min_purchase' => ['nullable','numeric','gte:0'],
            'max_discount' => ['nullable','numeric','gt:0'],
            'usage_limit' => ['nullable','integer','min:1'],
            'per_user_limit' => ['nullable','integer','min:1'],
            'status' => ['sometimes','boolean'],
        ]);
        if ($data['type'] === 'percent' && (float)$data['value'] > 100) {
            abort(422, 'درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد.');
        }
        if (($data['type'] === 'fixed') && isset($data['max_discount']) && (float)$data['max_discount'] > 0 && (float)$data['value'] > (float)$data['max_discount']) {
            abort(422, 'سقف تخفیف ثابت نمی‌تواند کمتر از مبلغ تخفیف باشد.');
        }
        return $data;
    }
}
