import { useEffect, useState } from 'react';

export default function ScrollToTop() {
  const [active, setActive] = useState(false);

  useEffect(() => {
    const onScroll = () => setActive(window.scrollY > 260);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleClick = () => {
    if (!active) return;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      className={`scroll-top-luxury${active ? ' active' : ''}`}
      onClick={handleClick}
      aria-label="بازگشت به بالای صفحه"
      aria-hidden={!active}
      tabIndex={active ? 0 : -1}
    >
      <span className="scroll-top-luxury-icon" aria-hidden="true" />
    </button>
  );
}
