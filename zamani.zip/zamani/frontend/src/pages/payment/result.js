import PaymentResult from '../../views/PaymentResult';
export default PaymentResult;
