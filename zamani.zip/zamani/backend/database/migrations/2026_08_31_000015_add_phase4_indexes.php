<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('categories', function (Blueprint $table) {
            $table->index(['parent_id', 'status']);
        });

        Schema::table('brands', function (Blueprint $table) {
            $table->index('status');
        });

        Schema::table('products', function (Blueprint $table) {
            $table->index(['category_id', 'status']);
            $table->index(['brand_id', 'status']);
            $table->index(['status', 'featured']);
            $table->index('stock');
        });

        Schema::table('product_images', function (Blueprint $table) {
            $table->index(['product_id', 'is_primary', 'sort_order']);
        });

        Schema::table('product_variants', function (Blueprint $table) {
            $table->index(['product_id', 'name', 'value']);
            $table->index('SKU');
        });
    }

    public function down(): void
    {
        Schema::table('product_variants', function (Blueprint $table) {
            $table->dropIndex(['product_id', 'name', 'value']);
            $table->dropIndex(['SKU']);
        });

        Schema::table('product_images', function (Blueprint $table) {
            $table->dropIndex(['product_id', 'is_primary', 'sort_order']);
        });

        Schema::table('products', function (Blueprint $table) {
            $table->dropIndex(['category_id', 'status']);
            $table->dropIndex(['brand_id', 'status']);
            $table->dropIndex(['status', 'featured']);
            $table->dropIndex(['stock']);
        });

        Schema::table('brands', function (Blueprint $table) {
            $table->dropIndex(['status']);
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->dropIndex(['parent_id', 'status']);
        });
    }
};
