<?php

namespace App\Services;

use Illuminate\Support\Facades\Storage;
use RuntimeException;

class BackupService
{
    public function createDatabaseBackup(): string
    {
        $connection = config('database.default');
        $database = config("database.connections.{$connection}.database");
        $diskName = (string) config('backup.disk', 'local');
        $directory = (string) config('backup.directory', 'backups');

        if (!$database) {
            throw new RuntimeException('Database is not configured.');
        }
        if ($connection !== 'mysql') {
            throw new RuntimeException("Backup driver '{$connection}' is not configured.");
        }

        $disk = Storage::disk($diskName);
        $timestamp = now()->format('Ymd_His');
        $relative = "{$directory}/database_{$timestamp}.sql";
        $tmp = tempnam(sys_get_temp_dir(), 'zamani_db_');
        if ($tmp === false) {
            throw new RuntimeException('Could not create a temporary backup file.');
        }

        try {
            $db = config("database.connections.{$connection}");
            $host = (string) ($db['host'] ?? '127.0.0.1');
            $port = (string) ($db['port'] ?? 3306);
            $user = (string) ($db['username'] ?? '');
            $password = (string) ($db['password'] ?? '');
            $command = sprintf(
                'mysqldump --host=%s --port=%s --user=%s %s > %s 2>/dev/null',
                escapeshellarg($host), escapeshellarg($port), escapeshellarg($user),
                escapeshellarg((string) $database), escapeshellarg($tmp)
            );
            if ($password !== '') {
                $command = 'MYSQL_PWD=' . escapeshellarg($password) . ' ' . $command;
            }

            exec($command, $output, $code);
            if ($code !== 0 || !is_file($tmp) || filesize($tmp) === 0) {
                throw new RuntimeException('Database backup command failed.');
            }
            $contents = file_get_contents($tmp);
            if ($contents === false || $contents === '') {
                throw new RuntimeException('Database backup file is empty.');
            }
            if (!$disk->put($relative, $contents)) {
                throw new RuntimeException('Could not store database backup.');
            }
            return $relative;
        } finally {
            @unlink($tmp);
        }
    }

    public function restoreDatabaseBackup(string $path): void
    {
        if (!Storage::disk(config('backup.disk', 'local'))->exists($path)) {
            throw new RuntimeException('Backup file was not found.');
        }
        throw new RuntimeException(
            'Database restore is intentionally disabled until a real server restore procedure is configured.'
        );
    }

    public function listBackups(): array
    {
        $disk = Storage::disk(config('backup.disk', 'local'));
        $directory = (string) config('backup.directory', 'backups');
        return collect($disk->files($directory))
            ->filter(fn ($file) => str_ends_with(strtolower($file), '.sql'))
            ->sortDesc()->values()->all();
    }
}
