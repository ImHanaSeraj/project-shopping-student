<?php
namespace App\Http\Controllers\Api\Admin;

use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Cache;

class ProductAdminController extends AdminBaseController
{
    public function index(Request $request)
    {
        $this->guardAdmin($request);
        $q = Product::with(['images','variants','category','brand'])->latest();
        if ($request->filled('search')) $q->where(fn($x) => $x->where('name','like','%'.$request->search.'%')->orWhere('SKU','like','%'.$request->search.'%'));
        if ($request->filled('status')) $q->where('status', $request->status === 'active');
        if ($request->filled('category_id')) $q->where('category_id', $request->category_id);
        return ProductResource::collection($q->paginate(15));
    }

    public function store(Request $request)
    {
        $this->guardAdmin($request);
        $data = $this->validateProduct($request);
        return DB::transaction(function() use ($data, $request) {
            $data['slug'] = $data['slug'] ?? Str::slug($data['name']).'-'.Str::lower(Str::random(5));
            $product = Product::create($data);
            $this->syncVariants($product, $request->input('variants', []));
            $this->syncImages($product, $request->input('images', []));
            return (new ProductResource($product->load(['images','variants','category','brand'])))->response()->setStatusCode(201);
        });
    }

    public function show(Request $request, $id)
    {
        $this->guardAdmin($request);
        return new ProductResource(Product::with(['images','variants','category','brand'])->findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $this->guardAdmin($request);
        $product = Product::findOrFail($id);
        $data = $this->validateProduct($request, $product->id);
        return DB::transaction(function() use ($product, $data, $request) {
            $product->update($data);
            if ($request->has('variants')) { $product->variants()->delete(); $this->syncVariants($product, $request->input('variants', [])); }
            if ($request->has('images')) { $product->images()->delete(); $this->syncImages($product, $request->input('images', [])); }
            return new ProductResource($product->fresh()->load(['images','variants','category','brand']));
        });
    }

    public function destroy(Request $request, $id)
    {
        $this->guardAdmin($request);
        Product::findOrFail($id)->delete();
        return ['message'=>'محصول حذف شد.'];
    }

    public function toggle(Request $request, $id)
    {
        $this->guardAdmin($request);
        $p = Product::findOrFail($id); $p->status = !$p->status; $p->save();
        return ['status'=>$p->status, 'message'=>$p->status ? 'محصول فعال شد.' : 'محصول غیرفعال شد.'];
    }

    public function uploadImage(Request $request)
    {
        $this->guardAdmin($request);
        $data = $request->validate(['image'=>['required','image','mimes:jpg,jpeg,png,webp','max:5120']]);

        $file = $data['image'];
        $directory = $this->productImageDirectory();
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }

        $filename = Str::uuid()->toString() . '.' . strtolower($file->getClientOriginalExtension() ?: 'jpg');
        $file->move($directory, $filename);

        return [
            'url' => '/images/products/' . $filename,
            'path' => 'images/products/' . $filename,
            'optimized' => false,
        ];
    }

    private function productImageDirectory(): string
    {
        $configured = env('FRONTEND_PUBLIC_PATH');
        if ($configured) {
            return rtrim($configured, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'products';
        }

        return dirname(base_path()) . DIRECTORY_SEPARATOR . 'frontend' . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'products';
    }

    private function validateProduct(Request $r, ?int $id = null): array
    {
        $data = $r->validate([
            'name' => 'required|string|max:255',
            'slug' => 'nullable|string|max:255|unique:products,slug,' . ($id ?: 'NULL') . ',id',
            'short_description' => 'nullable|string|max:1000',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'discount_price' => 'nullable|numeric|min:0|lte:price',
            'stock' => 'required|integer|min:0',
            'SKU' => 'required|string|max:100|unique:products,SKU,' . ($id ?: 'NULL') . ',id',
            'category_id' => 'required|exists:categories,id',
            'brand_id' => 'nullable|exists:brands,id',
            'status' => 'boolean',
            'featured' => 'boolean',
            'variants' => 'nullable|array',
            'variants.*.id' => 'nullable|integer|exists:product_variants,id',
            'variants.*.size' => 'nullable|string|max:50',
            'variants.*.color' => 'nullable|string|max:100',
            'variants.*.name' => 'nullable|string|max:100',
            'variants.*.value' => 'nullable|string|max:255',
            'variants.*.price' => 'nullable|numeric|min:0',
            'variants.*.stock' => 'required|integer|min:0',
            'variants.*.SKU' => 'required|string|max:100',
            'variants.*.image' => 'nullable|string|max:2048',
            'variants.*.status' => 'boolean',
        ]);

        if (!empty($data['variants'])) {
            $skus = array_map(fn ($sku) => strtoupper(trim((string) $sku)), array_column($data['variants'], 'SKU'));
            if (count($skus) !== count(array_unique($skus))) {
                abort(422, 'SKU هر تنوع محصول باید یکتا باشد.');
            }

            $combinations = [];
            foreach ($data['variants'] as $variant) {
                if (empty($variant['size']) && empty($variant['color']) && empty($variant['name'])) {
                    abort(422, 'هر تنوع باید حداقل سایز، رنگ یا یک مشخصه داشته باشد.');
                }
                if (!empty($variant['size']) || !empty($variant['color'])) {
                    $combination = mb_strtolower(trim((string) ($variant['color'] ?? ''))) . '|' . mb_strtolower(trim((string) ($variant['size'] ?? '')));
                    if (isset($combinations[$combination])) {
                        abort(422, 'ترکیب رنگ و سایز تکراری است.');
                    }
                    $combinations[$combination] = true;
                }

                $skuQuery = ProductVariant::query()->where('SKU', $variant['SKU']);
                if (!empty($variant['id'])) $skuQuery->whereKeyNot((int) $variant['id']);
                if ($skuQuery->exists()) abort(422, 'SKU تنوع محصول قبلاً استفاده شده است.');
            }

            $data['stock'] = collect($data['variants'])
                ->filter(fn ($variant) => ($variant['status'] ?? true) === true)
                ->sum(fn ($variant) => (int) $variant['stock']);
        }

        unset($data['variants']);
        return $data;
    }

    private function syncVariants(Product $p, array $variants): void
    {
        $usedIds = [];

        foreach ($variants as $v) {
            $size = isset($v['size']) ? trim((string) $v['size']) : null;
            $color = isset($v['color']) ? trim((string) $v['color']) : null;
            $name = isset($v['name']) ? trim((string) $v['name']) : null;
            $value = isset($v['value']) ? trim((string) $v['value']) : null;

            if (!$size && !$color && !$name) {
                continue;
            }

            $attributesName = $name ?: (($size || $color) ? 'لباس' : null);
            $attributesValue = $value ?: implode(' / ', array_filter([$color, $size]));

            $payload = [
                'product_id' => $p->id,
                'name' => $attributesName,
                'value' => $attributesValue,
                'size' => $size ?: null,
                'color' => $color ?: null,
                'price' => ($v['price'] ?? null) === '' ? null : ($v['price'] ?? null),
                'stock' => (int) ($v['stock'] ?? 0),
                'SKU' => trim((string) ($v['SKU'] ?? '')),
                'image' => !empty($v['image']) ? $v['image'] : null,
                'status' => (bool) ($v['status'] ?? true),
            ];

            $variant = !empty($v['id'])
                ? $p->variants()->whereKey((int) $v['id'])->first()
                : null;

            if ($variant) {
                $variant->update($payload);
            } else {
                $variant = ProductVariant::create($payload);
            }

            $usedIds[] = $variant->id;
        }

        if ($variants) {
            $p->variants()->whereNotIn('id', $usedIds)->delete();
        }
    }

    private function syncImages(Product $p, array $images): void
    {
        foreach (array_values($images) as $i => $img) {
            $url = is_array($img) ? ($img['image'] ?? $img['url'] ?? null) : $img;
            if ($url) {
                ProductImage::create([
                    'product_id' => $p->id,
                    'image' => $url,
                    'is_primary' => $i === 0,
                    'sort_order' => $i,
                ]);
            }
        }
    }
}
