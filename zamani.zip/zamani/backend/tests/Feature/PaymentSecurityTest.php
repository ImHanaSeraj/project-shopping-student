<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PaymentSecurityTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['payment.gateway' => 'mock', 'payment.mock_enabled' => true, 'payment.mock_frontend_url' => 'http://localhost:3000/payment/mock']);
    }

    public function test_paid_order_cannot_be_paid_again(): void
    {
        [$user, $order, $payment, $variant] = $this->makeOrder(1);
        $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay')->assertOk();
        $payment->refresh();
        $this->postJson('/api/payment/mock/callback', ['payment'=>$payment->id,'token'=>$payment->authority,'outcome'=>'success'])->assertOk();
        $again = $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay');
        $again->assertOk()->assertJsonPath('status', 'paid');
        $this->assertSame(0, (int) $variant->fresh()->stock);
    }

    public function test_callback_cannot_use_payment_from_another_order(): void
    {
        [$userA, $orderA, $paymentA] = $this->makeOrder(1);
        [$userB, $orderB, $paymentB] = $this->makeOrder(1);
        $this->actingAs($userA)->postJson('/api/payments/'.$orderA->id.'/pay')->assertOk();
        $paymentA->refresh();
        // Reusing another Payment id with its own token cannot be mapped to order B by gateway authority.
        $fake = $this->get('/api/payment/callback?order='.$orderB->id.'&Status=OK&Authority='.urlencode($paymentA->authority));
        $fake->assertRedirect();
        $this->assertSame('pending', $orderB->fresh()->payment_status);
    }

    public function test_mock_callback_rejects_tampered_persisted_amount(): void
    {
        [$user, $order, $payment, $variant] = $this->makeOrder(1);
        $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay')->assertOk();
        $payment->refresh();
        $payment->update(['amount' => $payment->amount + 1]);
        $response = $this->postJson('/api/payment/mock/callback', ['payment'=>$payment->id,'token'=>$payment->authority,'outcome'=>'success']);
        $response->assertStatus(422);
        $this->assertSame('pending', $order->fresh()->payment_status);
        $this->assertSame(0, (int) $variant->fresh()->stock);
    }

    public function test_repeated_success_callback_does_not_consume_stock_twice(): void
    {
        [$user, $order, $payment, $variant] = $this->makeOrder(1);
        $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay')->assertOk();
        $payment->refresh();
        $payload = ['payment'=>$payment->id,'token'=>$payment->authority,'outcome'=>'success'];
        $this->postJson('/api/payment/mock/callback', $payload)->assertOk();
        $this->postJson('/api/payment/mock/callback', $payload)->assertOk()->assertJsonPath('idempotent', true);
        $this->assertSame(0, (int) $variant->fresh()->stock);
    }

    private function makeOrder(int $stock): array
    {
        $user = User::factory()->create();
        $address = Address::create(['user_id'=>$user->id,'receiver_name'=>'Test','phone'=>'09120000000','province'=>'Tehran','city'=>'Tehran','address'=>'Test street','postal_code'=>'1234567890','is_default'=>true]);
        $product = Product::factory()->create(['status'=>true,'stock'=>$stock,'price'=>500000]);
        $variant = ProductVariant::create(['product_id'=>$product->id,'size'=>'M','color'=>'Black','SKU'=>'SEC-'.uniqid(),'stock'=>$stock,'status'=>true]);
        $cart = Cart::create(['user_id'=>$user->id]);
        CartItem::create(['cart_id'=>$cart->id,'product_id'=>$product->id,'variant_id'=>$variant->id,'quantity'=>1]);
        $this->actingAs($user)->postJson('/api/checkout', ['address_id'=>$address->id,'shipping_method'=>'standard'])->assertCreated();
        $order = Order::where('user_id',$user->id)->latest()->firstOrFail();
        $payment = $order->payment()->firstOrFail();
        return [$user, $order, $payment, $variant];
    }
}
