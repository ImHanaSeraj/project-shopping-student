<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Address;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AddressController extends Controller
{
    private function rules(): array
    {
        return [
            'receiver_name' => ['required', 'string', 'max:120'],
            'phone' => ['required', 'string', 'max:30'],
            'province' => ['required', 'string', 'max:100'],
            'city' => ['required', 'string', 'max:100'],
            'address' => ['required', 'string', 'max:2000'],
            'postal_code' => ['required', 'regex:/^\d{10}$/'],
            'is_default' => ['sometimes', 'boolean'],
        ];
    }

    public function index(Request $request)
    {
        $addresses = $request->user()->addresses()
            ->orderByDesc('is_default')
            ->latest()
            ->get();

        return response()->json($addresses);
    }

    public function store(Request $request)
    {
        $data = $request->validate($this->rules());
        $user = $request->user();

        $address = DB::transaction(function () use ($user, $data) {
            $hasAddresses = $user->addresses()->exists();
            $makeDefault = $data['is_default'] ?? !$hasAddresses;

            if ($makeDefault) {
                $user->addresses()->update(['is_default' => false]);
            }

            $data['is_default'] = $makeDefault;
            return $user->addresses()->create($data);
        });

        return response()->json($address, 201);
    }

    public function update(Request $request, Address $address)
    {
        $this->authorizeOwner($request, $address);
        $data = $request->validate($this->rules());

        $address = DB::transaction(function () use ($request, $address, $data) {
            $makeDefault = $data['is_default'] ?? $address->is_default;
            if ($makeDefault) {
                $request->user()->addresses()->where("id", "!=", $address->id)->update(['is_default' => false]);
            } elseif ($address->is_default && array_key_exists('is_default', $data)) {
                // Never leave the account without a default address when other addresses exist.
                $replacement = $request->user()->addresses()->where("id", "!=", $address->id)->latest()->first();
                if ($replacement) {
                    $replacement->update(['is_default' => true]);
                } else {
                    $makeDefault = true;
                }
            }

            $data['is_default'] = $makeDefault;
            $address->update($data);
            return $address->fresh();
        });

        return response()->json($address);
    }

    public function destroy(Request $request, Address $address)
    {
        $this->authorizeOwner($request, $address);

        DB::transaction(function () use ($request, $address) {
            $wasDefault = $address->is_default;
            $address->delete();

            if ($wasDefault) {
                $replacement = $request->user()->addresses()->latest()->first();
                if ($replacement) {
                    $replacement->update(['is_default' => true]);
                }
            }
        });

        return response()->json(['success' => true]);
    }

    public function makeDefault(Request $request, Address $address)
    {
        $this->authorizeOwner($request, $address);

        DB::transaction(function () use ($request, $address) {
            $request->user()->addresses()->update(['is_default' => false]);
            $address->update(['is_default' => true]);
        });

        return response()->json($address->fresh());
    }

    private function authorizeOwner(Request $request, Address $address): void
    {
        abort_unless((int) $address->user_id === (int) $request->user()->id, 404, 'آدرس پیدا نشد.');
    }
}
