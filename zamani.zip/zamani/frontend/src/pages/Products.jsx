import SEOHead from '../components/SEOHead';
import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Icon from '../components/Icon';
import ProductCard from '../components/products/ProductCard';
import { getCategories, getProducts } from '../services/productApi';

const filterGroups = [

  { key: 'color', title: 'رنگ', values: ['مشکی','کرم','سفید','بژ','شیری','ذغالی','قهوه‌ای'] },
  { key: 'size', title: 'سایز', values: ['XS','S','M','L','XL','XXL'] },
  { key: 'material', title: 'جنس پارچه', values: ['کرپ','ساتن','لینن','فاستونی','نخ','ابریشم'] },
];

function getParamArray(params, key) { return params.getAll(key).filter(Boolean); }

function matchesLocal(product, params) {
  const q = (params.get('search') || '').trim().toLowerCase();
  const variants = Array.isArray(product.variants) ? product.variants : [];
  const variantValues = variants.map(v => `${v.name || ''} ${v.value || ''}`.toLowerCase()).join(' ');
  if (q && !`${product.name || ''} ${product.description || ''} ${product.brand?.name || ''} ${product.category?.name || ''}`.toLowerCase().includes(q)) return false;
  const cats = getParamArray(params, 'category');
  if (cats.length && !cats.includes(String(product.category_id || product.category?.id || '')) && !cats.includes(product.category?.name || '')) return false;
  if (params.get('in_stock') === '1' && Number(product.stock || 0) <= 0 && !variants.some(v => Number(v.stock || 0) > 0)) return false;
  for (const key of ['color','size','material']) {
    const values = getParamArray(params, key);
    if (values.length && !values.some(value => variantValues.includes(value.toLowerCase()))) return false;
  }
  if (params.get('feature') === 'featured' && !product.featured) return false;
  if (params.get('feature') === 'discount' && !(product.discount_price && Number(product.discount_price) < Number(product.price))) return false;
  return true;
}

export default function Products() {
  const [params, setParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [meta, setMeta] = useState(null);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterOpen, setFilterOpen] = useState(false);
  const [search, setSearch] = useState(params.get('search') || '');

  const activeFilters = useMemo(() => {
    const keys = ['category','color','size','material'];
    return keys.reduce((n, key) => n + getParamArray(params, key).length, 0) + (params.get('in_stock') === '1' ? 1 : 0) + (params.get('feature') ? 1 : 0) + (params.get('min_price') || params.get('max_price') ? 1 : 0);
  }, [params]);

  useEffect(() => {
    setSearch(params.get('search') || '');
    let cancelled = false;
    setLoading(true);
    getProducts(params).then(({ data }) => {
      if (cancelled) return;
      const items = data?.data || data;
      setProducts(Array.isArray(items) ? items : []);
      setMeta(data?.meta || data?.pagination || null);
    }).catch(() => {
      if (cancelled) return;
      setProducts([]);
      setMeta(null);
    }).finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [params]);

  useEffect(() => {
    getCategories().then(({data}) => { const items = data?.data || data; if (Array.isArray(items) && items.length) setCategories(items); }).catch(() => {});
  }, []);

  const updateParam = (key, value, checked = true) => {
    const next = new URLSearchParams(params);
    if (key === 'search' || key === 'sort' || key === 'page' || key === 'min_price' || key === 'max_price') {
      if (value) next.set(key, value); else next.delete(key);
    } else {
      const current = next.getAll(key).filter(Boolean);
      const exists = current.includes(String(value));
      const values = checked ? (exists ? current : [...current, String(value)]) : current.filter(v => v !== String(value));
      next.delete(key); values.forEach(v => next.append(key, v));
      next.delete('page');
    }
    setParams(next);
  };

  const clearFilters = () => {
    const next = new URLSearchParams();
    if (params.get('search')) next.set('search', params.get('search'));
    if (params.get('sort')) next.set('sort', params.get('sort'));
    setParams(next);
  };

  const total = meta?.total ?? products.length;
  const currentPage = Number(meta?.current_page || params.get('page') || 1);
  const lastPage = Number(meta?.last_page || 1);

  return <main className="products-page"><SEOHead title="محصولات زنانه" description="خرید و مشاهده مجموعه محصولات پوشاک زنانه زمانی." path="/products" />
    <div className="products-hero container">
      <h1 className="products-title-gradient">محصولات</h1>
      <p>انتخابی curated از پوشاک زنانه؛ از مدل‌های روزمره تا آیتم‌های خاص و ماندگار.</p>
    </div>

    <div className="products-toolbar container">
      <form className="products-search" onSubmit={e => { e.preventDefault(); updateParam('search', search.trim()); }}>
        <Icon name="search" size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="جستجو در نام محصول، برند یا دسته‌بندی..."/><button type="submit">جستجو</button>
      </form>
      <div className="toolbar-actions">
        <button className={`filter-toggle ${activeFilters ? 'has-filter' : ''}`} onClick={() => setFilterOpen(true)}><Icon name="chevron" size={15}/><span>فیلتر</span>{activeFilters > 0 && <b>{activeFilters}</b>}</button>
        <label className="sort-control"><span>مرتب‌سازی:</span><select value={params.get('sort') || 'newest'} onChange={e => updateParam('sort', e.target.value)}><option value="newest">جدیدترین</option><option value="popular">محبوب‌ترین</option><option value="price_low">ارزان‌ترین</option><option value="price_high">گران‌ترین</option><option value="discount">بیشترین تخفیف</option></select></label>
      </div>
    </div>

    <div className="products-layout container">
      <aside className={`filters-sidebar ${filterOpen ? 'is-open' : ''}`}>
        <div className="filters-head"><div><span className="eyebrow">REFINE</span><h2>فیلتر محصولات</h2></div><button onClick={() => setFilterOpen(false)} className="filter-close"><Icon name="x"/></button></div>
        <div className="filter-scroll">
          <FilterSection title="دسته" values={categories} selected={getParamArray(params,'category')} onChange={(v,c) => updateParam('category', v, c)} valueKey="id" labelKey="name" countKey="products_count" />
          <div className="filter-group"><h3>قیمت</h3><div className="price-inputs"><input inputMode="numeric" value={params.get('min_price') || ''} onChange={e => updateParam('min_price', e.target.value)}/><span>تا</span><input inputMode="numeric" value={params.get('max_price') || ''} onChange={e => updateParam('max_price', e.target.value)}/></div><div className="price-label"><span>حداقل</span><span>حداکثر (تومان)</span></div></div>
          <Check label="فقط کالاهای موجود" checked={params.get('in_stock') === '1'} onChange={v => updateParam('in_stock','1',v)} />
          <FilterSection title="رنگ" values={filterGroups[0].values.map(v=>({name:v,id:v}))} selected={getParamArray(params,'color')} onChange={(v,c)=>updateParam('color',v,c)} valueKey="id" labelKey="name" />
          <FilterSection title="سایز" values={filterGroups[1].values.map(v=>({name:v,id:v}))} selected={getParamArray(params,'size')} onChange={(v,c)=>updateParam('size',v,c)} valueKey="id" labelKey="name" />
          <FilterSection title="جنس پارچه" values={filterGroups[2].values.map(v=>({name:v,id:v}))} selected={getParamArray(params,'material')} onChange={(v,c)=>updateParam('material',v,c)} valueKey="id" labelKey="name" />
          <div className="filter-group"><h3>ویژگی محصول</h3><Check label="محصولات منتخب" checked={params.get('feature') === 'featured'} onChange={v => updateParam('feature','featured',v)}/><Check label="تخفیف‌دار" checked={params.get('feature') === 'discount'} onChange={v => updateParam('feature','discount',v)}/></div>
        </div>
        <button className="btn btn-primary filter-apply" onClick={() => setFilterOpen(false)}>اعمال فیلتر</button>
        <button className="clear-filters" onClick={clearFilters}>حذف همه فیلترها</button>
      </aside>
      {filterOpen && <button className="filter-backdrop" onClick={() => setFilterOpen(false)} aria-label="بستن فیلتر"/>}

      <section className="products-results">
        <div className="results-head"><div><strong>{loading ? 'در حال بررسی محصولات...' : `${new Intl.NumberFormat('fa-IR').format(total)} محصول`}</strong>{activeFilters > 0 && !loading && <span> · {activeFilters} فیلتر فعال</span>}</div>{activeFilters > 0 && <button onClick={clearFilters}>پاک کردن فیلترها</button>}</div>
        {loading ? <div className="product-grid loading-grid">{[1,2,3,4,5,6,7,8].map(i => <ProductSkeleton key={i}/>)}</div> : products.length ? <div className="product-grid">{products.map(p => <ProductCard key={p.id} product={p}/>)}</div> : <EmptyState search={params.get('search')} clear={clearFilters}/>} 
        {!loading && products.length > 0 && lastPage > 1 && <Pagination current={currentPage} last={lastPage} onPage={p => updateParam('page', String(p))}/>} 
      </section>
    </div>
  </main>;
}

function FilterSection({ title, values, selected, onChange, valueKey, labelKey, countKey }) {
  return <div className="filter-group"><h3>{title}</h3><div className="filter-options">{values.map(item => { const value = String(item[valueKey]); const checked = selected.includes(value); return <label key={value}><input type="checkbox" checked={checked} onChange={e => onChange(value, e.target.checked)}/><span>{item[labelKey]}</span>{item[countKey] != null && <small>{item[countKey]}</small>}</label>; })}</div></div>;
}
function Check({label, checked, onChange}) { return <label className="single-check"><input type="checkbox" checked={checked} onChange={e=>onChange(e.target.checked)}/><span>{label}</span></label>; }
function ProductSkeleton(){ return <div className="product-skeleton"><div className="skeleton-media"/><div className="skeleton-line short"/><div className="skeleton-line"/><div className="skeleton-line price"/></div>; }
function EmptyState({search, clear}) { return <div className="empty-state"><div className="empty-icon"><Icon name="search" size={28}/></div><h2>محصولی پیدا نشد</h2><p>{search ? `برای «${search}» نتیجه‌ای پیدا نکردیم.` : 'با تغییر فیلترها یا جستجوی عبارت دیگری دوباره امتحان کنید.'}</p><button className="btn btn-outline" onClick={clear}>حذف فیلترها</button></div>; }
function Pagination({current,last,onPage}) { const pages = Array.from({length:last},(_,i)=>i+1).filter(p => p===1 || p===last || Math.abs(p-current)<=2); const compact=[]; pages.forEach((p,i)=>{ if(i && p-pages[i-1]>1) compact.push('dots'); compact.push(p); }); return <nav className="pagination" aria-label="صفحه‌بندی">{current>1&&<button onClick={()=>onPage(current-1)}><Icon name="arrow" size={14}/></button>}{compact.map((p,i)=>p==='dots'?<span key={`d${i}`}>…</span>:<button className={p===current?'active':''} key={p} onClick={()=>onPage(p)}>{new Intl.NumberFormat('fa-IR').format(p)}</button>)}{current<last&&<button onClick={()=>onPage(current+1)}><Icon name="arrow" size={14}/></button>}</nav>; }
