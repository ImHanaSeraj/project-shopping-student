import { OrderDetails } from '../../views/Orders';
import ProtectedRoute from '../../guards/ProtectedRoute';
export default function OrderDetailsPage(){ return <ProtectedRoute><OrderDetails/></ProtectedRoute>; }
