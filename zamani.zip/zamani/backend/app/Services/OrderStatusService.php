<?php

namespace App\Services;

use App\Models\Order;
use RuntimeException;

class OrderStatusService
{
    /**
     * The order workflow is intentionally explicit.
     *
     * pending -> awaiting_payment -> paid -> processing -> shipped -> delivered
     * pending/awaiting_payment -> cancelled
     * paid -> refund_requested -> refunded
     */
    private const TRANSITIONS = [
        'pending' => ['awaiting_payment', 'cancelled'],
        'awaiting_payment' => ['paid', 'pending', 'cancelled'],
        'paid' => ['processing', 'refund_requested'],
        'processing' => ['shipped'],
        'shipped' => ['delivered'],
        'delivered' => ['refund_requested'],
        'refund_requested' => ['refunded'],
        'cancelled' => [],
        'refunded' => [],
    ];

    public function canTransition(string $from, string $to): bool
    {
        return $from === $to || in_array($to, self::TRANSITIONS[$from] ?? [], true);
    }

    public function transition(Order $order, string $to): Order
    {
        $from = (string) $order->status;

        if (!$this->canTransition($from, $to)) {
            throw new RuntimeException("انتقال وضعیت سفارش از {$from} به {$to} مجاز نیست.");
        }

        if ($from === $to) {
            return $order;
        }

        if ($to === 'cancelled' && $order->payment_status === 'paid') {
            throw new RuntimeException('سفارش پرداخت‌شده بدون فرآیند استرداد قابل لغو نیست.');
        }

        if ($to === 'paid' && $order->payment_status !== 'paid') {
            throw new RuntimeException('سفارش فقط پس از تأیید موفق پرداخت می‌تواند Paid شود.');
        }

        if ($to === 'refund_requested' && $order->payment_status !== 'paid') {
            throw new RuntimeException('فقط سفارش پرداخت‌شده می‌تواند درخواست استرداد داشته باشد.');
        }

        if ($to === 'refunded' && $from !== 'refund_requested') {
            throw new RuntimeException('سفارش فقط پس از ثبت درخواست استرداد می‌تواند Refunded شود.');
        }

        $order->status = $to;
        if ($to === 'delivered' && !$order->delivered_at) {
            $order->delivered_at = now();
        }
        return $order;
    }

    public function transitionAndSave(Order $order, string $to): Order
    {
        $this->transition($order, $to)->save();
        return $order;
    }

    public function allStatuses(): array
    {
        return array_keys(self::TRANSITIONS);
    }
}
