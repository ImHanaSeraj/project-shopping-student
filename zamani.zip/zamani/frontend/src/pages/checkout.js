import Checkout from '../views/Checkout';
import ProtectedRoute from '../guards/ProtectedRoute';
export default function CheckoutPage(){ return <ProtectedRoute><Checkout/></ProtectedRoute>; }
