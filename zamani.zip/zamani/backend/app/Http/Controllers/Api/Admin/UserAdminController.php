<?php
namespace App\Http\Controllers\Api\Admin;
use App\Models\User; use Illuminate\Http\Request;
class UserAdminController extends AdminBaseController {
 public function index(Request $r){$this->guardAdmin($r); $q=User::withCount(['orders','wishlists'])->latest(); if($r->filled('search')){$s=$r->search;$q->where(fn($x)=>$x->where('name','like','%'.$s.'%')->orWhere('email','like','%'.$s.'%')->orWhere('phone','like','%'.$s.'%'));} if($r->filled('role'))$q->where('role',$r->role); return $q->paginate(20);}
 public function show(Request $r,$id){$this->guardAdmin($r); return User::with(['orders'=>fn($q)=>$q->latest()->limit(10),'addresses'])->withCount(['orders','wishlists'])->findOrFail($id);}
 public function update(Request $r,$id){$this->guardAdmin($r); $u=User::findOrFail($id); $d=$r->validate(['status'=>'sometimes|boolean','role'=>'sometimes|in:customer,manager,admin']); if($u->id===$r->user()->id && (($d['status']??true)===false || !in_array(($d['role']??$u->role), ['admin','manager'], true))) return response()->json(['message'=>'نمی‌توانید دسترسی مدیر حساب خودتان را حذف کنید.'],422); $u->update($d); return $u;}
}
