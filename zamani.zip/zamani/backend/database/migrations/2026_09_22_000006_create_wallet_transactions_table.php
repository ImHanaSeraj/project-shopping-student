<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::create('wallet_transactions', function(Blueprint $t){
  $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->foreignId('order_id')->nullable()->constrained()->nullOnDelete();
  $t->decimal('amount',14,2); $t->decimal('balance_after',14,2); $t->string('type',40); $t->string('description'); $t->string('reference')->unique(); $t->timestamps();
  $t->index(['user_id','created_at']); $t->index(['order_id','type']);
 }); }
 public function down(): void { Schema::dropIfExists('wallet_transactions'); }
};
