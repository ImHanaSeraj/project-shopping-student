import ResetPassword from '../views/auth/ResetPassword';
import GuestRoute from '../guards/GuestRoute';
export default function ResetPasswordPage(){ return <GuestRoute><ResetPassword/></GuestRoute>; }
