<?php

namespace App\Services\Sms;

use App\Contracts\SmsGatewayInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;

/**
 * Sends SMS via Kavenegar (https://kavenegar.com), a common Iranian SMS
 * provider. Uses the plain "send" REST endpoint; configure KAVENEGAR_API_KEY
 * and, optionally, SMS_SENDER_NUMBER.
 */
class KavenegarSmsGateway implements SmsGatewayInterface
{
    public function send(string $phone, string $message): void
    {
        $apiKey = config('otp.kavenegar.api_key');

        if (!$apiKey) {
            Log::error('Kavenegar SMS driver selected but KAVENEGAR_API_KEY is not set.');
            throw new RuntimeException('سرویس پیامک به‌درستی پیکربندی نشده است.');
        }

        $response = Http::asForm()
            ->timeout(15)
            ->post("https://api.kavenegar.com/v1/{$apiKey}/sms/send.json", array_filter([
                'receptor' => $phone,
                'message' => $message,
                'sender' => config('otp.sender'),
            ]));

        Log::info('Kavenegar SMS send response', [
            'status' => $response->status(),
            'successful' => $response->successful(),
        ]);

        if (!$response->successful()) {
            throw new RuntimeException('ارسال پیامک ناموفق بود. لطفاً بعداً دوباره تلاش کنید.');
        }
    }
}
