<?php

namespace App\Events;

use App\Models\ChatMessage;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Queue\SerializesModels;

// Broadcasts one new chat message to whoever is watching this conversation.
// Public channel keyed by the conversation's session_id (a UUID) so a
// not-logged-in customer can listen too, without needing broadcasting auth.
class ChatMessageCreated implements ShouldBroadcastNow
{
    use InteractsWithSockets, SerializesModels;

    public function __construct(public ChatMessage $message)
    {
    }

    public function broadcastOn(): array
    {
        return [new Channel('chat.' . $this->message->conversation->session_id)];
    }

    public function broadcastAs(): string
    {
        return 'message.created';
    }

    public function broadcastWith(): array
    {
        $m = $this->message;

        return [
            'id' => $m->id,
            'conversation_id' => $m->chat_conversation_id,
            'role' => $m->role,
            'content' => $m->content,
            'sender_name' => $m->role === 'admin' ? ($m->sender->name ?? 'پشتیبانی') : null,
            'created_at' => $m->created_at?->toIso8601String(),
        ];
    }
}
