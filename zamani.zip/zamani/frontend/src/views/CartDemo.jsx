import { useEffect, useMemo, useState } from 'react';
import Link from '../components/SafeLink';
import { resolveMediaUrl } from '../utils/media';

import Icon from '../components/Icon';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { getProducts } from '../services/productApi';
import { readCart, writeCart, cartTotals, formatPrice } from '../services/cart';

const FALLBACK_IMAGE = 'https://images.pexels.com/photos/4947543/pexels-photo-4947543.jpeg?auto=compress&cs=tinysrgb&w=500';

// چند محصول نمونه — فقط برای وقتی که API در دسترس نیست، این صفحه بدون بک‌اند هم کار کند.
const DEMO_PRODUCTS = [
  { id: 'demo-1', name: 'شومیز ابریشمی کرم', price: 1850000, discount_price: 1590000, image: '/images/Popular%20Products/shomiz.png' },
  { id: 'demo-2', name: 'پیراهن بلند مجلسی', price: 3200000, discount_price: null, image: '/images/Popular%20Products/pirahan.png' },
  { id: 'demo-3', name: 'شلوار پارچه‌ای کلاسیک', price: 1450000, discount_price: 1290000, image: '/images/Popular%20Products/shalvar.png' },
  { id: 'demo-4', name: 'ست دو تکه زنانه', price: 2650000, discount_price: null, image: '/images/Popular%20Products/setzanane.png' },
  { id: 'demo-5', name: 'تیشرت و شلوارک راحتی', price: 980000, discount_price: 840000, image: '/images/Popular%20Products/tshirt-shalvarak.png' },
  { id: 'demo-6', name: 'جوراب ساق‌بلند', price: 320000, discount_price: null, image: '/images/Popular%20Products/jorab.png' },
];

function DemoProductCard({ product, onAdd }) {
  const [qty, setQty] = useState(1);
  const [status, setStatus] = useState('idle'); // idle | adding | added
  const image = resolveMediaUrl(product.images?.[0]?.image || product.image || '');
  const price = Number(product.discount_price || product.price || 0);
  const hasDiscount = product.discount_price && Number(product.discount_price) < Number(product.price);

  const handleAdd = () => {
    if (status !== 'idle') return;
    setStatus('adding');
    // یک تأخیر کوتاه و ساختگی، فقط برای این‌که عملیات افزودن حس واقعی‌تری داشته باشد.
    setTimeout(() => {
      onAdd(product, qty);
      setStatus('added');
      setTimeout(() => setStatus('idle'), 1500);
    }, 420);
  };

  return (
    <article className={`cart-demo-card${status !== 'idle' ? ` is-${status}` : ''}`}>
      <div className="cart-demo-media">
        {image ? <img src={image} alt={product.name} loading="lazy" onError={(e) => { e.currentTarget.src = FALLBACK_IMAGE; }} /> : <div className="cart-demo-media-placeholder"><span>ZAMANI</span></div>}
        {hasDiscount && <span className="cart-demo-badge">تخفیف</span>}
      </div>
      <div className="cart-demo-info">
        <h3>{product.name}</h3>
        <div className="cart-demo-price">
          <strong>{formatPrice(price)}</strong>
          {hasDiscount && <del>{formatPrice(product.price)}</del>}
        </div>
        <div className="cart-demo-actions">
          <div className="quantity-control cart-demo-qty">
            <button type="button" onClick={() => setQty(q => Math.max(1, q - 1))} aria-label="کاهش تعداد"><Icon name="minus" size={13} /></button>
            <strong>{new Intl.NumberFormat('fa-IR').format(qty)}</strong>
            <button type="button" onClick={() => setQty(q => Math.min(9, q + 1))} aria-label="افزایش تعداد"><Icon name="plus" size={13} /></button>
          </div>
          <button type="button" className="btn btn-primary cart-demo-add" onClick={handleAdd} disabled={status !== 'idle'}>
            <span className="cart-demo-add-icon"><Icon name={status === 'added' ? 'check' : 'bag'} size={16} /></span>
            <span className="cart-demo-add-label">{status === 'adding' ? 'در حال افزودن...' : status === 'added' ? 'افزوده شد' : 'افزودن به سبد خرید'}</span>
          </button>
        </div>
      </div>
    </article>
  );
}

export default function CartDemo() {
  useDocumentTitle('دمو افزودن به سبد خرید | زمانی');
  const [products, setProducts] = useState(DEMO_PRODUCTS);
  const [cartItems, setCartItems] = useState([]);
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    setCartItems(readCart());
    getProducts({ per_page: 6 }).then(({ data }) => {
      const items = data?.data || data;
      if (Array.isArray(items) && items.length) setProducts(items);
    }).catch(() => {});
  }, []);

  const totals = useMemo(() => cartTotals(cartItems), [cartItems]);
  const itemCount = useMemo(() => cartItems.reduce((sum, item) => sum + Number(item.quantity || 0), 0), [cartItems]);

  const handleAdd = (product, quantity) => {
    const key = `${product.id}-demo`;
    const price = Number(product.discount_price || product.price || 0);
    const image = resolveMediaUrl(product.images?.[0]?.image || product.image || '');
    setCartItems(current => {
      const existing = current.find(item => item.key === key);
      const next = existing
        ? current.map(item => (item.key === key ? { ...item, quantity: Number(item.quantity || 0) + quantity } : item))
        : [...current, {
          key,
          productId: product.id,
          name: product.name,
          image,
          price,
          originalPrice: Number(product.price || price),
          discount: Math.max(0, Number(product.price || 0) - price),
          quantity,
          selections: {},
        }];
      writeCart(next);
      return next;
    });
    setPulse(true);
    setTimeout(() => setPulse(false), 700);
  };

  return (
    <main className="cart-demo-page container">
      <div className="cart-demo-breadcrumb"><Link href="/">خانه</Link><Icon name="arrow" size={11} /><span>دمو افزودن به سبد خرید</span></div>

      <header className="cart-demo-head">
        <div>
          <span className="eyebrow">INTERACTION DEMO</span>
          <h1>افزودن به سبد خرید</h1>
          <p>یک نمونهٔ مستقل برای تست و نمایش تعامل «افزودن به سبد خرید» — بدون نیاز به ورود. هر چیزی که این‌جا اضافه کنید، همان لحظه در سبد خرید واقعی هم قرار می‌گیرد.</p>
        </div>
      </header>

      <div className="cart-demo-layout">
        <div className="cart-demo-grid">
          {products.map(product => <DemoProductCard key={product.id} product={product} onAdd={handleAdd} />)}
        </div>

        <aside className={`cart-demo-summary${pulse ? ' is-pulse' : ''}`}>
          <div className="cart-demo-summary-head">
            <span className="cart-demo-summary-icon"><Icon name="bag" size={18} /></span>
            <strong>سبد خرید شما</strong>
            <span className="cart-demo-summary-count">{new Intl.NumberFormat('fa-IR').format(itemCount)}</span>
          </div>

          {!cartItems.length ? (
            <p className="cart-demo-summary-empty">هنوز چیزی به سبد اضافه نکرده‌اید.</p>
          ) : (
            <ul className="cart-demo-summary-list">
              {[...cartItems].reverse().slice(0, 4).map(item => (
                <li key={item.key}>
                  <span className="cart-demo-summary-name">{item.name}</span>
                  <span className="cart-demo-summary-qty">×{new Intl.NumberFormat('fa-IR').format(item.quantity)}</span>
                </li>
              ))}
            </ul>
          )}

          <div className="cart-demo-summary-total"><span>جمع کل</span><strong>{formatPrice(totals.total)}</strong></div>
          <Link href="/cart" className="btn btn-outline cart-demo-summary-link">مشاهده سبد خرید <Icon name="arrow" size={14} /></Link>
        </aside>
      </div>
    </main>
  );
}
