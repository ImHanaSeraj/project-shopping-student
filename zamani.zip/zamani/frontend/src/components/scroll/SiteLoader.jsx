import { useEffect, useState } from 'react';

export default function SiteLoader() {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const start = performance.now();
    const hide = () => {
      const wait = Math.max(0, 520 - (performance.now() - start));
      window.setTimeout(() => setVisible(false), wait);
    };
    if (document.readyState === 'complete') hide();
    else window.addEventListener('load', hide, { once: true });
    const fallback = window.setTimeout(hide, 850);
    return () => { window.removeEventListener('load', hide); window.clearTimeout(fallback); };
  }, []);
  if (!visible) return null;
  return <div className="zamani-site-loader" aria-hidden="true"><div className="loader-mark"><span>Z</span><i /></div><div className="loader-word">ZAMANI</div></div>;
}
