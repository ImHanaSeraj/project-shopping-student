<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Setting;

class SettingController extends Controller
{
    // Only these keys are safe to expose publicly (no auth). Anything else
    // stored in the settings table (payment/internal config, etc.) stays
    // admin-only via SettingAdminController.
    private const PUBLIC_KEYS = [
        'store_name',
        'support_phone',
        'shipping_fee',
        'free_shipping_threshold',
        'currency',
        'special_offer_end_at',
    ];

    public function publicSettings()
    {
        $settings = Setting::whereIn('key', self::PUBLIC_KEYS)->pluck('value', 'key');

        return response()->json([
            'success' => true,
            'data' => $settings,
        ]);
    }
}
