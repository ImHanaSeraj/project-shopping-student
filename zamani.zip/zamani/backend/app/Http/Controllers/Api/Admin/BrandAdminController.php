<?php
namespace App\Http\Controllers\Api\Admin;
use App\Models\Brand; use Illuminate\Http\Request; use Illuminate\Support\Str;
class BrandAdminController extends AdminBaseController {
 public function index(Request $r){$this->guardAdmin($r); return Brand::withCount('products')->orderBy('name')->get();}
 public function store(Request $r){$this->guardAdmin($r); $d=$r->validate(['name'=>'required|string|max:255','slug'=>'nullable|string|max:255|unique:brands,slug','logo'=>'nullable|string','description'=>'nullable|string','status'=>'boolean']); $d['slug']=$d['slug']??Str::slug($d['name']).'-'.Str::lower(Str::random(4)); return response()->json(Brand::create($d),201);}
 public function update(Request $r,$id){$this->guardAdmin($r); $b=Brand::findOrFail($id); $d=$r->validate(['name'=>'required|string|max:255','slug'=>'nullable|string|max:255|unique:brands,slug,'.$b->id,'logo'=>'nullable|string','description'=>'nullable|string','status'=>'boolean']); $b->update($d); return $b;}
 public function destroy(Request $r,$id){$this->guardAdmin($r); $b=Brand::findOrFail($id); if($b->products()->exists()) return response()->json(['message'=>'این برند دارای محصول است.'],422); $b->delete(); return ['message'=>'برند حذف شد.'];}
}
