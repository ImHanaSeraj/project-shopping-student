<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        // The old sync migration incorrectly marked every category outside
        // its six hard-coded IDs as inactive. Restore those admin-created
        // categories so the storefront can display them again.
        DB::table('categories')
            ->where('id', '>', 6)
            ->where('status', 0)
            ->update(['status' => 1, 'updated_at' => now()]);
    }

    public function down(): void
    {
        // Intentionally empty: we must not deactivate admin-created categories.
    }
};
