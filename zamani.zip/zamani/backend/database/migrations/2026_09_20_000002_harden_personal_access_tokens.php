<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('personal_access_tokens')) {
            return;
        }

        Schema::table('personal_access_tokens', function (Blueprint $table) {
            if (!Schema::hasColumn('personal_access_tokens', 'expires_at')) {
                $table->timestamp('expires_at')->nullable();
            }
        });

        try {
            Schema::table('personal_access_tokens', function (Blueprint $table) {
                $table->index('expires_at', 'pat_expires_at_index');
                $table->index(['tokenable_type', 'tokenable_id', 'last_used_at'], 'pat_tokenable_last_used_index');
            });
        } catch (\Throwable $e) {
            // Indexes may already exist on installations upgraded from an earlier build.
        }
    }

    public function down(): void
    {
        if (!Schema::hasTable('personal_access_tokens')) {
            return;
        }

        try {
            Schema::table('personal_access_tokens', function (Blueprint $table) {
                $table->dropIndex('pat_expires_at_index');
                $table->dropIndex('pat_tokenable_last_used_index');
            });
        } catch (\Throwable $e) {
            // Ignore missing indexes during rollback.
        }
    }
};
