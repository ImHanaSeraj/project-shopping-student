import React, { useMemo, useState } from 'react';
import { resolveMediaUrl } from '../utils/media';

function makeCandidates(src) {
  if (!src || !/\.webp(?:\?.*)?$/i.test(src)) return null;
  const match = src.match(/^(.*?)(?:-1200)?\.webp(\?.*)?$/i);
  if (!match) return null;
  const base = match[1].replace(/-(?:480|768|1200)$/i, '');
  const query = match[2] || '';
  return [
    `${base}-480.webp${query} 480w`,
    `${base}-768.webp${query} 768w`,
    `${base}-1200.webp${query} 1200w`,
  ].join(', ');
}

export default function OptimizedImage({ src, alt = '', className = '', sizes = '(max-width: 768px) 50vw, (max-width: 1200px) 25vw, 320px', loading = 'lazy', fetchPriority = 'auto', ...props }) {
  const [failed, setFailed] = useState(false);
  const resolvedSrc = useMemo(() => resolveMediaUrl(src), [src]);
  const srcSet = useMemo(() => makeCandidates(resolvedSrc), [resolvedSrc]);
  if (!resolvedSrc || failed) return <div className={`image-placeholder ${className}`} aria-label={alt}><span>ZAMANI</span></div>;
  return <img {...props} className={className} src={resolvedSrc} srcSet={srcSet || undefined} sizes={srcSet ? sizes : undefined} alt={alt} loading={loading} decoding="async" fetchPriority={fetchPriority} onError={() => setFailed(true)} />;
}
