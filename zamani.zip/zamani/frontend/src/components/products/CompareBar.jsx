import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from '../../utils/routerCompat';
import Icon from '../Icon';
import { getCompareIds, clearCompare, COMPARE_EVENT, COMPARE_LIMIT } from '../../utils/compareStorage';

export default function CompareBar() {
  const [ids, setIds] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const sync = () => setIds(getCompareIds());
    sync();
    window.addEventListener(COMPARE_EVENT, sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(COMPARE_EVENT, sync);
      window.removeEventListener('storage', sync);
    };
  }, []);

  if (!ids.length || location.pathname === '/compare') return null;

  return (
    <div className="compare-bar" role="region" aria-label="مقایسه محصولات">
      <div className="compare-bar-inner container">
        <div className="compare-bar-info">
          <Icon name="compare" size={18} />
          <span>
            <strong>{ids.length}</strong> از {COMPARE_LIMIT} محصول برای مقایسه انتخاب شد
          </span>
        </div>
        <div className="compare-bar-actions">
          <button type="button" className="compare-bar-clear" onClick={() => clearCompare()}>
            پاک کردن
          </button>
          <button type="button" className="btn btn-primary compare-bar-view" onClick={() => {
              if (typeof window !== 'undefined' && window.location.pathname !== '/compare') navigate('/compare');
            }}>
            مشاهده مقایسه <Icon name="arrow" size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
