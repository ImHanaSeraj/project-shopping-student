const listeners = new Set();

export function subscribeNotifications(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function emit(payload) {
  listeners.forEach((listener) => {
    try { listener(payload); } catch (_) {}
  });
}

export function notify(type, message, options = {}) {
  emit({
    kind: 'toast',
    type,
    message,
    duration: Number(options.duration ?? 4500),
    id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
  });
}

export const notifySuccess = (message, options) => notify('success', message, options);
export const notifyError = (message, options) => notify('error', message, options);
export const notifyWarning = (message, options) => notify('warning', message, options);
export const notifyInfo = (message, options) => notify('info', message, options);

export function showDialog(type, title, message, options = {}) {
  return new Promise((resolve) => {
    emit({
      kind: 'dialog',
      type,
      title,
      message,
      buttonText: options.buttonText ?? 'باشه',
      confirmText: options.confirmText ?? 'تایید',
      cancelText: options.cancelText ?? 'لغو',
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      resolve,
    });
  });
}
