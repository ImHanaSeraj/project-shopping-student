<?php
return [
    'merchant_id' => env('ZARINPAL_MERCHANT_ID'),
    'sandbox' => filter_var(env('ZARINPAL_SANDBOX', true), FILTER_VALIDATE_BOOL),
    'callback_url' => env('ZARINPAL_CALLBACK_URL', env('APP_URL').'/api/payment/callback'),
    'frontend_result_url' => env('ZARINPAL_FRONTEND_RESULT_URL', 'http://localhost:3000/payment/result'),
    'request_url' => env('ZARINPAL_SANDBOX', true) ? 'https://sandbox.zarinpal.com/pg/v4/payment/request.json' : 'https://payment.zarinpal.com/pg/v4/payment/request.json',
    'verify_url' => env('ZARINPAL_SANDBOX', true) ? 'https://sandbox.zarinpal.com/pg/v4/payment/verify.json' : 'https://payment.zarinpal.com/pg/v4/payment/verify.json',
    'start_url' => env('ZARINPAL_SANDBOX', true) ? 'https://sandbox.zarinpal.com/pg/StartPay/' : 'https://www.zarinpal.com/pg/StartPay/',
];
