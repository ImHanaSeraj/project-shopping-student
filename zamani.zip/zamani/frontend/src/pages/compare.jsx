import { useEffect, useMemo, useState } from 'react';
import { Link } from '../utils/routerCompat';
import Icon from '../components/Icon';
import OptimizedImage from '../components/OptimizedImage';
import { getCompareProducts } from '../services/productApi';
import { formatPrice, readCart, writeCart } from '../services/cart';
import { animateToCart } from '../components/cart/CartAnimation';
import { notify } from '../components/UXFeedback';
import { getCompareIds, removeFromCompare, clearCompare, COMPARE_EVENT } from '../utils/compareStorage';
import { variantsByType } from '../utils/variants';

function ProductPlaceholder() {
  return <div className="wishlist-placeholder"><span>ZAMANI</span><small>PRODUCT IMAGE</small></div>;
}

const getPrice = (p) => Number(p.discount_price || p.price || 0);
const getRating = (p) => p.reviews?.length
  ? p.reviews.reduce((sum, r) => sum + Number(r.rating || 0), 0) / p.reviews.length
  : Number(p.rating || 0);

// One row per attribute; `render` gets a product and returns what goes in its column.
const ROWS = [
  { key: 'price', label: 'قیمت', render: (p) => {
    const price = getPrice(p);
    const hasDiscount = p.discount_price && Number(p.discount_price) < Number(p.price);
    return <div className="compare-price"><strong>{formatPrice(price)}</strong>{hasDiscount && <del>{formatPrice(p.price)}</del>}</div>;
  } },
  { key: 'brand', label: 'برند', render: (p) => p.brand?.name || 'ZAMANI' },
  { key: 'category', label: 'دسته‌بندی', render: (p) => p.category?.name || '—' },
  { key: 'colors', label: 'رنگ‌های موجود', render: (p) => {
    const values = variantsByType(p.variants || [], 'color').map((v) => v.value);
    return values.length ? values.join('، ') : '—';
  } },
  { key: 'sizes', label: 'سایزهای موجود', render: (p) => {
    const values = variantsByType(p.variants || [], 'size').map((v) => v.value);
    return values.length ? values.join('، ') : '—';
  } },
  { key: 'material', label: 'جنس پارچه', render: (p) => {
    const values = variantsByType(p.variants || [], 'material').map((v) => v.value);
    return values.length ? values.join('، ') : 'اعلام نشده';
  } },
  { key: 'stock', label: 'موجودی', render: (p) => {
    const stock = Number(p.stock || 0) + (p.variants || []).reduce((sum, v) => sum + Number(v.stock || 0), 0);
    return stock > 0
      ? <span className="compare-in-stock">موجود</span>
      : <span className="compare-out-stock">ناموجود</span>;
  } },
  { key: 'rating', label: 'امتیاز', render: (p) => {
    const rating = getRating(p);
    return rating ? `${rating.toFixed(1)} از ۵ (${p.reviews_count ?? p.reviews?.length ?? 0} نظر)` : 'بدون نظر';
  } },
];

// Rows where a lower/higher value is objectively "better" and worth calling out.
const BEST_OF = {
  price: { getValue: getPrice, pick: 'min', tag: 'مقرون‌به‌صرفه‌ترین' },
  rating: { getValue: getRating, pick: 'max', tag: 'بالاترین امتیاز' },
};

function computeBestIds(products) {
  const result = {};
  if (products.length < 2) return result;
  for (const [key, { getValue, pick }] of Object.entries(BEST_OF)) {
    let best = null;
    for (const p of products) {
      const value = getValue(p);
      if (!value) continue;
      if (best === null || (pick === 'min' ? value < best.value : value > best.value)) {
        best = { id: p.id, value };
      }
    }
    if (best) result[key] = best.id;
  }
  return result;
}

export default function Compare() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [adding, setAdding] = useState(null);

  const load = async () => {
    const ids = getCompareIds();
    if (!ids.length) { setProducts([]); setLoading(false); return; }
    setLoading(true); setError('');
    try {
      const response = await getCompareProducts(ids);
      const payload = response?.data?.data || response?.data || [];
      const byId = new Map(payload.map((p) => [Number(p.id), p]));
      // Keep the order the user added them in, drop any id the API didn't return
      // (e.g. a product that went out of status since it was added).
      setProducts(ids.map((id) => byId.get(Number(id))).filter(Boolean));
    } catch {
      setError('دریافت اطلاعات مقایسه با خطا مواجه شد.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    window.addEventListener(COMPARE_EVENT, load);
    return () => window.removeEventListener(COMPARE_EVENT, load);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const bestIds = useMemo(() => computeBestIds(products), [products]);

  const remove = (id) => removeFromCompare(id);

  const addCart = (product) => {
    setAdding(product.id);
    const items = readCart();
    const key = `${product.id}-compare`;
    const price = Number(product.discount_price || product.price || 0);
    const existing = items.find((item) => item.key === key);
    const image = product.image || product.images?.[0]?.image || '';
    const next = existing
      ? items.map((item) => item.key === key ? { ...item, quantity: Number(item.quantity || 0) + 1 } : item)
      : [...items, { key, productId: product.id, name: product.name, image, price, originalPrice: Number(product.price || price), discount: Math.max(0, Number(product.price || 0) - price), quantity: 1, selections: {} }];
    writeCart(next);
    window.dispatchEvent(new Event('zamani-cart-updated'));
    animateToCart(document.activeElement, image);
    notify('محصول به سبد خرید اضافه شد.');
    setTimeout(() => setAdding(null), 300);
  };

  if (loading) {
    return <main className="compare-page container">
      <div className="wishlist-state"><div className="wishlist-spinner" /><strong>در حال بارگذاری مقایسه...</strong></div>
    </main>;
  }

  if (error && !products.length) {
    return <main className="compare-page container">
      <div className="wishlist-state"><Icon name="compare" size={30} /><strong>{error}</strong><button className="btn btn-primary" onClick={load}>تلاش دوباره</button></div>
    </main>;
  }

  return <main className="compare-page container">
    <div className="wishlist-breadcrumb"><Link to="/">خانه</Link><Icon name="arrow" size={11} /><span>مقایسه محصولات</span></div>
    <header className="wishlist-head">
      <div>
        <h1 className="wishlist-title products-title-gradient">مقایسه محصولات</h1>
        <p>{products.length ? `${new Intl.NumberFormat('fa-IR').format(products.length)} محصول در مقایسه` : 'محصولاتی برای مقایسه انتخاب نشده است.'}</p>
      </div>
      {products.length > 0 && <button className="btn btn-outline" onClick={() => clearCompare()}>پاک کردن همه</button>}
    </header>

    {!products.length ? (
      <div className="wishlist-empty">
        <div className="wishlist-empty-icon"><Icon name="compare" size={28} /></div>
        <span className="eyebrow">COMPARE PRODUCTS</span>
        <h2>لیست مقایسه خالی است</h2>
        <p>از صفحه محصولات، روی آیکن مقایسه بزنید تا چند محصول را کنار هم ببینید.</p>
        <Link className="btn btn-primary" to="/products">مشاهده محصولات <Icon name="arrow" size={14} /></Link>
      </div>
    ) : (
      <div className="compare-table-wrap">
        <table className="compare-table">
          <thead>
            <tr>
              <th className="compare-row-label" />
              {products.map((product) => {
                const images = (product.images || []).map((i) => (typeof i === 'string' ? i : i?.image || i?.path)).filter(Boolean);
                const image = images[0] || product.image || '';
                return (
                  <th key={product.id} className="compare-col-head">
                    <button className="compare-remove" onClick={() => remove(product.id)} aria-label="حذف از مقایسه"><Icon name="x" size={14} /></button>
                    <Link to={`/products/${product.slug || product.id}`} className="compare-media">
                      {image ? <OptimizedImage src={image} alt={product.name} /> : <ProductPlaceholder />}
                    </Link>
                    <Link to={`/products/${product.slug || product.id}`} className="compare-name"><h3>{product.name}</h3></Link>
                    <button className="btn btn-outline compare-cart" disabled={adding === product.id} onClick={() => addCart(product)}>
                      {adding === product.id ? 'اضافه شد' : 'افزودن به سبد'} <Icon name="bag" size={14} />
                    </button>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {ROWS.map((row) => (
              <tr key={row.key}>
                <th className="compare-row-label">{row.label}</th>
                {products.map((product) => {
                  const isBest = products.length > 1 && bestIds[row.key] === product.id;
                  return (
                    <td key={product.id} className={isBest ? 'compare-cell-best' : ''}>
                      {isBest && <span className="compare-best-tag"><Icon name="check" size={9} />{BEST_OF[row.key].tag}</span>}
                      <div>{row.render(product)}</div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )}
  </main>;
}
