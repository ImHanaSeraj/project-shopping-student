import { useEffect, useRef } from 'react';

export default function ScrollProgressBar() {
  const progressRef = useRef(null);

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;

    let frame = null;

    const update = () => {
      frame = null;
      const scrollTop = window.scrollY || document.documentElement.scrollTop || 0;
      const scrollHeight = Math.max(
        document.documentElement.scrollHeight,
        document.body?.scrollHeight || 0
      );
      const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
      const maxScroll = Math.max(scrollHeight - viewportHeight, 0);
      const progress = maxScroll > 0 ? Math.min(Math.max(scrollTop / maxScroll, 0), 1) : 0;

      if (progressRef.current) {
        progressRef.current.style.transform = `scaleX(${progress})`;
      }
    };

    const requestUpdate = () => {
      if (frame === null) frame = window.requestAnimationFrame(update);
    };

    window.addEventListener('scroll', requestUpdate, { passive: true });
    window.addEventListener('resize', requestUpdate, { passive: true });
    window.addEventListener('load', requestUpdate);

    requestUpdate();

    return () => {
      window.removeEventListener('scroll', requestUpdate);
      window.removeEventListener('resize', requestUpdate);
      window.removeEventListener('load', requestUpdate);
      if (frame !== null) window.cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <div className="scroll-progress" aria-hidden="true">
      <div ref={progressRef} className="scroll-progress__bar" />
    </div>
  );
}
