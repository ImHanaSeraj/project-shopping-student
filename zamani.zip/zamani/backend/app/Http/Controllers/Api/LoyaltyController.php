<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\LoyaltyPointTransaction;
use App\Services\LoyaltyService;
use Illuminate\Http\Request;

class LoyaltyController extends Controller
{
    public function __construct(private LoyaltyService $loyalty) {}

    public function show(Request $request)
    {
        $user = $request->user();
        $available = $this->loyalty->availablePoints($user);

        return response()->json([
            'balance' => (int) $user->fresh()->loyalty_points_balance,
            'available_points' => $available,
            'point_value' => $this->loyalty->pointValue(),
            'earn_threshold' => $this->loyalty->earnThreshold(),
            'next_purchase_rule' => 'به ازای هر '.$this->loyalty->earnThreshold().' تومان خرید واجد شرایط، ۱ امتیاز',
            'redemption_rule' => 'هر امتیاز '.$this->loyalty->pointValue().' تومان تخفیف',
            'transactions' => LoyaltyPointTransaction::where('user_id', $user->id)
                ->latest()
                ->limit(30)
                ->get(),
        ]);
    }
}
