<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Services\PricingService;
use App\Services\InventoryService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use RuntimeException;

class CheckoutController extends Controller
{
    public function __construct(private PricingService $pricing, private InventoryService $inventory)
    {
    }

    /** Return an authoritative price preview calculated from the user's database cart. */
    public function summary(Request $request)
    {
        $data = $request->validate([
            'shipping_method' => ['required', Rule::in(['standard','express'])],
            'discount_code' => ['nullable','string','max:50'],
        ]);

        try {
            $cart = $request->user()->cart()->first();
            if (!$cart) {
                return response()->json(['message' => 'سبد خرید شما خالی است.'], 422);
            }

            return response()->json($this->pricing->calculateCart(
                $cart,
                $data['shipping_method'],
                $data['discount_code'] ?? null,
                false,
                $request->user()
            ));
        } catch (RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }
    }

    public function validateDiscount(Request $request)
    {
        $data = $request->validate([
            'code' => ['required','string','max:50'],
            'shipping_method' => ['nullable', Rule::in(['standard','express'])],
        ]);

        try {
            $cart = $request->user()->cart()->first();
            if (!$cart) {
                return response()->json(['valid' => false, 'message' => 'سبد خرید شما خالی است.'], 422);
            }

            // The subtotal is calculated from DB; client subtotal is never accepted.
            $summary = $this->pricing->calculateCart(
                $cart,
                $data['shipping_method'] ?? 'standard',
                $data['code'],
                false,
                $request->user()
            );

            return response()->json([
                'valid' => true,
                'code' => $summary['discount_code'],
                'discount' => $summary['discount'],
                'subtotal' => $summary['subtotal'],
                'shipping' => $summary['shipping'],
                'total' => $summary['total'],
                'message' => 'کد تخفیف با موفقیت اعمال شد.',
            ]);
        } catch (RuntimeException $e) {
            return response()->json(['valid' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'address_id' => ['required','integer', Rule::exists('addresses','id')],
            'shipping_method' => ['required', Rule::in(['standard','express'])],
            'discount_code' => ['nullable','string','max:50'],
        ]);

        $user = $request->user();

        // Optional (OTP_REQUIRE_FOR_ORDER) hardening: refuse to place an order
        // until the user has verified ownership of their phone number via OTP.
        if (config('otp.require_for_order') && !$user->phone_verified_at) {
            return response()->json([
                'message' => 'برای ثبت سفارش ابتدا باید شماره موبایل خود را با کد تایید پیامکی تایید کنید.',
                'code' => 'PHONE_NOT_VERIFIED',
            ], 422);
        }

        $address = $user->addresses()->whereKey($data['address_id'])->firstOrFail();

        return DB::transaction(function () use ($data, $user, $address) {
            $cart = $user->cart()->first();
            if (!$cart) {
                abort(422, 'سبد خرید شما خالی است.');
            }

            try {
                $summary = $this->pricing->calculateCart(
                    $cart,
                    $data['shipping_method'],
                    $data['discount_code'] ?? null,
                    true,
                    $user
                );
            } catch (RuntimeException $e) {
                abort(422, $e->getMessage());
            }

            // Everything below is a historical snapshot. Later edits to the user's
            // profile, address, product, variant, or prices must not rewrite this order.
            $order = Order::create([
                'user_id' => $user->id,
                'customer_name' => $user->name,
                'customer_email' => $user->email,
                'customer_phone' => $user->phone,
                'address_id' => $address->id,
                'receiver_name' => $address->receiver_name,
                'receiver_phone' => $address->phone,
                'shipping_province' => $address->province,
                'shipping_city' => $address->city,
                'shipping_address' => $address->address,
                'shipping_postal_code' => $address->postal_code,
                'shipping_method' => $summary['shipping_method'],
                'order_number' => 'ZM-' . now()->format('ymdHis') . '-' . random_int(100,999),
                // `total` is kept as the pre-discount merchandise subtotal for backward compatibility.
                'total' => $summary['subtotal'],
                'discount' => $summary['discount'],
                'discount_code' => $summary['discount_code'],
                'shipping_cost' => $summary['shipping'],
                'final_total' => $summary['total'],
                'status' => 'pending',
                'payment_status' => 'pending',
            ]);

            foreach ($summary['items'] as $item) {
                $product = Product::query()->whereKey($item['product_id'])->firstOrFail();
                $variant = $item['variant_id']
                    ? $product->variants()->whereKey($item['variant_id'])->firstOrFail()
                    : null;

                $order->items()->create([
                    'product_id' => $product->id,
                    'variant_id' => $variant?->id,
                    'product_name' => $product->name,
                    'product_sku' => $product->SKU,
                    'variant_sku' => $variant?->SKU,
                    'variant_size' => $variant?->size,
                    'variant_color' => $variant?->color,
                    'variant_image' => $variant?->image,
                    'quantity' => $item['quantity'],
                    'price' => $item['unit_price'],
                ]);
            }

            $order->payments()->create([
                'amount' => $summary['total'],
                'status' => 'pending',
                'gateway' => 'zarinpal',
            ]);

            // Reserve stock now, atomically with order creation. A payment failure/cancellation will release it.
            $this->inventory->reserve($order->load('items'));

            if ($summary['discount_id']) {
                $discount = \App\Models\Discount::query()->lockForUpdate()->findOrFail($summary['discount_id']);
                app(\App\Services\DiscountService::class)->recordUsage($discount, $user, $order, $summary['discount']);
            }

            // The cart's items are now captured as a permanent snapshot on the
            // order (product_name/SKU/price copied above), so the cart itself
            // is done its job here — empty it. Without this, the cart_items
            // rows kept existing after checkout, so the header/cart page kept
            // showing the same items as "still in the cart" even after a
            // successful payment.
            $cart->items()->delete();

            return response()->json([
                'message' => 'سفارش ایجاد شد.',
                'pricing' => [
                    'subtotal' => $summary['subtotal'],
                    'discount' => $summary['discount'],
                    'shipping' => $summary['shipping'],
                    'total' => $summary['total'],
                ],
                'order' => $order->load('items', 'address', 'payment'),
            ], 201);
        }, 3);
    }
}
