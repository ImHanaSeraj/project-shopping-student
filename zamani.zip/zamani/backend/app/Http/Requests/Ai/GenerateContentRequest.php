<?php

namespace App\Http\Requests\Ai;

use Illuminate\Foundation\Http\FormRequest;

class GenerateContentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->isManager() ?? false;
    }

    public function rules(): array
    {
        return [
            'raw_notes' => ['required', 'string', 'min:5', 'max:2000'],
            'category' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function messages(): array
    {
        return [
            'raw_notes.required' => 'وارد کردن یادداشت‌های اولیه محصول الزامی است.',
            'raw_notes.min' => 'یادداشت خیلی کوتاه است، توضیح بیشتری وارد کنید.',
        ];
    }
}
