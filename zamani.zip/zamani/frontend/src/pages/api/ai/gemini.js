const DEFAULT_MODEL = process.env.GEMINI_MODEL || 'gemini-3.6-flash';

function json(res, status, body) {
  res.status(status).json(body);
}

function extractText(payload) {
  return (payload?.candidates || [])
    .flatMap(c => c?.content?.parts || [])
    .map(p => p?.text || '')
    .join('')
    .trim();
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { message: 'Method not allowed' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return json(res, 500, { message: 'کلید Gemini در تنظیمات سرور تعریف نشده است.' });

  const { mode = 'chat', message = '', history = [], height_cm, weight_kg, available_sizes = [], product = {}, copy_type = 'full', current_text = '' } = req.body || {};

  if (mode === 'chat' && !String(message).trim()) {
    return json(res, 422, { message: 'پیام خالی است.' });
  }

  let contents;
  let generationConfig = { temperature: 0.35, maxOutputTokens: 700 };
  let systemInstruction;

  if (mode === 'product_copy') {
    const type = copy_type === 'short' ? 'short' : 'full';
    const productName = product?.name || 'محصول فروشگاه زمانی';
    const category = product?.category || '';
    const brand = product?.brand || '';
    const existing = String(current_text || '').slice(0, 6000);
    systemInstruction = `تو نویسنده حرفه‌ای محتوای فروشگاه اینترنتی ZAMANI هستی. برای محصولی که اطلاعاتش داده می‌شود، متن فارسی طبیعی، دقیق و قابل استفاده در صفحه محصول بنویس. اطلاعات فنی یا ویژگی‌هایی که داده نشده‌اند را حدس نزن. از تکرار بی‌دلیل نام محصول و عبارت‌های تبلیغاتی اغراق‌آمیز خودداری کن. ${type === 'short' ? 'توضیح کوتاه را در 1 تا 3 جمله و حدود 25 تا 60 کلمه بنویس.' : 'توضیحات کامل را در چند پاراگراف منظم و خوانا بنویس؛ مزایا، کاربرد، سازگاری یا ویژگی‌های داده‌شده را توضیح بده و در صورت مناسب بودن از فهرست بولت استفاده کن.'} متن را فقط به صورت JSON معتبر با کلید text برگردان.`;
    contents = [{ role: 'user', parts: [{ text: `نوع متن: ${type === 'short' ? 'توضیح کوتاه' : 'توضیحات کامل'}\nنام محصول: ${productName}\nدسته: ${category}\nبرند: ${brand}\nمتن فعلی برای تکمیل/بهبود: ${existing || 'هنوز متنی نوشته نشده است.'}` }] }];
    generationConfig = { ...generationConfig, maxOutputTokens: type === 'short' ? 250 : 900 };
  } else if (mode === 'size') {
    const sizes = Array.isArray(available_sizes) ? available_sizes.filter(Boolean) : [];
    const productName = product?.name || 'محصول فروشگاه زمانی';
    const variantInfo = Array.isArray(product?.variants) ? product.variants : [];
    systemInstruction = `تو دستیار هوشمند انتخاب سایز فروشگاه ZAMANI هستی.\nبرای محصول «${productName}» بر اساس قد و وزن کاربر یک سایز تقریبی پیشنهاد بده.\nفقط از سایزهای موجود در فهرست استفاده کن. اگر داده کافی نیست، نزدیک‌ترین گزینه را انتخاب کن.\nاین پیشنهاد پزشکی نیست و فقط راهنمای خرید تقریبی است.\nپاسخ را فقط به صورت JSON معتبر با کلیدهای size, confidence, alternative_size, reason بده. confidence یکی از low, medium, high باشد. alternative_size در صورت نبود گزینه جایگزین null باشد.\nسایزهای موجود: ${JSON.stringify(sizes)}\nاطلاعات واریانت‌ها: ${JSON.stringify(variantInfo).slice(0, 5000)}`;
    contents = [{ role: 'user', parts: [{ text: `قد: ${height_cm} سانتی‌متر\nوزن: ${weight_kg} کیلوگرم\nسایزهای موجود: ${JSON.stringify(sizes)}` }] }];
    generationConfig = { ...generationConfig };
  } else {
    systemInstruction = `تو دستیار هوشمند فروشگاه اینترنتی ZAMANI هستی. به فارسی روان و کوتاه پاسخ بده.\nدر انتخاب لوازم جانبی موبایل و لپ‌تاپ، مقایسه محصولات، ویژگی‌ها، سازگاری و راهنمای خرید کمک کن.\nاگر اطلاعات یک محصول را نداری، آن را حدس نزن و از کاربر بخواه نام یا لینک محصول را بفرستد.\nلحن دوستانه، حرفه‌ای و فروشگاهی داشته باش؛ تبلیغ اغراق‌آمیز نکن.`;
    const safeHistory = Array.isArray(history) ? history.slice(-12).map(item => ({
      role: item?.role === 'assistant' || item?.role === 'model' ? 'model' : 'user',
      parts: [{ text: String(item?.content || '').slice(0, 4000) }]
    })).filter(item => item.parts[0].text.trim()) : [];
    contents = [...safeHistory, { role: 'user', parts: [{ text: String(message).trim().slice(0, 4000) }] }];
  }

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(DEFAULT_MODEL)}:generateContent`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify({ contents, systemInstruction: { parts: [{ text: systemInstruction }] }, generationConfig }),
    });

    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      return json(res, response.status, {
        message: payload?.error?.message || 'ارتباط با Gemini برقرار نشد.',
        provider: 'gemini'
      });
    }

    const text = extractText(payload);
    if (!text) return json(res, 502, { message: 'Gemini پاسخ متنی معتبری برنگرداند.' });

    if (mode === 'size' || mode === 'product_copy') {
      let data;
      try { data = JSON.parse(text); } catch { data = null; }
      if (!data) {
        const cleaned = text.replace(/^```(?:json|text|markdown)?\s*/i, '').replace(/\s*```$/i, '').trim();
        try { data = JSON.parse(cleaned); } catch { data = null; }
      }
      if (mode === 'size') {
        if (!data?.size) return json(res, 502, { message: 'پاسخ پیشنهاد سایز از Gemini معتبر نبود.' });
      } else {
        // Product-copy generation is text-first. If Gemini ignores the JSON request,
        // use its plain response instead of showing a false "invalid structure" error.
        if (!data?.text) data = { text: text.replace(/^```(?:text|markdown)?\s*/i, '').replace(/\s*```$/i, '').trim() };
        if (!data.text) return json(res, 502, { message: 'پاسخ تکمیل متن از Gemini خالی بود.' });
      }
      return json(res, 200, { data, provider: 'gemini', model: DEFAULT_MODEL });
    }

    return json(res, 200, { reply: text, provider: 'gemini', model: DEFAULT_MODEL });
  } catch (error) {
    return json(res, 500, { message: error?.message || 'خطا در اتصال به Gemini.' });
  }
}
