import InfoPages from '../views/InfoPages';
export default function Guide(){ return <InfoPages kind="guide"/>; }
