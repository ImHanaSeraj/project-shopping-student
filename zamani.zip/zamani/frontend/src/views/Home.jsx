import SEOHead from '../components/SEOHead';
import { useEffect, useState } from 'react';
import Link from '../components/SafeLink';

import Icon from '../components/Icon';
import CloudOrbit from '../components/CloudOrbit';
import ProductCard from '../components/products/ProductCard';
import { getCategories, getProducts, getPublicSettings } from '../services/productApi';
import { resolveMediaUrl } from '../utils/media';

// تصاویر دسته‌بندی‌های محبوب — از public/images/Popular Products
// آدرس فایل‌ها روی سیستم شما: frontend/public/images/Popular Products/<نام فایل>
const POPULAR_PRODUCTS_DIR = '/images/Popular%20Products';
const POPULAR_CATEGORY_IMAGES = [
  { keywords: ['مانتو', 'manto'], file: 'manto.png', label: 'مانتو' },
  { keywords: ['لباس زیر', 'lebas zir'], file: 'lebas-zir.png', label: 'لباس زیر و تاپ' },
  { keywords: ['جوراب', 'jorab'], file: 'jorab.png', label: 'جوراب' },
  { keywords: ['پیراهن', 'pirahan'], file: 'pirahan.png', label: 'پیراهن' },
  { keywords: ['ست زنانه', 'setzanane', 'set zanane', 'set zananeh', 'set-zananeh'], file: 'setzanane.png', label: 'ست زنانه' },
  { keywords: ['شلوار', 'shalvar'], file: 'shalvar.png', label: 'شلوار' },
  { keywords: ['شومیز', 'shomiz'], file: 'shomiz.png', label: 'شومیز' },
  { keywords: ['تیشرت', 'تی‌شرت', 'تی شرت', 'شلوارک', 'tshirt', 't-shirt', 'shalvarak'], file: 'tshirt-shalvarak.png', label: 'تیشرت و شلوارک' },
];

const DEFAULT_CATEGORY_IMAGE = 'https://images.pexels.com/photos/4947543/pexels-photo-4947543.jpeg?auto=compress&cs=tinysrgb&w=400';

// برای هر دسته‌بندی چند مسیر ممکن رو برمی‌گردونه؛ اگه اولی 404 بشه (عکس اونجا نبود)
// خودکار میره سراغ بعدی، تا وقتی عکس واقعی پیدا بشه یا به عکس پیش‌فرض برسه.
function findPopularCategory(category = {}) {
  const haystack = `${category.slug || ''} ${category.name || ''}`.toLowerCase().replace(/[-_]/g, ' ');
  return POPULAR_CATEGORY_IMAGES.find(item => item.keywords.some(k => haystack.includes(k.toLowerCase())));
}

function categoryImageCandidates(category = {}) {
  const found = findPopularCategory(category);

  if (found) {
    return [`${POPULAR_PRODUCTS_DIR}/${found.file}`];
  }

  return [DEFAULT_CATEGORY_IMAGE];
}

function handleCategoryImgError(e) {
  const list = JSON.parse(e.currentTarget.dataset.candidates || '[]');
  const next = Number(e.currentTarget.dataset.idx || '0') + 1;
  if (next < list.length) {
    e.currentTarget.dataset.idx = String(next);
    e.currentTarget.src = list[next];
  }
}

function ProductSection({ id, title, eyebrow, products, linkLabel = 'مشاهده همه' }) {
  return <section className="section container" id={id}><SEOHead title="پوشاک زنانه زمانی" description="فروشگاه آنلاین پوشاک زنانه زمانی؛ انتخابی مینیمال، باکیفیت و اصیل." path="/" />
    <div className="section-heading">
      <div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2></div>
      <Link href="/products">{linkLabel} <Icon name="arrow" size={15} /></Link>
    </div>
    <div className="product-grid">{products.map(product => <ProductCard key={product.id} product={product} />)}</div>
  </section>;
}


function SpecialOffersSection({ products }) {
  return <section className="special-offers-home container" aria-label="فروش ویژه و پیشنهادهای زمان‌دار">
    <div className="special-offers-frame">
      <div className="special-offers-shell">
        <div className="special-offers-intro">
          <h2>فروش ویژه</h2>
          <p>تخفیف‌های منتخب زمانی برای مدت محدود. تا پایان زمان پیشنهاد، انتخابت را نهایی کن.</p>
          <div className="special-countdown-home" data-special-countdown="true">
            <div><strong>--</strong><span>روز</span></div><i>:</i><div><strong>--</strong><span>ساعت</span></div><i>:</i><div><strong>--</strong><span>دقیقه</span></div><i>:</i><div><strong>--</strong><span>ثانیه</span></div>
          </div>
          <Link href="/special-offers" className="btn btn-primary">مشاهده همه فروش ویژه <Icon name="arrow" size={16}/></Link>
        </div>
        <div className="special-offers-products">
          {products.length ? products.slice(0, 4).map(product => <ProductCard key={product.id} product={product} />) : <div className="special-offers-empty">در حال آماده‌سازی پیشنهادهای ویژه...</div>}
        </div>
      </div>
    </div>
  </section>;
}

function useSpecialOfferCountdown() {
  useEffect(() => {
    const root = document.querySelector('[data-special-countdown="true"]');
    if (!root) return;
    // زمان پایان کمپین از پنل ادمین (تنظیمات → special_offer_end_at) خونده میشه.
    // اگه هنوز چیزی تنظیم نشده باشه، از این تاریخ پیش‌فرض استفاده میشه.
    let end = new Date('2026-09-21T23:59:59+03:30').getTime();
    let cancelled = false;
    let timer = null;

    const tick = () => {
      const diff = Math.max(0, end - Date.now());
      const totalSeconds = Math.floor(diff / 1000);
      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor((totalSeconds % 86400) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;
      const values = [days, hours, minutes, seconds].map((value, i) =>
        new Intl.NumberFormat('fa-IR', { minimumIntegerDigits: i === 0 ? 1 : 2, useGrouping: false }).format(value)
      );
      root.querySelectorAll('strong').forEach((el, i) => { el.textContent = values[i]; });
      root.classList.toggle('is-expired', diff <= 0);
    };

    tick();
    timer = setInterval(tick, 1000);

    getPublicSettings().then(({ data }) => {
      const value = data?.data?.special_offer_end_at;
      if (cancelled || !value) return;
      // ورودی input[type=datetime-local] فرمت "YYYY-MM-DDTHH:mm" (بدون منطقه‌زمانی) میده؛
      // اون رو به‌وقت تهران در نظر می‌گیریم، هماهنگ با مقدار پیش‌فرض بالا.
      const hasOffset = /[+-]\d{2}:?\d{2}$|Z$/.test(value);
      const parsed = new Date(hasOffset ? value : `${value}:00+03:30`).getTime();
      if (!Number.isNaN(parsed)) { end = parsed; tick(); }
    }).catch(() => {});

    return () => { cancelled = true; clearInterval(timer); };
  }, []);
}

function Home() {
  useSpecialOfferCountdown();
  const [products, setProducts] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [discounted, setDiscounted] = useState([]);
  const [latest, setLatest] = useState([]);
  const [apiCategories, setApiCategories] = useState([]);
  const [heroSlide, setHeroSlide] = useState(0);
  const heroSlidesCount = 3;

  useEffect(() => {
    const timer = setInterval(() => {
      setHeroSlide(current => (current + 1) % heroSlidesCount);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    getProducts({ per_page: 8 }).then(({ data }) => {
      const items = data?.data || data;
      if (Array.isArray(items) && items.length) setProducts(items);
    }).catch(() => {});
    getProducts({ per_page: 4, feature: 'featured' }).then(({ data }) => setFeatured(data?.data || data || [])).catch(() => {});
    getProducts({ per_page: 4, feature: 'discount' }).then(({ data }) => setDiscounted(data?.data || data || [])).catch(() => {});
    getProducts({ per_page: 4, sort: 'latest' }).then(({ data }) => setLatest(data?.data || data || [])).catch(() => {});
    getCategories().then(({ data }) => {
      const items = data?.data || data;
      if (Array.isArray(items) && items.length) setApiCategories(items);
    }).catch(err => console.error('[Home] /categories request failed:', err?.message || err));
  }, []);


  // دسته‌بندی‌ها از دیتابیس (API) می‌آیند. فقط اگر API هیچ دسته‌ای برنگرداند
  // (خطا / دیتابیس خالی) لیست ثابت به‌عنوان fallback نمایش داده می‌شود.
  const categoryCards = apiCategories.length
    ? apiCategories.map(cat => ({
        key: cat.id,
        href: cat.slug ? `/categories/${cat.slug}` : `/products?category=${cat.id}`,
        title: cat.name,
        candidates: categoryImageCandidates(cat),
      }))
    : POPULAR_CATEGORY_IMAGES.map(p => ({
        key: p.file,
        href: '/categories',
        title: p.label,
        candidates: [`${POPULAR_PRODUCTS_DIR}/${p.file}`],
      }));

  return <div className="home-page">
    <section className="hero container hero-slider" aria-label="پیشنهادهای ویژه زمانی">
      {[
        ['NEW SEASON', 'زیبایی در\nسادگی و اصالت', 'مجموعه جدید زمانی؛ انتخاب‌هایی مینیمال، زنانه و ماندگار برای شروع یک فصل تازه.', 'مشاهده جدیدترین‌ها', '/latest'],
        ['SPECIAL EDIT', 'استایل خودت را\nدوباره بساز', 'قطعاتی که به‌راحتی کنار هم قرار می‌گیرند و برای هر روز، یک انتخاب شیک می‌سازند.', 'محصولات', '/products'],
        ['تخفیف ویژه', 'انتخاب‌های منتخب\nتا ۳۰٪ تخفیف', 'تخفیف محدود روی بخشی از محصولات منتخب؛ فرصت خوبی برای تکمیل استایل شما.', 'محصولات', '/products']
      ].map(([eyebrow, title, text, cta, href], i) => i === heroSlide ? (
        <article className="hero-slide hero-slide-active" key={eyebrow}>
          <div className="hero-copy">
            <span className="eyebrow">{eyebrow} · ZAMANI</span>
            <h1 className="hero-title-gradient">{title.split('\n').map((line, j) => <span key={j}>{line}{j === 0 && <br />}</span>)}</h1>
            <p>{text}</p>
            <div className="hero-actions">
              <Link href={href} className="btn btn-primary">{cta} <Icon name="arrow" size={17}/></Link>
              <Link href="/categories" className="btn btn-outline">دسته‌بندی‌ها</Link>
            </div>

          </div>
          <div className={`hero-image hero-art hero-art-${i}`}>
            <img className="hero-image-bg" src={`/images/banners/${i === 0 ? "home-banner" : i === 1 ? "home-banner2" : "home-banner3"}.png`} alt="" aria-hidden="true" />
            <img className="hero-image-main" src={`/images/banners/${i === 0 ? "home-banner" : i === 1 ? "home-banner2" : "home-banner3"}.png`} alt="ZAMANI women fashion collection" />
          </div>
        </article>
      ) : null)}
    </section>

    <section className="trust-section container">
      <div className="trust-card"><Icon name="shield" /><div><strong>ضمانت اصالت کالا</strong><small>کالای اورجینال و باکیفیت</small></div></div>
      <div className="trust-card"><Icon name="truck" /><div><strong>ارسال سریع</strong><small>ارسال به سراسر کشور</small></div></div>
      <div className="trust-card"><Icon name="support" /><div><strong>پشتیبانی ۲۴/۷</strong><small>پاسخگوی شما هستیم</small></div></div>
      <div className="trust-card"><Icon name="card" /><div><strong>پرداخت امن</strong><small>تجربه خرید مطمئن</small></div></div>
    </section>

    <SpecialOffersSection products={discounted} />

    <section className="section container" id="categories">
      <div className="section-heading"><div><h2>دسته‌بندی‌های محبوب</h2></div><Link href="/products">مشاهده همه <Icon name="arrow" size={15} /></Link></div>
      <div className="category-circle-grid">{categoryCards.map(card => (
         <Link className="category-circle-item" href={card.href} key={card.key}>
           <span className="category-circle-wrap">
             <CloudOrbit />
             <span className="category-circle">
               <img src={card.candidates[0]} data-candidates={JSON.stringify(card.candidates)} data-idx="0" onError={handleCategoryImgError} alt={card.title} loading="eager" decoding="async" style={{ width: '100%', height: '100%', minWidth: '100%', minHeight: '100%', maxWidth: '100%', maxHeight: '100%', display: 'block', objectFit: 'cover', objectPosition: 'center center', borderRadius: '50%' }} />
             </span>
           </span>
           <h3>{card.title}</h3>
         </Link>
       ))}</div>
     </section>

    <ProductSection id="products" title="محبوب‌ترین‌ها" products={featured} />
    <ProductSection id="new" title="جدیدترین‌ها" products={latest} />

  </div>;
}

export default Home;
