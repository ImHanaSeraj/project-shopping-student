import Link from 'next/link';
/**
 * Next.js Link guard.
 *
 * Some UI data comes from APIs and can be temporarily undefined while a
 * component is rendering. Next.js 15 throws when Link receives an undefined
 * href, so normalize empty/invalid values to a safe local route instead of
 * crashing the whole page.
 */
export default function SafeLink({ href, children, ...props }) {
  const safeHref =
    typeof href === 'string' && href.trim()
      ? href
      : href && typeof href === 'object'
        ? href
        : '/';

  return (
    <Link href={safeHref} {...props}>
      {children}
    </Link>
  );
}

