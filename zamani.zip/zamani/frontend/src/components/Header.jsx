import OptimizedImage from './OptimizedImage';
import { useEffect, useState } from 'react';
import Link from './SafeLink';
import {useLocation} from '../utils/routerCompat';
import Icon from './Icon';
import { useAuth } from '../context/AuthContext';
import { fetchCart } from '../services/cart';
import { getCompareIds, COMPARE_EVENT } from '../utils/compareStorage';

const navItems = [
  ['خانه', '/'],
  ['محصولات', '/products'],
  ['دسته‌بندی‌ها', '/categories'],
  ['جدیدترین‌ها', '/latest'],
  ['پرفروش‌ترین‌ها', '/bestsellers'],
  ['درباره ما', '/about'],
  ['تماس با ما', '/contact'],
];

function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const [wishlistCount, setWishlistCount] = useState(0);
  const [compareCount, setCompareCount] = useState(0);
  const location = useLocation();
  const { user } = useAuth();
  const requireLogin = (event, target) => {
    if (user) return;
    event.preventDefault();
    setCartOpen(false);
    window.location.href = `/login?redirect=${encodeURIComponent(target)}`;
  };

  useEffect(() => {
    // Logged-in users' carts live on the server (see services/cart.js
    // addCartItem, which posts to /cart/items and never touches
    // localStorage), so the header has to read from there too — reading
    // only localStorage made the badge/drawer look empty even right after
    // a successful "add to cart".
    let cancelled = false;
    const syncCart = async () => {
      if (user) {
        try {
          const items = await fetchCart();
          if (cancelled) return;
          setCartItems(items);
          setCartCount(items.reduce((sum, item) => sum + Number(item.quantity || 0), 0));
        } catch {
          if (!cancelled) { setCartItems([]); setCartCount(0); }
        }
      } else {
        const nextCart = JSON.parse(localStorage.getItem('zamani_cart') || '[]');
        setCartItems(nextCart);
        setCartCount(nextCart.reduce((sum, item) => sum + Number(item.quantity || 0), 0));
      }
    };
    const syncWishlist = () => setWishlistCount(JSON.parse(localStorage.getItem('zamani_wishlist') || '[]').length);
    const syncCompare = () => setCompareCount(getCompareIds().length);
    const sync = () => { syncCart(); syncWishlist(); syncCompare(); };
    sync();
    window.addEventListener('zamani-cart-updated', sync);
    window.addEventListener('zamani-wishlist-updated', syncWishlist);
    window.addEventListener(COMPARE_EVENT, syncCompare);
    window.addEventListener('storage', sync);
    return () => {
      cancelled = true;
      window.removeEventListener('zamani-cart-updated', sync);
      window.removeEventListener('zamani-wishlist-updated', syncWishlist);
      window.removeEventListener(COMPARE_EVENT, syncCompare);
      window.removeEventListener('storage', sync);
    };
  }, [user]);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname, location.search]);

  useEffect(() => {
    if (!mobileOpen) return;
    const onKeyDown = (event) => { if (event.key === 'Escape') setMobileOpen(false); };
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [mobileOpen]);

  return (
    <>
      <header className="site-header">
        <div className="top-bar">
          <div><Icon name="truck" size={15} /> ارسال رایگان برای خرید بالای ۴ میلیون تومان</div>
          <div><Icon name="shield" size={15} /> ضمانت اصالت کالا</div>
          <div><Icon name="support" size={15} /> پشتیبانی ۲۴/۷</div>
          <div><Icon name="card" size={15} /> ۳ روز ضمانت بازگشت</div>
        </div>

        <div className="header-main container">
          <div className="header-side header-side-start">
            <button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)} aria-label="باز کردن منو"><Icon name="menu" /></button>
          </div>

          <Link href="/" className="brand brand-centered" aria-label="کالکشن زمانی">
            <span className="brand-word-fa">کالکشن زمانی</span>
          </Link>

          <div className="header-side header-side-end">
            <Link href="/account" className="account-link"><Icon name="user" size={18} /><span>{user?.name || 'ورود / ثبت‌نام'}</span></Link>
            <Link href="/wishlist" onClick={(e) => requireLogin(e, '/wishlist')} className="icon-button cart-button desktop-only" aria-label="علاقه‌مندی‌ها"><Icon name="heart" />{wishlistCount > 0 && <b>{wishlistCount}</b>}</Link>
            <Link href="/compare" className="icon-button cart-button desktop-only" aria-label="مقایسه محصولات"><Icon name="compare" />{compareCount > 0 && <b>{compareCount}</b>}</Link>
            <button onClick={(e) => { if (!user) { requireLogin(e, '/cart'); return; } setCartOpen(true); }} className="icon-button cart-button" aria-label="سبد خرید"><Icon name="bag" />{cartCount > 0 && <b>{cartCount}</b>}</button>
          </div>
        </div>

        <nav className="desktop-nav" aria-label="منوی اصلی">
          <div className="container nav-inner">
            {navItems.map(([label, href]) => <Link key={label} href={href} className={(href === '/' ? location.pathname === '/' : location.pathname.startsWith(href)) ? 'active' : ''}>{label}</Link>)}
          </div>
        </nav>
      </header>

      {cartOpen && <>
        <button className="cart-drawer-backdrop" onClick={() => setCartOpen(false)} aria-label="بستن سبد خرید" />
        <aside className="cart-drawer" aria-label="سبد خرید">
          <div className="cart-drawer-head"><div><span className="eyebrow">SHOPPING BAG</span><strong>سبد خرید</strong></div><button className="icon-button" onClick={() => setCartOpen(false)} aria-label="بستن"><Icon name="x"/></button></div>
          <div className="cart-drawer-body">{cartItems.length ? cartItems.map(item => <div className="cart-drawer-item" key={item.key || item.id}><div className="cart-drawer-thumb">{item.image ? <OptimizedImage src={item.image} alt="" /> : <span>Z</span>}</div><div><strong>{item.name}</strong><small>{item.selections?.color || item.selections?.size ? [item.selections?.color, item.selections?.size].filter(Boolean).join(' / ') : 'محصول'}</small><b>{new Intl.NumberFormat('fa-IR').format(Number(item.price||0)*Number(item.quantity||0))} تومان</b></div></div>) : <div className="cart-drawer-empty"><Icon name="bag" size={28}/><strong>سبد خرید خالی است</strong><span>هنوز محصولی به سبد اضافه نکرده‌اید.</span></div>}</div>
          {cartItems.length > 0 && <div className="cart-drawer-foot"><div><span>مجموع</span><strong>{new Intl.NumberFormat('fa-IR').format(cartItems.reduce((sum,item)=>sum+Number(item.price||0)*Number(item.quantity||0),0))} تومان</strong></div><Link className="btn btn-primary" href="/cart" onClick={(e) => { requireLogin(e, '/cart'); setCartOpen(false); }}>مشاهده سبد خرید <Icon name="arrow" size={14}/></Link></div>}
        </aside>
      </>}


      <aside className={`mobile-drawer ${mobileOpen ? 'is-open' : ''}`} aria-hidden={!mobileOpen}>
        <div className="drawer-head"><Link href="/" className="mobile-brand"><span>کالکشن زمانی</span></Link><button className="icon-button" onClick={() => setMobileOpen(false)} aria-label="بستن"><Icon name="x" /></button></div>
        <div className="drawer-account"><Icon name="user" /><div><strong>حساب کاربری</strong><Link href="/account" onClick={() => setMobileOpen(false)}>حساب کاربری</Link></div></div>
        <nav>{navItems.map(([label, href]) => <Link key={label} href={href} onClick={() => setMobileOpen(false)}>{label}</Link>)}</nav><div className="drawer-contact"><span>پشتیبانی و تماس</span><a href="mailto:sjack0324@gmail.com">sjack0324@gmail.com</a></div>
      </aside>
      {mobileOpen && <button className="drawer-backdrop" onClick={() => setMobileOpen(false)} aria-label="بستن منو" />}
    </>
  );
}

export default Header;
