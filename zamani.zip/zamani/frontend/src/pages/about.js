import InfoPages from '../views/InfoPages';
export default function About(){ return <InfoPages kind="about"/>; }
