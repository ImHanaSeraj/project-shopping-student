<?php

namespace App\Http\Requests\Ai;

use Illuminate\Foundation\Http\FormRequest;

class ChatbotSendRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; 
    }

    public function rules(): array
    {
        return [
            'message' => ['required', 'string', 'min:1', 'max:2000'],
            'conversation_id' => ['nullable', 'integer', 'exists:chat_conversations,id'],
            'session_id' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function messages(): array
    {
        return [
            'message.required' => 'وارد کردن پیام الزامی است.',
            'message.max' => 'پیام نباید بیشتر از ۲۰۰۰ کاراکتر باشد.',
            'conversation_id.exists' => 'گفتگوی موردنظر یافت نشد.',
        ];
    }
}
