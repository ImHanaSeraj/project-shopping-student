import React,{useState} from "react";
import {useNavigate} from '../../utils/routerCompat';
import {useAuth} from "../../context/AuthContext";

export default function AdminLogin(){
 const {login}=useAuth();
 const navigate=useNavigate();
 const [form,setForm]=useState({login:"",password:""});
 const [err,setErr]=useState("");
 const [loading,setLoading]=useState(false);
 async function submit(e){
  e.preventDefault(); setLoading(true); setErr("");
  try{
   const u=await login(form);
   const user=u?.user || u;
   if(user?.role==="admin" || user?.role==="manager" || user?.is_admin===true) navigate("/admin");
   else {setErr("این حساب دسترسی مدیریت ندارد");}
  }catch(e){setErr("اطلاعات ورود صحیح نیست");}
  setLoading(false);
 }
 return <div className="admin-login">
  <form onSubmit={submit} className="admin-card">
   <h1>ورود مدیریت</h1>
   <input placeholder="ایمیل یا شماره موبایل" value={form.login} onChange={e=>setForm({...form,login:e.target.value})}/>
   <input type="password" placeholder="رمز عبور" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
   {err&&<p>{err}</p>}
   <button disabled={loading}>{loading?"در حال ورود":"ورود به پنل"}</button>
  </form>
 </div>
}
