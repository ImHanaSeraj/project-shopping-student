import { useEffect, useRef, useState } from 'react';
import Icon from '../../components/Icon';
import { adminApi } from '../../services/admin';
import { getEcho } from '../../services/chat';
import { useAuth } from '../../context/AuthContext';

const tabLabel = { pending: 'در انتظار', mine: 'گفتگوهای من', closed: 'بسته‌شده' };

export default function SupportChat() {
  const { user } = useAuth();
  const [inbox, setInbox] = useState({ pending: [], mine: [], closed: [] });
  const [tab, setTab] = useState('pending');
  const [active, setActive] = useState(null); // full conversation with messages
  const [reply, setReply] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const listRef = useRef(null);

  const loadInbox = () => adminApi.supportChatInbox().then(({ data }) => setInbox(data.data)).catch(() => {});

  useEffect(() => { loadInbox(); }, []);

  // Live queue updates: any admin claiming/closing a chat, or a new escalation
  // coming in, refreshes everyone's inbox instantly instead of waiting on a poll.
  useEffect(() => {
    const echo = getEcho();
    if (!echo) return;
    const channel = echo.private('admin.chat');
    channel.listen('.conversation.updated', () => {
      loadInbox();
      if (active) refreshActive(active.id);
    });
    return () => echo.leave('admin.chat');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active?.id]);

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [active?.messages]);

  const refreshActive = (id) => {
    adminApi.supportChatConversation(id).then(({ data }) => setActive(data.data)).catch(() => {});
  };

  // Subscribe to the open conversation's own message stream while it's open.
  useEffect(() => {
    if (!active?.session_id) return;
    const echo = getEcho();
    if (!echo) return;
    const channel = echo.channel('chat.' + active.session_id);
    channel.listen('.message.created', (e) => {
      setActive((prev) => (prev && prev.id === e.conversation_id
        ? { ...prev, messages: prev.messages.some((m) => m.id === e.id) ? prev.messages : [...prev.messages, e] }
        : prev));
    });
    return () => echo.leave('chat.' + active.session_id);
  }, [active?.session_id]);

  const open = (row) => refreshActive(row.id);

  const claim = async (row) => {
    setBusy(true); setError('');
    try {
      await adminApi.supportChatClaim(row.id);
      await loadInbox();
      refreshActive(row.id);
      setTab('mine');
    } catch (e) {
      setError(e.response?.data?.message || 'این گفتگو دیگر در انتظار نیست.');
    } finally { setBusy(false); }
  };

  const sendReply = async (e) => {
    e.preventDefault();
    const text = reply.trim();
    if (!text || !active) return;
    setReply('');
    try {
      await adminApi.supportChatReply(active.id, text);
    } catch {
      setError('ارسال پاسخ انجام نشد.');
    }
  };

  const closeChat = async () => {
    if (!active) return;
    await adminApi.supportChatClose(active.id);
    setActive(null);
    loadInbox();
  };

  const rows = inbox[tab] || [];

  return (
    <div className="admin-section support-chat-page">
      <div className="support-chat-layout">
        <div className="support-chat-list">
          <div className="admin-tabs">
            {Object.keys(tabLabel).map((k) => (
              <button key={k} className={tab === k ? 'active' : ''} onClick={() => setTab(k)}>
                {tabLabel[k]} {inbox[k]?.length ? <small>({inbox[k].length})</small> : null}
              </button>
            ))}
          </div>
          {rows.length === 0 && <p className="support-chat-empty">موردی برای نمایش نیست.</p>}
          {rows.map((row) => (
            <button
              key={row.id}
              className={`support-chat-row ${active?.id === row.id ? 'is-active' : ''}`}
              onClick={() => open(row)}
            >
              <div className="support-chat-row-head">
                <strong>{row.customer_name}</strong>
                {tab === 'pending' && (
                  <span className="support-chat-claim" onClick={(e) => { e.stopPropagation(); claim(row); }}>
                    {busy ? '...' : 'در دست گرفتن'}
                  </span>
                )}
              </div>
              <p>{row.last_message || '—'}</p>
            </button>
          ))}
        </div>
        <div className="support-chat-thread">
          {!active ? (
            <div className="support-chat-placeholder"><Icon name="support" size={32} /><p>گفتگویی را برای مشاهده انتخاب کنید.</p></div>
          ) : (
            <>
              <div className="support-chat-thread-head">
                <div><strong>{active.customer_name}</strong><small>وضعیت: {active.status === 'active' ? 'فعال' : active.status === 'pending' ? 'در انتظار' : 'بسته‌شده'}</small></div>
                {active.status === 'pending' && <button className="admin-btn" onClick={() => claim(active)}>در دست گرفتن</button>}
                {active.status === 'active' && active.assigned_admin === user?.name && <button className="admin-btn danger" onClick={closeChat}>بستن گفتگو</button>}
              </div>
              <div className="support-chat-messages" ref={listRef}>
                {active.messages.map((m) => (
                  <div key={m.id} className={`chat-bubble chat-bubble-${m.role}`}>{m.content}</div>
                ))}
              </div>
              {active.status === 'active' && active.assigned_admin === user?.name ? (
                <form className="support-chat-form" onSubmit={sendReply}>
                  <input value={reply} onChange={(e) => setReply(e.target.value)} placeholder="پاسخ خود را بنویسید…" maxLength={2000} />
                  <button type="submit" disabled={!reply.trim()}><Icon name="arrow" /></button>
                </form>
              ) : (
                <p className="support-chat-hint">
                  {active.status === 'pending' ? 'برای پاسخ دادن، ابتدا این گفتگو را در دست بگیرید.' : 'این گفتگو در حال حاضر قابل پاسخ‌دهی نیست.'}
                </p>
              )}
            </>
          )}
        </div>
      </div>
      {error && <div className="admin-notice error">{error}</div>}
    </div>
  );
}
