import AdminLogin from '../../views/admin/AdminLogin';
export default AdminLogin;
