import { useEffect, useState } from 'react';

export default function ScrollAwareHeader() {
  const [state, setState] = useState('top');
  useEffect(() => {
    let last = window.scrollY || 0;
    let frame = null;
    const update = () => {
      frame = null;
      const y = window.scrollY || 0;
      const delta = y - last;
      if (y <= 24) setState('top');
      else if (Math.abs(delta) >= 3) setState(delta > 0 ? 'down' : 'up');
      last = y;
    };
    const onScroll = () => { if (frame === null) frame = requestAnimationFrame(update); };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => { window.removeEventListener('scroll', onScroll); if (frame !== null) cancelAnimationFrame(frame); };
  }, []);
  useEffect(() => {
    const header = document.querySelector('.site-header');
    if (!header) return;
    header.dataset.scrollState = state;
  }, [state]);
  return null;
}
