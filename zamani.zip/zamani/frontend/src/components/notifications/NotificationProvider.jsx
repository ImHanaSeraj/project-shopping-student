import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { notify, notifyError, notifyInfo, notifySuccess, notifyWarning, showDialog, subscribeNotifications } from './notificationBus';

const NotificationContext = createContext(null);
const iconMap = {
  success: '/notifications/success.svg',
  error: '/notifications/error.svg',
  warning: '/notifications/warning.svg',
  info: '/notifications/info.svg',
  question: '/notifications/question.svg',
};
const labels = { success: 'موفقیت', error: 'خطا', warning: 'هشدار', info: 'اطلاعات', question: 'تایید' };

export default function NotificationProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [dialog, setDialog] = useState(null);

  useEffect(() => subscribeNotifications((item) => {
    if (item.kind === 'toast') {
      setToasts((current) => [...current, item]);
      if (item.duration > 0) {
        window.setTimeout(() => setToasts((current) => current.filter((toast) => toast.id !== item.id)), item.duration);
      }
    } else {
      setDialog(item);
    }
  }), []);

  const closeToast = useCallback((id) => setToasts((current) => current.filter((toast) => toast.id !== id)), []);
  const resolveDialog = useCallback((value) => {
    if (!dialog) return;
    const resolver = dialog.resolve;
    setDialog(null);
    if (resolver) resolver(value);
  }, [dialog]);

  const api = useMemo(() => ({ notify, notifySuccess, notifyError, notifyWarning, notifyInfo, showDialog }), []);

  return (
    <NotificationContext.Provider value={api}>
      {children}
      <div className="zamani-notification-root" dir="rtl" aria-live="polite">
        <div className="zamani-toast-stack">
          {toasts.map((toast) => (
            <div key={toast.id} className={`zamani-toast zamani-toast-${toast.type}`} role={toast.type === 'error' ? 'alert' : 'status'}>
              <div className="zamani-toast-icon-wrap"><img src={iconMap[toast.type] || iconMap.info} alt="" /></div>
              <div className="zamani-toast-content"><strong>{labels[toast.type] || 'پیام'}</strong><span>{toast.message}</span></div>
              <button type="button" className="zamani-toast-close" onClick={() => closeToast(toast.id)} aria-label="بستن">×</button>
              {toast.duration > 0 && <span className="zamani-toast-timer" style={{ animationDuration: `${toast.duration}ms` }} />}
            </div>
          ))}
        </div>
        {dialog && (
          <div className="zamani-dialog-backdrop" onMouseDown={(event) => event.target === event.currentTarget && resolveDialog('cancel')}>
            <section className={`zamani-dialog zamani-dialog-${dialog.type}`} role="dialog" aria-modal="true">
              <div className="zamani-dialog-head">
                <button type="button" className="zamani-dialog-close" onClick={() => resolveDialog('cancel')} aria-label="بستن">×</button>
                <img src={iconMap[dialog.type] || iconMap.info} alt="" />
              </div>
              <div className="zamani-dialog-body">
                <span className="zamani-dialog-kicker">{labels[dialog.type] || 'پیام'}</span>
                <h3>{dialog.title}</h3>
                <p>{dialog.message}</p>
                {dialog.type === 'question' ? (
                  <div className="zamani-dialog-actions">
                    <button type="button" className="zamani-dialog-button zamani-dialog-confirm" onClick={() => resolveDialog('confirm')}>{dialog.confirmText}</button>
                    <button type="button" className="zamani-dialog-button zamani-dialog-cancel" onClick={() => resolveDialog('cancel')}>{dialog.cancelText}</button>
                  </div>
                ) : (
                  <button type="button" className="zamani-dialog-button" onClick={() => resolveDialog('ok')}>{dialog.buttonText}</button>
                )}
              </div>
            </section>
          </div>
        )}
      </div>
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) throw new Error('useNotifications must be used inside NotificationProvider');
  return context;
}
