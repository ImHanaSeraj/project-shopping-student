<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\Brand;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductVariant;
use App\Models\Review;
use App\Models\User;
use App\Models\Wishlist;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class DatabaseRelationshipsTest extends TestCase
{
    use RefreshDatabase;

    public function test_all_phase_four_relationships_are_connected(): void
    {
        $user = User::factory()->create();
        $category = Category::create(['name' => 'مانتو', 'slug' => 'manto']);
        $brand = Brand::create(['name' => 'ZAMANI', 'slug' => 'zamani']);
        $product = Product::create([
            'name' => 'مانتو مشکی',
            'slug' => 'black-manto',
            'price' => 1900000,
            'SKU' => 'ZM-M-001',
            'category_id' => $category->id,
            'brand_id' => $brand->id,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'name' => 'سایز',
            'value' => 'M',
            'stock' => 5,
            'SKU' => 'ZM-M-001-M',
        ]);
        ProductImage::create([
            'product_id' => $product->id,
            'image' => 'products/black-manto.webp',
            'is_primary' => true,
            'sort_order' => 1,
        ]);
        $address = Address::create([
            'user_id' => $user->id,
            'receiver_name' => $user->name,
            'phone' => '09120000000',
            'province' => 'تهران',
            'city' => 'تهران',
            'address' => 'آدرس تست',
            'postal_code' => '1111111111',
        ]);
        $cart = Cart::create(['user_id' => $user->id]);
        $cart->items()->create([
            'product_id' => $product->id,
            'variant_id' => $variant->id,
            'quantity' => 1,
            'price' => 1900000,
        ]);
        $wishlist = Wishlist::create(['user_id' => $user->id, 'product_id' => $product->id]);
        $review = Review::create([
            'user_id' => $user->id,
            'product_id' => $product->id,
            'rating' => 5,
            'comment' => 'تست',
        ]);
        $order = Order::create([
            'user_id' => $user->id,
            'address_id' => $address->id,
            'order_number' => 'ZM-TEST-0001',
            'total' => 1900000,
            'final_total' => 1900000,
        ]);
        $order->items()->create([
            'product_id' => $product->id,
            'variant_id' => $variant->id,
            'product_name' => $product->name,
            'quantity' => 1,
            'price' => 1900000,
        ]);
        $payment = $order->payment()->create([
            'amount' => 1900000,
            'status' => 'pending',
            'gateway' => 'test',
        ]);

        $this->assertTrue($category->products->contains($product));
        $this->assertTrue($brand->products->contains($product));
        $this->assertTrue($product->images->contains(fn ($image) => $image->is_primary));
        $this->assertTrue($product->variants->contains($variant));
        $this->assertTrue($user->orders->contains($order));
        $this->assertTrue($user->addresses->contains($address));
        $this->assertTrue($user->wishlists->contains($wishlist));
        $this->assertTrue($user->reviews->contains($review));
        $this->assertTrue($product->wishlists->contains($wishlist));
        $this->assertTrue($product->reviews->contains($review));
        $this->assertTrue($order->items->contains('id', $order->items->first()->id));
        $this->assertTrue($order->payments->contains($payment));
        $this->assertTrue($order->payment->is($payment));
        $this->assertTrue($cart->items->first()->variant->is($variant));
    }

    public function test_category_parent_child_relationship_works(): void
    {
        $parent = Category::create(['name' => 'پیراهن', 'slug' => 'dress']);
        $child = Category::create([
            'name' => 'مجلسی',
            'slug' => 'formal-dress',
            'parent_id' => $parent->id,
        ]);

        $this->assertTrue($parent->children->contains($child));
        $this->assertTrue($child->parent->is($parent));
    }
}
