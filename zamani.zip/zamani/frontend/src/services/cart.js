import api from './api';
export const CART_KEY = 'zamani_cart';

export async function fetchCart() {
  const { data } = await api.get('/cart');
  return data?.items || [];
}

export async function addCartItem(productId, variantId, quantity) {
  const { data } = await api.post('/cart/items', { product_id: productId, variant_id: variantId || null, quantity });
  return data;
}

export async function updateCartItem(id, quantity) {
  const { data } = await api.patch(`/cart/items/${id}`, { quantity });
  return data;
}

export async function removeCartItem(id) {
  return api.delete(`/cart/items/${id}`);
}

export async function clearCart() {
  return api.delete('/cart');
}

export function readCart() {
  try {
    const value = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

export function writeCart(items) {
  localStorage.setItem(CART_KEY, JSON.stringify(items));
  window.dispatchEvent(new Event('zamani-cart-updated'));
  return items;
}

export function cartTotals(items) {
  const subtotal = items.reduce((sum, item) => sum + Number(item.price || 0) * Number(item.quantity || 0), 0);
  const discount = items.reduce((sum, item) => sum + Number(item.discount || 0) * Number(item.quantity || 0), 0);
  const shipping = subtotal - discount >= 4000000 || items.length === 0 ? 0 : 89000;
  return { subtotal, discount, shipping, total: Math.max(0, subtotal - discount + shipping) };
}

export function formatPrice(value) {
  return `${new Intl.NumberFormat('fa-IR').format(Math.round(Number(value || 0)))} تومان`;
}
