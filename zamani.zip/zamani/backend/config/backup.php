<?php

return [
    'disk' => env('BACKUP_DISK', 'local'),
    'directory' => trim(env('BACKUP_DIRECTORY', 'backups'), '/'),
    'schedule_enabled' => filter_var(env('BACKUP_SCHEDULE_ENABLED', false), FILTER_VALIDATE_BOOL),
    'schedule_time' => env('BACKUP_SCHEDULE_TIME', '03:00'),
];
