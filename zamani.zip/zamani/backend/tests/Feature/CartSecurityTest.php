<?php

namespace Tests\Feature;

use App\Models\Cart;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class CartSecurityTest extends TestCase
{
    use RefreshDatabase;

    public function test_authenticated_user_can_add_variant_to_server_cart_without_supplying_price(): void
    {
        $user = User::create(['name' => 'Test User', 'email' => 'cart-test-'.uniqid().'@example.com', 'password' => 'password', 'status' => true]);
        $product = Product::create(['name' => 'Test Shirt', 'slug' => 'test-shirt-'.uniqid(), 'price' => 500000, 'discount_price' => null, 'stock' => 10, 'SKU' => 'P-'.uniqid(), 'status' => true]);
        $variant = ProductVariant::create([
            'product_id' => $product->id, 'size' => 'M', 'color' => 'مشکی',
            'SKU' => 'ZM-TEST-M-BLACK', 'stock' => 3, 'price' => 650000, 'status' => true,
        ]);
        Sanctum::actingAs($user);

        $response = $this->postJson('/api/cart/items', [
            'product_id' => $product->id,
            'variant_id' => $variant->id,
            'quantity' => 2,
            'price' => 1000,
        ]);

        $response->assertCreated();
        $response->assertJsonPath('item.price', 650000);
        $this->assertDatabaseHas('cart_items', ['cart_id' => Cart::first()->id, 'variant_id' => $variant->id, 'quantity' => 2]);
    }

    public function test_cart_rejects_zero_or_negative_quantity(): void
    {
        $user = User::create(['name' => 'Test User', 'email' => 'cart-test-'.uniqid().'@example.com', 'password' => 'password', 'status' => true]);
        Sanctum::actingAs($user);

        $this->postJson('/api/cart/items', ['product_id' => 1, 'quantity' => 0])->assertUnprocessable();
        $this->postJson('/api/cart/items', ['product_id' => 1, 'quantity' => -1])->assertUnprocessable();
    }

    public function test_cart_rejects_quantity_above_variant_stock(): void
    {
        $user = User::create(['name' => 'Test User', 'email' => 'cart-test-'.uniqid().'@example.com', 'password' => 'password', 'status' => true]);
        $product = Product::create(['name' => 'Test Shirt 2', 'slug' => 'test-shirt-2-'.uniqid(), 'price' => 500000, 'stock' => 0, 'SKU' => 'P-'.uniqid(), 'status' => true]);
        $variant = ProductVariant::create([
            'product_id' => $product->id, 'size' => 'L', 'color' => 'سفید',
            'SKU' => 'ZM-TEST-L-WHITE', 'stock' => 2, 'price' => 400000, 'status' => true,
        ]);
        Sanctum::actingAs($user);

        $this->postJson('/api/cart/items', ['product_id' => $product->id, 'variant_id' => $variant->id, 'quantity' => 3])
            ->assertUnprocessable();
    }
}
