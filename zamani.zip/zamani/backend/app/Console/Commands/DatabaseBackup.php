<?php

namespace App\Console\Commands;

use App\Services\BackupService;
use Illuminate\Console\Command;

class DatabaseBackup extends Command
{
    protected $signature = 'backup:database';
    protected $description = 'Create a database backup using the configured backup service';

    public function handle(BackupService $backupService): int
    {
        try {
            $path = $backupService->createDatabaseBackup();
            $this->info("Backup created: {$path}");
            return self::SUCCESS;
        } catch (\Throwable $e) {
            report($e);
            $this->error('Database backup failed.');
            return self::FAILURE;
        }
    }
}
