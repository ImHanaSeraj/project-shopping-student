<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function __invoke(Request $request)
    {
        $query = trim((string) $request->input('q', ''));

        if ($query === '') {
            return response()->json([
                'query' => '',
                'products' => [],
                'categories' => [],
                'products_total' => 0,
            ]);
        }

        $productQuery = Product::with(['images', 'category', 'brand'])
            ->where('status', true)
            ->where(function ($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                    ->orWhere('description', 'like', "%{$query}%")
                    ->orWhere('short_description', 'like', "%{$query}%")
                    ->orWhere('SKU', 'like', "%{$query}%")
                    ->orWhereHas('brand', fn ($brand) => $brand->where('name', 'like', "%{$query}%"))
                    ->orWhereHas('category', fn ($category) => $category->where('name', 'like', "%{$query}%"));
            });

        $productsTotal = (clone $productQuery)->count();
        $limit = min(max((int) $request->input('limit', 12), 1), 24);
        $products = $productQuery->latest()->limit($limit)->get();

        $categories = Category::query()
            ->withCount('products')
            ->whereNull('parent_id')
            ->where(function ($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                    ->orWhere('slug', 'like', "%{$query}%");
            })
            ->limit(8)
            ->get();

        return response()->json([
            'query' => $query,
            'products' => ProductResource::collection($products),
            'categories' => $categories,
            'products_total' => $productsTotal,
        ]);
    }
}
