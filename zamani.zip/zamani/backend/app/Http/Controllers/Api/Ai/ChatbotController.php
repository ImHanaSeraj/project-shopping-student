<?php

namespace App\Http\Controllers\Api\Ai;

use App\Events\ChatConversationUpdated;
use App\Events\ChatMessageCreated;
use App\Http\Controllers\Controller;
use App\Http\Requests\Ai\ChatbotSendRequest;
use App\Models\ChatConversation;
use App\Models\Product;
use App\Services\GeminiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

class ChatbotController extends Controller
{

    public function __construct(private GeminiService $ai)
    {
    }

    public function send(ChatbotSendRequest $request)
    {
        try {

            $data = $request->validated();

            $conversation = !empty($data['conversation_id'])
                ? ChatConversation::findOrFail($data['conversation_id'])
                : ChatConversation::create([
                    'user_id' => $request->user()?->id,
                    'session_id' => $data['session_id'] ?? (string) Str::uuid(),
                    'status' => 'bot',
                ]);

            $userMessage = $conversation->messages()->create([
                'role' => 'user',
                'content' => $data['message'],
            ]);
            broadcast(new ChatMessageCreated($userMessage->load('conversation')));

            // A human has already taken over (or is waiting to). Don't let the AI
            // butt into the conversation - just deliver the message and let the
            // admin inbox pick it up from the live channel.
            if ($conversation->isHumanHandled()) {
                return response()->json([
                    'conversation_id' => $conversation->id,
                    'session_id' => $conversation->session_id,
                    'status' => $conversation->status,
                    'reply' => null,
                    'products' => [],
                ]);
            }

            $catalogHint = Product::where('status', true)
                ->select('name', 'price', 'stock')
                ->limit(30)
                ->get()
                ->map(function ($p) {
                    return "{$p->name} - {$p->price} تومان - موجودی: {$p->stock}";
                })
                ->implode("\n");

            $history = $conversation->messages()
                ->orderBy('id')
                ->get()
                ->map(function ($m) {
                    return [
                        'role' => $m->role === 'admin' ? 'assistant' : $m->role,
                        'content' => $m->content,
                    ];
                })
                ->all();

            $systemPrompt =
                "شما دستیار پشتیبانی فروشگاه هستید.\n\n" .
                "در پاسخ‌ها مودب، کوتاه و دقیق باش.\n\n" .
                "محصولات:\n" .
                $catalogHint;

            $reply = $this->ai->chat([
                [
                    'role' => 'system',
                    'content' => $systemPrompt,
                ],
                ...$history,
            ]);

            $assistantMessage = $conversation->messages()->create([
                'role' => 'assistant',
                'content' => $reply,
            ]);
            broadcast(new ChatMessageCreated($assistantMessage->load('conversation')));

            return response()->json([
                'conversation_id' => $conversation->id,
                'session_id' => $conversation->session_id,
                'status' => $conversation->status,
                'reply' => $reply,
                'products' => [],
            ]);

        } catch (Throwable $e) {

            Log::error($e);

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'file' => basename($e->getFile()),
                'line' => $e->getLine(),
            ], 500);

        }
    }

    public function history(int $conversationId)
    {
        return ChatConversation::with('messages')->findOrFail($conversationId);
    }

    // Customer taps "صحبت با پشتیبان انسانی" in the widget. Drops the AI out of
    // the loop and puts the conversation in the admin queue.
    public function escalate(Request $request)
    {
        $data = $request->validate([
            'conversation_id' => 'required|integer|exists:chat_conversations,id',
        ]);

        $conversation = ChatConversation::findOrFail($data['conversation_id']);

        if ($conversation->status === 'bot') {
            $conversation->update(['status' => 'pending', 'escalated_at' => now()]);

            $systemMessage = $conversation->messages()->create([
                'role' => 'system',
                'content' => 'کاربر درخواست صحبت با پشتیبان انسانی را داد.',
            ]);
            broadcast(new ChatMessageCreated($systemMessage->load('conversation')));
        }

        broadcast(new ChatConversationUpdated($conversation->fresh()));

        return response()->json([
            'conversation_id' => $conversation->id,
            'status' => $conversation->status,
        ]);
    }
}
