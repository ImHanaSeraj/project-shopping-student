<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Base catalog categories are safe to seed repeatedly. Admin-created
        // categories are never deleted or overwritten by this seeder.
        $this->call(ZamaniCategorySeeder::class);
    }
}
