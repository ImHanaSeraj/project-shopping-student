import Account from '../../views/Account';
import ProtectedRoute from '../../guards/ProtectedRoute';
export default function AccountWishlistPage(){ return <ProtectedRoute><Account/></ProtectedRoute>; }
