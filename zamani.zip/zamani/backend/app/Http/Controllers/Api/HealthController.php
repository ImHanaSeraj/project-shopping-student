<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Throwable;

class HealthController
{
    public function __invoke(): JsonResponse
    {
        $database = 'ok';

        try {
            DB::connection()->getPdo();
        } catch (Throwable $exception) {
            $database = 'error';
        }

        $healthy = $database === 'ok';

        return response()->json([
            'success' => $healthy,
            'application' => 'ZAMANI API',
            'status' => $healthy ? 'ok' : 'degraded',
            'database' => $database,
            'timestamp' => now()->toIso8601String(),
        ], $healthy ? 200 : 503);
    }
}