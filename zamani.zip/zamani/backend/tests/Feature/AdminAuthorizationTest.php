<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AdminAuthorizationTest extends TestCase
{
    use RefreshDatabase;

    private function customer(): User
    {
        return User::create([
            'name' => 'Customer',
            'email' => 'customer-' . uniqid() . '@example.com',
            'phone' => '09' . random_int(100000000, 999999999),
            'password' => 'StrongPass123!',
            'role' => 'customer',
            'status' => true,
        ]);
    }

    private function admin(): User
    {
        return User::create([
            'name' => 'Admin',
            'email' => 'admin-' . uniqid() . '@example.com',
            'phone' => '09' . random_int(100000000, 999999999),
            'password' => 'StrongPass123!',
            'role' => 'admin',
            'status' => true,
        ]);
    }

    public function test_customer_is_blocked_from_every_admin_resource(): void
    {
        Sanctum::actingAs($this->customer());

        $requests = [
            fn () => $this->getJson('/api/admin/dashboard'),
            fn () => $this->getJson('/api/admin/products'),
            fn () => $this->getJson('/api/admin/categories'),
            fn () => $this->getJson('/api/admin/brands'),
            fn () => $this->getJson('/api/admin/orders'),
            fn () => $this->getJson('/api/admin/users'),
            fn () => $this->getJson('/api/admin/reviews'),
            fn () => $this->getJson('/api/admin/discounts'),
            fn () => $this->getJson('/api/admin/settings'),
        ];

        foreach ($requests as $request) {
            $request()->assertForbidden();
        }
    }

    public function test_inactive_admin_is_blocked(): void
    {
        $admin = $this->admin();
        $admin->update(['status' => false]);

        Sanctum::actingAs($admin);

        $this->getJson('/api/admin/dashboard')->assertForbidden();
    }

    public function test_admin_can_access_admin_resources(): void
    {
        Sanctum::actingAs($this->admin());

        $this->getJson('/api/admin/dashboard')->assertSuccessful();
        $this->getJson('/api/admin/settings')->assertSuccessful();
    }

    public function test_settings_are_protected_and_validated(): void
    {
        Sanctum::actingAs($this->admin());

        $this->putJson('/api/admin/settings', [
            'key' => 'invalid key',
            'value' => 'x',
        ])->assertUnprocessable();

        $this->putJson('/api/admin/settings', [
            'key' => 'store_name',
            'value' => 'زمانی',
        ])->assertSuccessful();

        $this->getJson('/api/admin/settings')
            ->assertSuccessful()
            ->assertJsonPath('data.0.key', 'store_name');
    }
}
