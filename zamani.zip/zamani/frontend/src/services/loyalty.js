import api from './api';

export const getLoyalty = () => api.get('/loyalty');
export const getAdminLoyalty = (params = {}) => api.get('/admin/loyalty', { params });
export const adjustAdminLoyalty = (id, data) => api.post(`/admin/loyalty/users/${id}/adjust`, data);
