import { useEffect, useState } from 'react';
import { useParams } from '../utils/routerCompat';
import ProductCard from '../components/products/ProductCard';
import SEOHead, { absoluteUrl } from '../components/SEOHead';
import { getCategories, getProducts } from '../services/productApi';
import api from '../services/api';

export default function CategoryDetails() {
  const { slug } = useParams();
  const [category, setCategory] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let cancelled = false;
    api.get(`/categories/${encodeURIComponent(slug)}`).then(r => r.data)
      .then(async cat => {
        if (cancelled) return;
        const categoryData = cat?.data || cat;
        setCategory(categoryData);
        const categoryIds = Array.isArray(categoryData.product_category_ids) && categoryData.product_category_ids.length
          ? categoryData.product_category_ids
          : [categoryData.id];
        const prod = await getProducts({ per_page: 48, category: categoryIds }).catch(() => ({ data: [] }));
        if (cancelled) return;
        const items = prod?.data?.data || prod?.data || [];
        setProducts(Array.isArray(items) ? items : []);
      }).catch(() => {}).finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [slug]);
  if (loading || !category) return null;
  const description = category.description || `محصولات دسته ${category.name} در فروشگاه کالکشن زمانی.`;
  const schema = { '@graph': [
    { '@context': 'https://schema.org', '@type': 'CollectionPage', name: category.name, description, url: absoluteUrl(`/categories/${category.slug}`) },
    { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'خانه', item: absoluteUrl('/') },
      { '@type': 'ListItem', position: 2, name: 'دسته‌بندی‌ها', item: absoluteUrl('/categories') },
      { '@type': 'ListItem', position: 3, name: category.name, item: absoluteUrl(`/categories/${category.slug}`) }
    ] }
  ]};
  return <main className="inner-page">
    <SEOHead title={category.name} description={description} path={`/categories/${category.slug}`} image={category.image} schema={schema} />
    {category.children?.length ? <section className="container category-children">{category.children.map(child => <a key={child.id} href={`/categories/${child.slug}`} className="category-child-link">{child.name}</a>)}</section> : null}
    {products.length ? <section className="container collection-grid">{products.map(p => <ProductCard key={p.id} product={p}/>)}</section> : null}
  </main>;
}
