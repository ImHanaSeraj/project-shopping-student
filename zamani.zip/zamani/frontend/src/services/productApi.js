import api from './api';
import { cachedGet, stableParams } from './requestCache';

export const getProducts = (params = {}) => {
  if (typeof window === 'undefined') return api.get('/products', { params });
  const query = new URLSearchParams();
  if (params instanceof URLSearchParams) {
    params.forEach((value, key) => { if (value !== undefined && value !== null && value !== '') query.append(key, String(value)); });
  } else {
    Object.entries(params || {}).forEach(([key, value]) => {
      const values = Array.isArray(value) ? value : [value];
      values.forEach(v => { if (v !== undefined && v !== null && v !== '') query.append(key, String(v)); });
    });
  }
  return fetch(`/api/products${query.toString() ? `?${query.toString()}` : ''}`, {
    headers: { Accept: 'application/json' }, cache: 'no-store'
  }).then(async response => {
    const data = await response.json().catch(() => ({}));
    if (!response.ok) { const error = new Error(data?.error?.message || 'دریافت محصولات انجام نشد.'); error.response = {status: response.status, data}; throw error; }
    return { data };
  });
};
export const getProduct = (id) => cachedGet(`product:${id}`, () => api.get(`/products/${id}`), 30000);

// Categories are always read from Laravel/MySQL. In the Next frontend we use
// a same-origin proxy so localhost:3000 never loses the request because of CORS.
export const getCategories = () => {
  if (typeof window === 'undefined') return api.get('/categories');
  return fetch('/api/categories', {
    method: 'GET',
    headers: { Accept: 'application/json' },
    cache: 'no-store',
  }).then(async response => {
    const data = await response.json();
    if (!response.ok) {
      const error = new Error(data?.error?.message || data?.error?.detail || 'دریافت دسته‌بندی‌ها انجام نشد.');
      error.response = { status: response.status, data };
      throw error;
    }
    return { data };
  });
};

export const getBrands = () => cachedGet('brands', () => api.get('/brands'), 120000);
// Whitelisted store settings (store name, shipping fee, special-offer countdown end date, ...).
// Cached briefly so the homepage + /special-offers page don't both fetch it separately.
export const getPublicSettings = () => cachedGet('settings:public', () => api.get('/settings/public'), 60000);
export const getRelatedProducts = (id) => cachedGet(`related:${id}`, () => api.get(`/products/${id}/related`), 30000);

// Batch fetch for the compare page. Not cached like getProduct/getBrands —
// the id list changes every time the user adds/removes a product.
export const getCompareProducts = (ids = []) => {
  const query = [...new Set(ids.map(Number).filter((id) => Number.isFinite(id)))].join(',');
  if (!query) return Promise.resolve({ data: { data: [] } });
  return api.get('/products/compare', { params: { ids: query } });
};
export const submitReview = (id, payload) => api.post(`/products/${id}/reviews`, payload);

export const recommendSize = ({ height_cm, weight_kg, available_sizes = [], product = {} }) => api.post('/ai/gemini', { mode: 'size', height_cm, weight_kg, available_sizes, product });
