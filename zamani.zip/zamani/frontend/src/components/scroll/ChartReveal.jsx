import { useEffect } from 'react';

export default function ChartReveal() {
  useEffect(() => {
    const prepare = chart => {
      chart.querySelectorAll('path, polyline, line').forEach(path => {
        try {
          const length = path.getTotalLength();
          path.style.setProperty('--chart-length', `${length}px`);
          path.classList.add('chart-stroke');
        } catch (_) {}
      });
    };
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      prepare(entry.target);
      requestAnimationFrame(() => entry.target.classList.add('chart-ready'));
      observer.unobserve(entry.target);
    }), { threshold: 0.25 });
    document.querySelectorAll('.admin-chart, .chart-reveal').forEach(chart => { prepare(chart); observer.observe(chart); });
    const mutation = new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => {
      if (node.nodeType !== 1) return;
      node.matches?.('.admin-chart, .chart-reveal') && (prepare(node), observer.observe(node));
      node.querySelectorAll?.('.admin-chart, .chart-reveal').forEach(chart => { prepare(chart); observer.observe(chart); });
    })));
    mutation.observe(document.body, { childList: true, subtree: true });
    return () => { observer.disconnect(); mutation.disconnect(); };
  }, []);
  return null;
}
