<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
    // role: user | assistant (AI) | admin | system (e.g. "operator joined the chat")
    protected $fillable = ['chat_conversation_id', 'role', 'content', 'sender_id'];

    public function conversation()
    {
        return $this->belongsTo(ChatConversation::class, 'chat_conversation_id');
    }

    public function sender()
    {
        return $this->belongsTo(User::class, 'sender_id');
    }
}
