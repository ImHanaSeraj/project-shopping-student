<?php
namespace App\Http\Controllers\Api\Admin;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class DashboardController extends AdminBaseController
{
    public function __invoke(Request $request)
    {
        $this->guardAdmin($request);
        $today = Carbon::today();
        $month = Carbon::now()->startOfMonth();
        $paid = fn($q) => $q->where('payment_status', 'paid');
        return response()->json([
            'sales_today' => (float) $paid(Order::query())->whereDate('created_at', $today)->sum('final_total'),
            'sales_month' => (float) $paid(Order::query())->where('created_at', '>=', $month)->sum('final_total'),
            'orders_count' => Order::count(),
            'users_count' => User::count(),
            'products_count' => Product::count(),
            'low_stock_count' => Product::where('stock', '<=', 5)->where('status', true)->count(),
            'new_orders_count' => Order::whereIn('status', ['pending_payment','paid','processing'])->count(),
            'low_stock_products' => Product::with(['images','category'])->where('stock', '<=', 5)->where('status', true)->orderBy('stock')->limit(8)->get(),
            'new_orders' => Order::with('user:id,name,phone')->latest()->limit(8)->get(),
        ]);
    }
}
