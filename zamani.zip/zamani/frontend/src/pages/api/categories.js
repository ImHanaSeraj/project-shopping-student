const BACKEND_API = 'http://127.0.0.1:8000/api';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ success: false, error: { message: 'Method Not Allowed' } });
  }

  try {
    const response = await fetch(`${BACKEND_API}/categories`, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      cache: 'no-store',
    });
    const text = await response.text();
    let payload;
    try { payload = JSON.parse(text); }
    catch { payload = { success: false, error: { message: text || 'پاسخ نامعتبر از Laravel' } }; }

    res.setHeader('Cache-Control', 'no-store, max-age=0');
    return res.status(response.status).json(payload);
  } catch (error) {
    console.error('[API /categories]', error);
    return res.status(502).json({
      success: false,
      error: {
        message: 'ارتباط با Laravel برقرار نشد.',
        detail: String(error?.message || error),
      },
    });
  }
}
