import { useEffect, useRef, useState } from 'react';

export default function ViewportCounter({ value, duration = 900 }) {
  const ref = useRef(null);
  const [display, setDisplay] = useState('0');
  useEffect(() => {
    const el = ref.current;
    const target = Number(String(value ?? 0).replace(/[^0-9.-]/g, '')) || 0;
    if (!el || typeof IntersectionObserver === 'undefined') { setDisplay(String(target)); return undefined; }
    let started = false;
    const observer = new IntersectionObserver(entries => {
      if (!entries[0].isIntersecting || started) return;
      started = true;
      const start = performance.now();
      const tick = now => {
        const p = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        setDisplay(Math.round(target * eased).toLocaleString('fa-IR'));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      observer.disconnect();
    }, { threshold: 0.35 });
    observer.observe(el);
    return () => observer.disconnect();
  }, [value, duration]);
  return <strong ref={ref} className="viewport-counter">{display}</strong>;
}
