import { useState } from 'react';
import SEOHead from '../components/SEOHead';
import Icon from '../components/Icon';

const faqItems = [
  ['چطور سایز مناسب را انتخاب کنم؟', 'در صفحه هر محصول جدول سایزبندی قرار گرفته است. اگر بین دو سایز هستید، پشتیبانی زمانی برای انتخاب دقیق‌تر راهنمایی‌تان می‌کند.'],
  ['هزینه و زمان ارسال چقدر است؟', 'برای سفارش‌های بالای ۴ میلیون تومان ارسال رایگان است. زمان ارسال معمولاً ۱ تا ۳ روز کاری است.'],
  ['امکان تعویض یا مرجوعی وجود دارد؟', 'بله؛ تا ۳ روز پس از تحویل، مطابق شرایط مرجوعی فروشگاه امکان بازگشت وجود دارد.'],
  ['آیا پرداخت آنلاین امن است؟', 'بله؛ پرداخت‌ها از درگاه امن انجام می‌شوند و اطلاعات کارت بانکی در فروشگاه ذخیره نمی‌شود.'],
];

export default function Contact() {
  const [faqOpen, setFaqOpen] = useState(0);

  return <main className="container section contact-page">
    <SEOHead title="تماس با ما" description="راه‌های ارتباط با فروشگاه پوشاک زنانه زمانی و پشتیبانی خرید." path="/contact" />
    <h1>تماس با ما</h1>
    <p>برای راهنمایی خرید، پیگیری سفارش یا همکاری با تیم زمانی با ما در ارتباط باشید.</p>
    <div className="contact-grid">
      <div><strong>تلفن</strong><span>۰۹۲۱۷۱۲۰۰۱۷</span></div>
      <div><strong>ایمیل</strong><a className="contact-email" href="mailto:sjack0324@gmail.com">sjack0324@gmail.com</a></div>
      <div><strong>ساعات پاسخگویی</strong><span>شنبه تا پنجشنبه · ۹ تا ۲۱</span></div>
      <div className="contact-address"><strong>آدرس فروشگاه</strong><span>تهران، فیروزکوه، خیابان پاسداران، پاساژ نگین (شهرداری)، طبقه دوم، بوتیک زمانی.</span></div>
    </div>

    <section className="faq-section" id="faq">
      <div className="faq-intro">
        <span className="eyebrow">FAQ</span>
        <h2>سؤالی دارید؟</h2>
        <p>پاسخ کوتاه و شفاف به پرسش‌های پرتکرار خرید از زمانی.</p>
      </div>
      <div className="faq-list">
        {faqItems.map(([q, a], i) => (
          <div className={`faq-item ${faqOpen === i ? 'open' : ''}`} key={q}>
            <button onClick={() => setFaqOpen(faqOpen === i ? -1 : i)}>
              <span>{q}</span>
              <Icon name="plus" size={17} />
            </button>
            <div className="faq-answer">{a}</div>
          </div>
        ))}
      </div>
    </section>
  </main>;
}
