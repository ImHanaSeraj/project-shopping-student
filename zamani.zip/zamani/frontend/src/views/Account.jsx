import { useEffect, useMemo, useState } from "react";
import Link from '../components/SafeLink';
import {useLocation, useNavigate} from '../utils/routerCompat';
import Icon from "../components/Icon";
import { useAuth } from "../context/AuthContext";
import { getProfile, updateProfile, changePassword, logoutAccount, getAddresses, createAddress, updateAddress, deleteAddress, setDefaultAddress } from "../services/account";
import { getOrders } from "../services/orders";
import useDocumentTitle from "../hooks/useDocumentTitle";

const fa=n=>new Intl.NumberFormat("fa-IR").format(Number(n||0));
const money=n=>`${fa(n)} تومان`;
const tabs=[
 ["/account","داشبورد","grid"],["/account/profile","پروفایل","user"],["/account/orders","سفارش‌ها","bag"],["/account/addresses","آدرس‌ها","pin"],["/account/wishlist","علاقه‌مندی‌ها","heart"],["/account/password","تغییر رمز عبور","lock"]
];
const status={pending_payment:"در انتظار پرداخت",paid:"پرداخت شده",preparing:"در حال آماده‌سازی",shipped:"ارسال شده",delivered:"تحویل شده"};
function Layout({children,title,subtitle}){const loc=useLocation(); const nav=useNavigate(); const {user,logout}=useAuth(); const [busy,setBusy]=useState(false); const doLogout=async()=>{setBusy(true);try{await logoutAccount()}catch{}finally{logout();nav("/login");}}; return <main className="account-page container"><div className="account-breadcrumb"><Link href="/">خانه</Link><Icon name="arrow" size={11}/><span>حساب کاربری</span>{title&&<><Icon name="arrow" size={11}/><b>{title}</b></>}</div><div className="account-shell"><aside className="account-sidebar"><div className="account-user"><div className="account-avatar">{(user?.name||"Z").slice(0,1)}</div><div><strong>{user?.name||"کاربر زمانی"}</strong><small>{user?.email||user?.phone||"حساب کاربری"}</small></div></div><nav>{tabs.map(([to,label,icon])=><Link className={loc.pathname===to||((to==="/account/orders")&&loc.pathname.startsWith("/orders"))?"active":""} key={to} href={to}><Icon name={icon} size={17}/><span>{label}</span></Link>)}{user?.role==="admin"&&<Link className={loc.pathname.startsWith("/admin")?"active":""} href="/admin"><Icon name="grid" size={17}/><span>ورود به پنل مدیریت</span></Link>}<button onClick={doLogout} disabled={busy}><Icon name="logout" size={17}/><span>{busy?"در حال خروج...":"خروج از حساب"}</span></button></nav></aside><section className="account-content"><div className="account-content-head"><div><h1>{title||"حساب کاربری"}</h1><p>{subtitle||"مدیریت اطلاعات، سفارش‌ها و تنظیمات حساب شما"}</p></div></div>{children}</section></div></main>}
function Dashboard(){const {user}=useAuth();const [orders,setOrders]=useState([]);const [addresses,setAddresses]=useState([]);useEffect(()=>{getOrders({page:1,per_page:3}).then(r=>setOrders(r.data?.data||[])).catch(()=>{});getAddresses().then(r=>setAddresses(r.data||[])).catch(()=>{});},[]);return <Layout title="داشبورد" subtitle="خلاصه‌ای از حساب و فعالیت‌های اخیر شما"><div className="account-stats"><Link href="/account/orders"><span>سفارش‌ها</span><strong>{fa(orders.length)}</strong></Link><Link href="/account/addresses"><span>آدرس‌های ذخیره‌شده</span><strong>{fa(addresses.length)}</strong></Link><Link href="/wishlist"><span>علاقه‌مندی‌ها</span><strong>مشاهده</strong></Link><Link href="/account/profile"><span>اطلاعات حساب</span><strong>ویرایش</strong></Link></div><div className="account-panels"><section className="account-panel"><div className="panel-head"><h2>آخرین سفارش‌ها</h2><Link href="/account/orders">مشاهده همه</Link></div>{orders.length?orders.map(o=><Link className="mini-order" href={`/orders/${o.id}`} key={o.id}><div><strong>{o.order_number}</strong><small>{new Date(o.created_at).toLocaleDateString("fa-IR")}</small></div><span className={`order-badge status-${o.status}`}>{status[o.status]||o.status}</span><b>{money(o.final_total)}</b></Link>):<div className="account-empty">هنوز سفارشی ثبت نشده است.</div>}</section><section className="account-panel"><div className="panel-head"><h2>اطلاعات مشتری</h2><Link href="/account/profile">ویرایش</Link></div><div className="profile-summary"><div><span>نام</span><b>{user?.name||"—"}</b></div><div><span>ایمیل</span><b>{user?.email||"—"}</b></div><div><span>موبایل</span><b>{user?.phone||"—"}</b></div></div></section></div></Layout>}
function Profile(){const {user,login}=useAuth();const [form,setForm]=useState({name:user?.name||"",email:user?.email||"",phone:user?.phone||""});const [state,setState]=useState({busy:false,msg:"",error:""});const save=async e=>{e.preventDefault();setState({busy:true,msg:"",error:""});try{const r=await updateProfile(form);login(r.data,localStorage.getItem("token"));setState({busy:false,msg:"اطلاعات پروفایل با موفقیت ذخیره شد.",error:""});}catch(e){setState({busy:false,msg:"",error:e.response?.data?.message||"ذخیره اطلاعات انجام نشد."});}};return <Layout title="پروفایل" subtitle="اطلاعات شخصی حساب خود را مدیریت کنید"><form className="account-form" onSubmit={save}><div className="form-grid"><label>نام و نام خانوادگی<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/></label><label>شماره موبایل<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} required/></label><label>ایمیل<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/></label></div>{state.error&&<div className="account-alert error">{state.error}</div>}{state.msg&&<div className="account-alert success">{state.msg}</div>}<button className="btn btn-primary" disabled={state.busy}>{state.busy?"در حال ذخیره...":"ذخیره تغییرات"}</button></form></Layout>}
function Addresses(){
  const [items,setItems]=useState([]);
  const [mode,setMode]=useState(null);
  const [busy,setBusy]=useState(false);
  const [msg,setMsg]=useState("");
  const empty={receiver_name:"",phone:"",province:"",city:"",address:"",postal_code:"",is_default:false};
  const [form,setForm]=useState(empty);
  const load=()=>getAddresses().then(r=>setItems(r.data||[])).catch(()=>setMsg("دریافت آدرس‌ها انجام نشد."));
  useEffect(()=>{load();},[]);
  const openNew=()=>{setForm({...empty,is_default:items.length===0});setMsg("");setMode("new");};
  const openEdit=(a)=>{setForm({receiver_name:a.receiver_name||"",phone:a.phone||"",province:a.province||"",city:a.city||"",address:a.address||"",postal_code:a.postal_code||"",is_default:!!a.is_default});setMsg("");setMode(a.id);};
  const save=async e=>{e.preventDefault();setBusy(true);setMsg("");try{if(mode==="new") await createAddress(form); else await updateAddress(mode,form);setForm(empty);setMode(null);setMsg(mode==="new"?"آدرس با موفقیت ذخیره شد.":"آدرس با موفقیت ویرایش شد.");await load();}catch(e){setMsg(e.response?.data?.message||"ذخیره آدرس انجام نشد.");}finally{setBusy(false)}};
  const makeDefault=async id=>{setBusy(true);setMsg("");try{await setDefaultAddress(id);setMsg("آدرس پیش‌فرض تغییر کرد.");await load();}catch(e){setMsg(e.response?.data?.message||"تغییر آدرس پیش‌فرض انجام نشد.");}finally{setBusy(false)}};
  const remove=async id=>{if(!window.confirm("این آدرس حذف شود؟"))return;setBusy(true);setMsg("");try{await deleteAddress(id);setMsg("آدرس حذف شد.");await load();}catch(e){setMsg(e.response?.data?.message||"حذف آدرس انجام نشد.");}finally{setBusy(false)}};
  return <Layout title="آدرس‌ها" subtitle="آدرس‌های ارسال خود را مدیریت کنید">
    <div className="panel-head account-address-head"><div><h2>آدرس‌های ذخیره‌شده</h2><p>{fa(items.length)} آدرس</p></div><button className="btn btn-primary" onClick={mode?()=>setMode(null):openNew} disabled={busy}><Icon name="plus" size={15}/>{mode?"بستن":"آدرس جدید"}</button></div>
    {mode&&<form className="account-form address-form" onSubmit={save}><div className="form-grid"><label>نام گیرنده<input value={form.receiver_name} onChange={e=>setForm({...form,receiver_name:e.target.value})} required/></label><label>شماره تماس<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} required/></label><label>استان<input value={form.province} onChange={e=>setForm({...form,province:e.target.value})} required/></label><label>شهر<input value={form.city} onChange={e=>setForm({...form,city:e.target.value})} required/></label><label className="full">آدرس<textarea value={form.address} onChange={e=>setForm({...form,address:e.target.value})} required/></label><label>کد پستی<input value={form.postal_code} onChange={e=>setForm({...form,postal_code:e.target.value.replace(/\D/g,"").slice(0,10)})} inputMode="numeric" pattern="[0-9]{10}" required/></label></div><label className="address-default-check"><input type="checkbox" checked={!!form.is_default} onChange={e=>setForm({...form,is_default:e.target.checked})}/> این آدرس آدرس پیش‌فرض من باشد</label><div className="account-alert">{msg}</div><button className="btn btn-primary" disabled={busy}>{busy?"در حال ذخیره...":mode==="new"?"ذخیره آدرس":"ذخیره تغییرات"}</button></form>}
    {!items.length&&!mode?<div className="account-empty large"><Icon name="pin" size={30}/><h3>هنوز آدرسی ثبت نشده</h3><p>برای پرداخت سریع‌تر، یک آدرس ارسال ذخیره کنید.</p><button className="btn btn-outline" onClick={openNew}>افزودن آدرس</button></div>:<div className="address-list">{items.map(a=><article className={`address-card ${a.is_default?"is-default":""}`} key={a.id}><div className="address-icon"><Icon name="pin"/></div><div className="address-card-body"><div className="address-card-top"><strong>{a.receiver_name}</strong>{a.is_default&&<span className="address-default-badge">پیش‌فرض</span>}</div><p>{a.province}، {a.city}<br/>{a.address}<br/>کدپستی: {a.postal_code}</p><small>{a.phone}</small><div className="address-actions"><button className="text-link" onClick={()=>openEdit(a)} disabled={busy}>ویرایش</button>{!a.is_default&&<button className="text-link" onClick={()=>makeDefault(a.id)} disabled={busy}>پیش‌فرض</button>}<button className="text-link danger" onClick={()=>remove(a.id)} disabled={busy}>حذف</button></div></div></article>)}</div>}
    {msg&&!mode&&<div className="account-alert success">{msg}</div>}
  </Layout>
}
function PassField({label,value,onChange,minLength,autoComplete}){
  const [show,setShow]=useState(false);
  return <label className="pass-field">{label}
    <div className="pass-input-wrap">
      <Icon name="lock" size={15} className="pass-input-icon"/>
      <input type={show?"text":"password"} value={value} onChange={onChange} minLength={minLength} autoComplete={autoComplete} required/>
      <button type="button" className="pass-toggle" onClick={()=>setShow(v=>!v)} tabIndex={-1} aria-label={show?"مخفی کردن رمز":"نمایش رمز"}>
        <Icon name={show?"eye-off":"eye"} size={16}/>
      </button>
    </div>
  </label>;
}
function Password(){
  const { updateToken } = useAuth();
  const [form,setForm]=useState({current:"",password:"",password_confirmation:""});
  const [state,setState]=useState({busy:false,msg:"",error:""});
  const rules=[
    {label:"حداقل ۸ کاراکتر",test:v=>v.length>=8},
    {label:"حداقل یک عدد",test:v=>/\d/.test(v)},
    {label:"حداقل یک حرف بزرگ یا کوچک",test:v=>/[a-zA-Z]/.test(v)},
  ];
  const matchOk=form.password&&form.password_confirmation&&form.password===form.password_confirmation;
  const save=async e=>{e.preventDefault();setState({busy:true,msg:"",error:""});try{const response=await changePassword(form);updateToken(response.data?.token);setForm({current:"",password:"",password_confirmation:""});setState({busy:false,msg:"رمز عبور با موفقیت تغییر کرد.",error:""});}catch(e){setState({busy:false,msg:"",error:e.response?.data?.message||"تغییر رمز عبور انجام نشد."});}};
  return <Layout title="تغییر رمز عبور" subtitle="برای امنیت بیشتر، رمز عبور قوی انتخاب کنید">
    <form className="account-form password-form" onSubmit={save}>
      <div className="password-form-head">
        <div className="password-form-icon"><Icon name="lock" size={20}/></div>
        <div><h3>به‌روزرسانی رمز عبور</h3><p>رمز عبور فعلی خود را وارد کنید و یک رمز جدید و قوی انتخاب کنید.</p></div>
      </div>
      <PassField label="رمز عبور فعلی" value={form.current} onChange={e=>setForm({...form,current:e.target.value})} autoComplete="current-password"/>
      <div className="pass-divider"/>
      <div className="form-grid">
        <PassField label="رمز عبور جدید" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} minLength={8} autoComplete="new-password"/>
        <PassField label="تکرار رمز عبور جدید" value={form.password_confirmation} onChange={e=>setForm({...form,password_confirmation:e.target.value})} minLength={8} autoComplete="new-password"/>
      </div>
      <ul className="pass-rules">
        {rules.map(r=><li key={r.label} className={r.test(form.password)?"ok":""}><Icon name="check" size={12}/>{r.label}</li>)}
        <li className={matchOk?"ok":""}><Icon name="check" size={12}/>تکرار رمز با رمز جدید یکسان باشد</li>
      </ul>
      {state.error&&<div className="account-alert error"><Icon name="x" size={13}/>{state.error}</div>}
      {state.msg&&<div className="account-alert success"><Icon name="check" size={13}/>{state.msg}</div>}
      <button className="btn btn-primary" disabled={state.busy}>{state.busy?"در حال تغییر...":"تغییر رمز عبور"}</button>
    </form>
  </Layout>;
}
export default function Account(){const loc=useLocation();useDocumentTitle("حساب کاربری | زمانی");if(loc.pathname==="/account/profile")return <Profile/>;if(loc.pathname==="/account/addresses")return <Addresses/>;if(loc.pathname==="/account/password")return <Password/>;if(loc.pathname==="/account/wishlist")return <WishlistRedirect/>;return <Dashboard/>}
function WishlistRedirect(){const nav=useNavigate();useEffect(()=>{nav("/wishlist",{replace:true});},[nav]);return null;}
