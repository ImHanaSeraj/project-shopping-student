<?php

namespace App\Http\Requests\Ai;

use Illuminate\Foundation\Http\FormRequest;

class RewriteTextRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->isManager() ?? false;
    }

    public function rules(): array
    {
        return [
            'text' => ['required', 'string', 'min:5', 'max:4000'],
        ];
    }

    public function messages(): array
    {
        return [
            'text.required' => 'متنی برای بازنویسی وارد نشده است.',
            'text.min' => 'متن خیلی کوتاه است.',
        ];
    }
}
