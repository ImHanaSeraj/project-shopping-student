<?php
namespace App\Services;
use App\Models\Cart;
use App\Models\Discount;
use App\Models\DiscountUsage;
use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use RuntimeException;
class DiscountService {
    public function findForCart(string $code, Cart $cart, float $subtotal, User $user, bool $lock = false, array $lines = []): array {
        $normalized = strtoupper(trim($code));
        if ($normalized === '') throw new RuntimeException('کد تخفیف را وارد کنید.');
        $query = Discount::query()->where('code', $normalized)->where('status', true);
        if ($lock) $query->lockForUpdate();
        $discount = $query->first();
        if (!$discount) throw new RuntimeException('کد تخفیف معتبر نیست.');
        $today = now()->startOfDay();
        if ($discount->start_date && $today->lt($discount->start_date->startOfDay())) throw new RuntimeException('زمان استفاده از این کد تخفیف هنوز شروع نشده است.');
        if ($discount->end_date && $today->gt($discount->end_date->endOfDay())) throw new RuntimeException('مهلت استفاده از این کد تخفیف تمام شده است.');
        if ($discount->usage_limit !== null && $discount->used_count >= $discount->usage_limit) throw new RuntimeException('ظرفیت استفاده از این کد تخفیف تمام شده است.');
        if ($discount->per_user_limit !== null) {
            $count = DiscountUsage::where('discount_id',$discount->id)->where('user_id',$user->id)->count();
            if ($count >= $discount->per_user_limit) throw new RuntimeException('حداکثر تعداد استفاده شما از این کد تخفیف تکمیل شده است.');
        }
        if ($subtotal < (float)$discount->min_purchase) throw new RuntimeException('مبلغ سبد خرید برای استفاده از این کد کافی نیست.');
        $eligibleSubtotal = $subtotal;
        if ($discount->product_id) {
            $eligibleSubtotal = 0.0;
            foreach ($lines as $line) {
                if ((int)$line['product_id'] === (int)$discount->product_id) {
                    $eligibleSubtotal += (float)$line['line_total'];
                }
            }
            $eligibleSubtotal = round($eligibleSubtotal, 2);
            if ($eligibleSubtotal <= 0) throw new RuntimeException('این کد تخفیف برای محصولات سبد شما قابل استفاده نیست.');
        }
        $amount = $discount->type === 'percent'
            ? round($eligibleSubtotal * ((float)$discount->value / 100), 2)
            : round((float)$discount->value, 2);
        if ($discount->max_discount !== null) $amount = min($amount, (float)$discount->max_discount);
        $amount = min(max($amount,0), $eligibleSubtotal);
        return ['discount'=>$discount,'amount'=>round($amount,2),'code'=>$normalized, 'eligible_subtotal'=>round($eligibleSubtotal,2)];
    }
    public function recordUsage(Discount $discount, User $user, Order $order, float $amount): void {
        DiscountUsage::create(['discount_id'=>$discount->id,'user_id'=>$user->id,'order_id'=>$order->id,'amount'=>round($amount,2)]);
        $discount->increment('used_count');
    }
}
