import SEOHead from '../components/SEOHead';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from '../utils/routerCompat';
import Icon from '../components/Icon';
import ProductCard from '../components/products/ProductCard';
import { searchStore } from '../services/searchApi';

const nf = new Intl.NumberFormat('fa-IR');

function normalizeResponse(data) {
  const products = data?.products?.data || data?.products || [];
  const categories = data?.categories?.data || data?.categories || [];
  return {
    products: Array.isArray(products) ? products : [],
    categories: Array.isArray(categories) ? categories : [],
    total: Number(data?.meta?.products_total ?? data?.products_total ?? products.length),
  };
}

export default function Search() {
  const [params, setParams] = useSearchParams();
  const initial = params.get('q') || '';
  const [query, setQuery] = useState(initial);
  const [data, setData] = useState({ products: [], categories: [], total: 0 });
  const [loading, setLoading] = useState(Boolean(initial));
  const [error, setError] = useState(false);
  const requestId = useRef(0);

  useEffect(() => {
    const q = initial.trim();
    setQuery(initial);
    if (!q) {
      setData({ products: [], categories: [], total: 0 });
      setLoading(false);
      setError(false);
      return;
    }

    const id = ++requestId.current;
    setLoading(true);
    setError(false);
    const timer = setTimeout(() => {
      searchStore(q, { limit: 12 })
        .then(({ data: response }) => {
          if (id !== requestId.current) return;
          setData(normalizeResponse(response));
        })
        .catch(() => {
          if (id !== requestId.current) return;
          setData({ products: [], categories: [], total: 0 });
          setError(true);
        })
        .finally(() => {
          if (id === requestId.current) setLoading(false);
        });
    }, 180);

    return () => clearTimeout(timer);
  }, [initial]);

  const submit = (event) => {
    event.preventDefault();
    const q = query.trim();
    if (q) setParams({ q });
    else setParams({});
  };

  const clear = () => setParams({});
  const hasQuery = Boolean(initial.trim());
  const empty = hasQuery && !loading && !data.products.length && !data.categories.length;
  const heading = useMemo(() => hasQuery ? `نتایج جستجو برای «${initial}»` : 'جستجوی محصولات', [hasQuery, initial]);

  return (
    <main className="search-page">
      <section className="search-page-head container">
        <div className="breadcrumb"><Link to="/">خانه</Link><span>/</span><strong>جستجو</strong></div>
        <span className="eyebrow">ZAMANI SEARCH</span>
        <h1>{heading}</h1>
        <p>محصول، دسته‌بندی یا نام برند موردنظرتان را جستجو کنید.</p>
        <form className="search-page-form" onSubmit={submit}>
          <Icon name="search" size={19} />
          <input value={query} onChange={(e) => setQuery(e.target.value)} autoFocus placeholder="مثلاً مانتو، شومیز یا لباس مجلسی..." aria-label="جستجو" />
          {query && <button type="button" className="search-clear" onClick={() => setQuery('')} aria-label="پاک کردن"><Icon name="x" size={16}/></button>}
          <button type="submit" className="btn btn-primary"><span>جستجو</span> <Icon name="arrow" size={15}/></button>
        </form>
      </section>

      {!hasQuery ? (
        <section className="search-empty container search-empty-initial">
          <div className="search-empty-mark"><Icon name="search" size={28}/></div>
          <span className="eyebrow">SEARCH ZAMANI</span>
          <h2>دنبال چه چیزی هستید؟</h2>
          <p>عبارت جستجو را وارد کنید تا محصولات و دسته‌بندی‌های مرتبط را همین‌جا ببینید.</p>
        </section>
      ) : loading ? (
        <section className="container search-results-area">
          <div className="search-loading-head"><span className="skeleton-line short"/><span className="skeleton-line"/></div>
          <div className="search-category-skeletons"><i/><i/><i/></div>
          <div className="product-grid search-loading-grid">{[1,2,3,4,5,6].map(i => <div className="product-skeleton" key={i}><div className="skeleton-media"/><div className="skeleton-line short"/><div className="skeleton-line"/><div className="skeleton-line price"/></div>)}</div>
        </section>
      ) : empty ? (
        <section className="search-empty container">
          <div className="search-empty-mark"><Icon name="search" size={28}/></div>
          <span className="eyebrow">NO MATCH</span>
          <h2>نتیجه‌ای پیدا نشد</h2>
          <p>{error ? 'ارتباط با سرور جستجو برقرار نشد. دوباره امتحان کنید.' : `برای «${initial}» محصول یا دسته‌بندی مرتبطی پیدا نکردیم.`}</p>
          <div className="search-empty-actions"><button className="btn btn-primary" onClick={() => { setQuery(''); clear(); }}>جستجوی جدید</button><Link className="btn btn-outline" to="/products">مشاهده همه محصولات</Link></div>
        </section>
      ) : (
        <section className="container search-results-area">
          <div className="search-results-top"><div><span className="eyebrow">RESULTS</span><h2>{nf.format(data.total)} نتیجه</h2></div><Link to={`/products?search=${encodeURIComponent(initial)}`} className="text-link">مشاهده همه نتایج <Icon name="arrow" size={15}/></Link></div>

          {data.categories.length > 0 && <div className="search-category-results"><div className="search-subheading"><h3>دسته‌بندی‌های مرتبط</h3><span>{nf.format(data.categories.length)} دسته</span></div><div className="search-category-list">{data.categories.slice(0, 6).map(category => <Link to={`/products?category=${category.id}`} key={category.id} className="search-category-item"><span className="search-category-number">{String(category.id).padStart(2,'0')}</span><div><strong>{category.name}</strong><small>{category.products_count != null ? `${nf.format(category.products_count)} محصول` : 'مشاهده محصولات'}</small></div><Icon name="arrow" size={15}/></Link>)}</div></div>}

          {data.products.length > 0 && <div className="search-product-results"><div className="search-subheading"><h3>محصولات</h3><span>{nf.format(data.products.length)} مورد نمایش داده شد</span></div><div className="product-grid">{data.products.map(product => <ProductCard key={product.id} product={product}/>)}</div></div>}
        </section>
      )}
    </main>
  );
}
