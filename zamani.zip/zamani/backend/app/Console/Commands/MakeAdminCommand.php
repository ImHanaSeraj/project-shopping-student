<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class MakeAdminCommand extends Command
{
    /**
     * php artisan user:make-admin somebody@example.com
     * php artisan user:make-admin 09121234567
     * php artisan user:make-admin somebody@example.com --role=manager
     */
    protected $signature = 'user:make-admin
        {identifier : Email or phone of the user}
        {--role=admin : Role to assign (admin or manager)}';

    protected $description = 'Promote an existing user to admin or manager by email or phone';

    public function handle(): int
    {
        $identifier = $this->argument('identifier');
        $role = $this->option('role');

        if (!in_array($role, ['admin', 'manager'], true)) {
            $this->error('نقش باید admin یا manager باشد.');
            return self::FAILURE;
        }

        $user = User::where('email', $identifier)->orWhere('phone', $identifier)->first();

        if (!$user) {
            $this->error("کاربری با ایمیل/موبایل «{$identifier}» پیدا نشد. اول از طریق سایت ثبت‌نام کن، بعد همین دستور رو دوباره اجرا کن.");
            return self::FAILURE;
        }

        $user->update(['role' => $role, 'status' => true]);

        $this->info("کاربر «{$user->name}» ({$user->email}) با موفقیت به {$role} تبدیل شد.");
        return self::SUCCESS;
    }
}
