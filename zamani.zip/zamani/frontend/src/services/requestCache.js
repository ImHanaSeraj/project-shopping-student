const cache = new Map();
const inflight = new Map();

export function stableParams(params = {}) {
  const entries = [];
  if (params instanceof URLSearchParams) params.forEach((value, key) => entries.push([key, value]));
  else Object.entries(params || {}).forEach(([key, value]) => {
    if (value == null || value === '') return;
    (Array.isArray(value) ? value : [value]).forEach(v => entries.push([key, String(v)]));
  });
  return entries.sort(([a, av], [b, bv]) => a.localeCompare(b) || av.localeCompare(bv)).map(([k,v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
}

export function cachedGet(key, request, ttl = 30000) {
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && hit.expires > now) return Promise.resolve(hit.value);
  if (inflight.has(key)) return inflight.get(key);
  const promise = Promise.resolve().then(request).then(value => {
    cache.set(key, { value, expires: Date.now() + ttl });
    return value;
  }).finally(() => inflight.delete(key));
  inflight.set(key, promise);
  return promise;
}

export function invalidateCache(prefix = '') {
  for (const key of cache.keys()) if (!prefix || key.startsWith(prefix)) cache.delete(key);
}
