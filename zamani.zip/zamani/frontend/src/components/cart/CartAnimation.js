export function animateToCart(sourceElement, image) {
  if (typeof window === 'undefined' || !sourceElement) return;
  const target = document.querySelector('.cart-button[aria-label="سبد خرید"]');
  if (!target) return;
  const sourceRect = sourceElement.getBoundingClientRect();
  const targetRect = target.getBoundingClientRect();
  const clone = image ? document.createElement('img') : document.createElement('div');
  clone.className = 'cart-fly-clone';
  if (image) clone.src = image;
  Object.assign(clone.style, {left:`${sourceRect.left}px`,top:`${sourceRect.top}px`,width:`${Math.min(sourceRect.width,110)}px`,height:`${Math.min(sourceRect.height,110)}px`,borderRadius:'8px'});
  document.body.appendChild(clone);
  requestAnimationFrame(() => requestAnimationFrame(() => {
    clone.classList.add('is-flying');
    clone.style.left = `${targetRect.left + targetRect.width/2 - 13}px`;
    clone.style.top = `${targetRect.top + targetRect.height/2 - 13}px`;
    clone.style.width='26px'; clone.style.height='26px'; clone.style.borderRadius='50%';
  }));
  window.setTimeout(() => {
    clone.remove(); target.classList.remove('cart-badge-pop'); void target.offsetWidth; target.classList.add('cart-badge-pop');
    window.setTimeout(() => target.classList.remove('cart-badge-pop'), 420);
  }, 620);
}
