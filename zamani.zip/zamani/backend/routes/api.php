<?php
use App\Http\Controllers\Api\GeminiController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\HealthController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\OtpController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\BrandController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\ReviewController;
use App\Http\Controllers\Api\SearchController;
use App\Http\Controllers\Api\WishlistController;
use App\Http\Controllers\Api\CheckoutController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\AddressController;
use App\Http\Controllers\Api\ReferralController;
use App\Http\Controllers\Api\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Api\Admin\ProductAdminController;
use App\Http\Controllers\Api\Admin\CategoryAdminController;
use App\Http\Controllers\Api\Admin\BrandAdminController;
use App\Http\Controllers\Api\Admin\OrderAdminController;
use App\Http\Controllers\Api\Admin\UserAdminController;
use App\Http\Controllers\Api\Admin\ReviewAdminController;
use App\Http\Controllers\Api\Admin\DiscountAdminController;
use App\Http\Controllers\Api\Admin\SettingAdminController;
Route::get('/health',HealthController::class);
Route::get('/version', fn () => response()->json(['success' => true, 'app' => 'ZAMANI', 'api_version' => 'v1']));
Route::post('/size-guide/recommend', [\App\Http\Controllers\Api\SizeGuideController::class, 'recommend']);
Route::middleware('throttle:10,1')->group(function () {
    Route::post('/auth/register',[AuthController::class,'register']);
    Route::post('/auth/login',[AuthController::class,'login']);
});
Route::middleware('throttle:5,1')->group(function () {
    Route::post('/auth/forgot-password',[AuthController::class,'forgot']);
    Route::post('/auth/reset-password',[AuthController::class,'reset']);
    Route::post('/auth/otp/request',[OtpController::class,'requestLogin']);
    Route::post('/auth/otp/verify',[OtpController::class,'verifyLogin']);
});
Route::middleware(['auth:sanctum', 'active'])->group(function(){Route::get('/cart', [CartController::class, 'index']);Route::post('/cart/items', [CartController::class, 'store']);Route::patch('/cart/items/{cartItem}', [CartController::class, 'update']);Route::delete('/cart/items/{cartItem}', [CartController::class, 'destroy']);Route::delete('/cart', [CartController::class, 'clear']);Route::get('/wishlist', [WishlistController::class, 'index']);Route::post('/wishlist/{productId}', [WishlistController::class, 'store']);Route::delete('/wishlist/{productId}', [WishlistController::class, 'destroy']);Route::get('/wishlist/{productId}/status', [WishlistController::class, 'status']);Route::get('/referral', [ReferralController::class, 'show']);Route::post('/auth/logout',[AuthController::class,'logout']);Route::get('/profile',[AuthController::class,'profile']);Route::put('/profile',[AuthController::class,'update']);Route::put('/profile/password',[AuthController::class,'password']);Route::post('/profile/phone/otp/request',[OtpController::class,'requestPhoneVerification']);Route::post('/profile/phone/otp/verify',[OtpController::class,'verifyPhoneVerification']);
Route::post('/payments/{order}/pay', [PaymentController::class, 'pay']);
Route::get('/payments/{order}', [PaymentController::class, 'status']);
Route::get('/orders', [OrderController::class, 'index']);
Route::get('/orders/{order}', [OrderController::class, 'show']);
Route::post('/orders/{order}/cancel', [OrderController::class, 'cancel']);
Route::post('/orders/{order}/return', [OrderController::class, 'requestReturn']);
Route::get('/checkout/addresses',[AddressController::class,'index']);
Route::post('/checkout/addresses',[AddressController::class,'store']);
Route::put('/checkout/addresses/{address}',[AddressController::class,'update']);
Route::delete('/checkout/addresses/{address}',[AddressController::class,'destroy']);
Route::patch('/checkout/addresses/{address}/default',[AddressController::class,'makeDefault']);
Route::post('/checkout/summary',[CheckoutController::class,'summary']);
Route::post('/checkout/discount',[CheckoutController::class,'validateDiscount']);
Route::post('/checkout',[CheckoutController::class,'store']);});

Route::get('/categories', [CategoryController::class, 'index']);
Route::get('/brands', [BrandController::class, 'index']);
Route::get('/settings/public', [\App\Http\Controllers\Api\SettingController::class, 'publicSettings']);
Route::get('/payment/callback', [PaymentController::class, 'callback']);
Route::post('/payment/mock/callback', [PaymentController::class, 'mockCallback']);
Route::get('/search', SearchController::class);
Route::get('/categories/{slug}', [CategoryController::class, 'show']);
// Must be registered before the apiResource's /products/{product} route,
// otherwise Laravel matches "compare" as the {product} id/slug instead.
Route::get('/products/compare', [ProductController::class, 'compare']);
Route::apiResource('products', ProductController::class)->only(['index', 'show']);
Route::get('/products/{id}/related',[ProductController::class,'related']);
Route::middleware(['auth:sanctum', 'active'])->post('/products/{id}/reviews',[ReviewController::class,'store']);

// Admin panel API
Route::middleware(['auth:sanctum', 'admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', AdminDashboardController::class);
    Route::get('/discounts', [DiscountAdminController::class,'index']);
    Route::post('/discounts', [DiscountAdminController::class,'store']);
    Route::put('/discounts/{id}', [DiscountAdminController::class,'update']);
    Route::delete('/discounts/{id}', [DiscountAdminController::class,'destroy']);
    Route::get('/discount-products', [DiscountAdminController::class,'products']);
    Route::get('/products', [ProductAdminController::class,'index']);
    Route::post('/products', [ProductAdminController::class,'store']);
    Route::get('/products/{id}', [ProductAdminController::class,'show']);
    Route::put('/products/{id}', [ProductAdminController::class,'update']);
    Route::delete('/products/{id}', [ProductAdminController::class,'destroy']);
    Route::patch('/products/{id}/toggle', [ProductAdminController::class,'toggle']);
    Route::middleware('throttle:20,1')->post('/products/upload-image', [ProductAdminController::class,'uploadImage']);
    Route::get('/categories', [CategoryAdminController::class,'index']);
    Route::post('/categories/upload-image', [CategoryAdminController::class,'uploadImage']);
    Route::post('/categories', [CategoryAdminController::class,'store']);
    Route::put('/categories/{id}', [CategoryAdminController::class,'update']);
    Route::delete('/categories/{id}', [CategoryAdminController::class,'destroy']);
    Route::get('/brands', [BrandAdminController::class,'index']);
    Route::post('/brands', [BrandAdminController::class,'store']);
    Route::put('/brands/{id}', [BrandAdminController::class,'update']);
    Route::delete('/brands/{id}', [BrandAdminController::class,'destroy']);
    Route::get('/orders', [OrderAdminController::class,'index']);
    Route::get('/orders/{id}', [OrderAdminController::class,'show']);
    Route::patch('/orders/{id}/status', [OrderAdminController::class,'updateStatus']);
    Route::get('/users', [UserAdminController::class,'index']);
    Route::get('/users/{id}', [UserAdminController::class,'show']);
    Route::patch('/users/{id}', [UserAdminController::class,'update']);
    Route::get('/reviews', [ReviewAdminController::class,'index']);
    Route::patch('/reviews/{id}/status', [ReviewAdminController::class,'updateStatus']);
    Route::delete('/reviews/{id}', [ReviewAdminController::class,'destroy']);
    Route::get('/settings', [SettingAdminController::class,'index']);
    Route::put('/settings', [SettingAdminController::class,'upsert']);
    Route::delete('/settings/{key}', [SettingAdminController::class,'destroy']);
    Route::get('/support-chat', [\App\Http\Controllers\Api\Admin\SupportChatAdminController::class,'index']);
    Route::get('/support-chat/{conversation}', [\App\Http\Controllers\Api\Admin\SupportChatAdminController::class,'show']);
    Route::post('/support-chat/{conversation}/claim', [\App\Http\Controllers\Api\Admin\SupportChatAdminController::class,'claim']);
    Route::post('/support-chat/{conversation}/reply', [\App\Http\Controllers\Api\Admin\SupportChatAdminController::class,'reply']);
    Route::post('/support-chat/{conversation}/close', [\App\Http\Controllers\Api\Admin\SupportChatAdminController::class,'close']);
});

// Advanced HANA-derived capabilities integrated into ZAMANI without replacing its clothing commerce flow.
Route::post('/chatbot/send',[\App\Http\Controllers\Api\Ai\ChatbotController::class,'send']);
Route::post('/chatbot/escalate',[\App\Http\Controllers\Api\Ai\ChatbotController::class,'escalate']);
Route::middleware(['auth:sanctum','active'])->group(function(){
 Route::get('/notifications',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'notifications']);
 Route::patch('/notifications/{id}/read',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'notificationRead']);
 Route::patch('/notifications/read-all',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'notificationReadAll']);
});
Route::get('/chatbot/{conversationId}',[\App\Http\Controllers\Api\Ai\ChatbotController::class,'history']);
Route::get('/recommendations',[\App\Http\Controllers\Api\Ai\RecommendationController::class,'forUser'])->middleware('auth:sanctum');

// Public: powers the on-page "راهنمای سایز هوشمند" (Gemini chat/size/product_copy
// assistant). Must stay outside the admin group - customers browsing a product
// page are not authenticated admins. GeminiController itself still rejects
// mode=product_copy for guests, so nothing admin-only leaks out here.
Route::post('/ai/gemini', GeminiController::class);

Route::middleware(['auth:sanctum','admin'])->prefix('admin')->group(function(){
 Route::get('/advanced/dashboard',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'dashboard']);
 Route::get('/advanced/reports',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'reports']);
 Route::get('/advanced/logs',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'logs']);
 Route::get('/advanced/messages',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'messages']);
 Route::patch('/advanced/messages/{contactMessage}/read',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'messageRead']);
 Route::post('/advanced/messages/{contactMessage}/reply',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'messageReply']);
 Route::patch('/advanced/messages/{contactMessage}/archive',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'messageArchive']);
 Route::get('/advanced/warehouses',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'warehouses']);
 Route::post('/advanced/warehouses',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'warehouseStore']);
 Route::put('/advanced/warehouses/{warehouse}',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'warehouseUpdate']);
 Route::patch('/advanced/warehouses/{warehouse}/stock',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'warehouseStock']);
 Route::delete('/advanced/warehouses/{warehouse}',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'warehouseDelete']);
 Route::get('/advanced/suppliers',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'suppliers']);
 Route::post('/advanced/suppliers',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'supplierStore']);
 Route::put('/advanced/suppliers/{supplier}',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'supplierUpdate']);
 Route::delete('/advanced/suppliers/{supplier}',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'supplierDelete']);
 Route::get('/advanced/files',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'files']);
 Route::post('/advanced/files',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'fileUpload']);
 Route::delete('/advanced/files/{file}',[\App\Http\Controllers\Api\AdvancedFeaturesController::class,'fileDelete']);
 Route::prefix('ai')->group(function(){
  Route::post('/products/generate-content',[\App\Http\Controllers\Api\Ai\ProductAiController::class,'generateContent']);
  Route::post('/products/rewrite-text',[\App\Http\Controllers\Api\Ai\ProductAiController::class,'rewriteText']);
  Route::post('/products/generate-specs',[\App\Http\Controllers\Api\Ai\ProductAiController::class,'generateSpecs']);
  Route::post('/products/suggest-category',[\App\Http\Controllers\Api\Ai\ProductAiController::class,'suggestCategory']);
  Route::post('/products/suggest-tags',[\App\Http\Controllers\Api\Ai\ProductAiController::class,'suggestTags']);
  Route::post('/products/suggest-price',[\App\Http\Controllers\Api\Ai\ProductAiController::class,'suggestPrice']);
  Route::post('/products/generate-seo',[\App\Http\Controllers\Api\Ai\ProductAiController::class,'generateSeo']);
  Route::get('/products/{product}/similar',[\App\Http\Controllers\Api\Ai\ProductAiController::class,'similar']);
 });
});
