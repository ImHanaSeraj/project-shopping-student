import InfoPages from '../../views/InfoPages';

export async function getServerSideProps() {
  const backend = 'http://127.0.0.1:8000/api';
  try {
    const response = await fetch(`${backend}/categories`, {
      headers: { Accept: 'application/json' },
      cache: 'no-store',
    });
    const text = await response.text();
    let payload = [];
    try { payload = JSON.parse(text); } catch {}
    const categories = Array.isArray(payload)
      ? payload
      : (Array.isArray(payload?.data) ? payload.data : []);
    return { props: { initialCategories: categories } };
  } catch (error) {
    return { props: { initialCategories: [], initialCategoryError: 'ارتباط با سرور فروشگاه برقرار نشد.' } };
  }
}

export default function CategoriesPage({ initialCategories = [], initialCategoryError = '' }) {
  return (
    <InfoPages
      kind="categories"
      initialCategories={initialCategories}
      initialCategoryError={initialCategoryError}
    />
  );
}
