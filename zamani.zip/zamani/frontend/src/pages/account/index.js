import Account from '../../views/Account';
import ProtectedRoute from '../../guards/ProtectedRoute';
export default function AccountPage(){ return <ProtectedRoute><Account/></ProtectedRoute>; }
