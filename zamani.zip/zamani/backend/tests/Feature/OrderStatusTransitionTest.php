<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Services\OrderStatusService;
use Tests\TestCase;

class OrderStatusTransitionTest extends TestCase
{
    public function test_order_status_workflow_allows_only_defined_transitions(): void
    {
        $service = app(OrderStatusService::class);
        $order = new Order(['status' => 'pending', 'payment_status' => 'pending']);

        $service->transition($order, 'awaiting_payment');
        $this->assertSame('awaiting_payment', $order->status);

        $order->payment_status = 'paid';
        $service->transition($order, 'paid');
        $this->assertSame('paid', $order->status);

        $service->transition($order, 'processing');
        $service->transition($order, 'shipped');
        $service->transition($order, 'delivered');
        $this->assertSame('delivered', $order->status);
    }

    public function test_invalid_jump_is_rejected(): void
    {
        $this->expectException(\RuntimeException::class);

        $service = app(OrderStatusService::class);
        $order = new Order(['status' => 'pending', 'payment_status' => 'pending']);
        $service->transition($order, 'shipped');
    }

    public function test_refund_requires_paid_then_refund_requested(): void
    {
        $service = app(OrderStatusService::class);
        $order = new Order(['status' => 'paid', 'payment_status' => 'paid']);

        $service->transition($order, 'refund_requested');
        $service->transition($order, 'refunded');

        $this->assertSame('refunded', $order->status);
    }
}
