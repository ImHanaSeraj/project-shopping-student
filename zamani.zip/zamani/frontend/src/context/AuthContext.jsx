import React, { createContext, useEffect, useState, useContext } from 'react';
import api from '../services/api';

export const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

const clearStoredAuth = () => {
  if (typeof window === 'undefined') return;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
};

export default function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const stored = localStorage.getItem('user');
    if (stored) {
      try { setUser(JSON.parse(stored)); } catch { setUser(null); }
    }
    if (!token) { setLoading(false); return; }
    api.get('/profile')
      .then(({ data }) => {
        localStorage.setItem('user', JSON.stringify(data));
        setUser(data);
      })
      .catch(() => { clearStoredAuth(); setUser(null); })
      .finally(() => setLoading(false));
  }, []);

  const login = (u, token) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(u));
    setUser(u);
  };

  const updateToken = (token) => { if (token && typeof window !== 'undefined') localStorage.setItem('token', token); };

  const updateUser = (u) => {
    if (typeof window === 'undefined' || !u) return;
    localStorage.setItem('user', JSON.stringify(u));
    setUser(u);
  };

  const logout = () => {
    if (typeof window !== 'undefined') {
      clearStoredAuth();
      localStorage.removeItem('zamani_cart');
      localStorage.removeItem('zamani_wishlist');
      window.dispatchEvent(new Event('zamani-cart-updated'));
      window.dispatchEvent(new Event('zamani-wishlist-updated'));
    }
    setUser(null);
  };

  return <AuthContext.Provider value={{ user, login, updateToken, updateUser, logout, loading }}>{children}</AuthContext.Provider>;
}
