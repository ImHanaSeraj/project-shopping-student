<?php

namespace App\Http\Controllers\Api\Ai;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\GeminiService;
use Illuminate\Http\Request;
use Throwable;

class ProductAiController extends Controller
{
    public function __construct(private GeminiService $gemini) {}

    private function productCopy(Request $request, string $type = 'full')
    {
        try {
            $result = $this->gemini->generate('product_copy', [
                'copy_type' => $type,
                'product' => $request->all(),
                'current_text' => $request->input('current_text', $request->input('text', '')),
            ]);

            return response()->json([
                'success' => true,
                'result' => $result['data']['text'] ?? '',
                'data' => $result['data'] ?? [],
                'provider' => 'gemini',
                'model' => $result['model'] ?? null,
            ]);
        } catch (Throwable $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 502);
        }
    }

    public function generateContent(Request $request) { return $this->productCopy($request, 'full'); }

    public function rewriteText(Request $request)
    {
        return $this->productCopy($request, 'full');
    }

    private function simpleAi(Request $request, string $instruction)
    {
        try {
            $result = $this->gemini->generate('chat', [
                'message' => $instruction . "\nاطلاعات محصول:\n" .
                    json_encode($request->all(), JSON_UNESCAPED_UNICODE),
            ]);

            return response()->json([
                'success' => true,
                'result' => $result['reply'] ?? '',
                'provider' => 'gemini',
                'model' => $result['model'] ?? null,
            ]);
        } catch (Throwable $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 502);
        }
    }

    public function generateSpecs(Request $request) { return $this->simpleAi($request, 'مشخصات و ویژگی‌های مناسب این محصول پوشاک را تولید کن. اطلاعاتی که داده نشده حدس نزن.'); }
    public function suggestCategory(Request $request) { return $this->simpleAi($request, 'دسته‌بندی مناسب این محصول پوشاک را پیشنهاد بده.'); }
    public function suggestTags(Request $request) { return $this->simpleAi($request, '۱۰ تگ فارسی مناسب برای این محصول پیشنهاد بده.'); }
    public function suggestPrice(Request $request) { return $this->simpleAi($request, 'یک بازه قیمت منطقی برای این محصول پیشنهاد بده و دلیل کوتاه بنویس.'); }
    public function generateSeo(Request $request) { return $this->simpleAi($request, 'عنوان SEO، توضیحات متا و کلمات کلیدی مناسب این محصول تولید کن.'); }

    public function similar(Product $product)
    {
        $items = Product::where('id','!=',$product->id)
            ->where('category_id',$product->category_id)
            ->limit(8)->get();

        return response()->json(['success'=>true,'data'=>$items]);
    }
}
