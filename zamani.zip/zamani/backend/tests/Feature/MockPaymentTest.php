<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MockPaymentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['payment.gateway' => 'mock', 'payment.mock_enabled' => true, 'payment.mock_frontend_url' => 'http://localhost:3000/payment/mock']);
    }

    public function test_mock_success_marks_payment_and_order_paid_and_commits_stock(): void
    {
        [$user, $order, $payment, $variant] = $this->makeOrder(1);
        $response = $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay');
        $response->assertOk()->assertJsonPath('status', 'redirect');
        $payment->refresh();

        $callback = $this->postJson('/api/payment/mock/callback', [
            'payment' => $payment->id,
            'token' => $payment->authority,
            'outcome' => 'success',
        ]);
        $callback->assertOk()->assertJsonPath('status', 'success');

        $order->refresh(); $payment->refresh(); $variant->refresh();
        $this->assertSame('paid', $order->status);
        $this->assertSame('paid', $order->payment_status);
        $this->assertSame('paid', $payment->status);
        $this->assertSame('committed', $order->inventory_status);
        $this->assertSame(0, (int) $variant->stock);
        $this->assertNotEmpty($payment->ref_id);
    }

    public function test_mock_failure_releases_stock_and_is_idempotent(): void
    {
        [$user, $order, $payment, $variant] = $this->makeOrder(1);
        $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay')->assertOk();
        $payment->refresh();

        $payload = ['payment' => $payment->id, 'token' => $payment->authority, 'outcome' => 'failed'];
        $this->postJson('/api/payment/mock/callback', $payload)->assertOk()->assertJsonPath('status', 'failed');
        $this->postJson('/api/payment/mock/callback', $payload)->assertOk()->assertJsonPath('idempotent', true);

        $order->refresh(); $payment->refresh(); $variant->refresh();
        $this->assertSame('failed', $payment->status);
        $this->assertSame('failed', $order->payment_status);
        $this->assertSame('pending', $order->status);
        $this->assertSame('released', $order->inventory_status);
        $this->assertSame(1, (int) $variant->stock);
    }

    public function test_failed_payment_can_be_retried_and_re_reserves_current_stock(): void
    {
        [$user, $order, $payment, $variant] = $this->makeOrder(1);
        $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay')->assertOk();
        $payment->refresh();
        $this->postJson('/api/payment/mock/callback', ['payment'=>$payment->id,'token'=>$payment->authority,'outcome'=>'failed'])->assertOk();

        $retry = $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay');
        $retry->assertOk()->assertJsonPath('status', 'redirect');
        $order->refresh();
        $this->assertSame('reserved', $order->inventory_status);
        $this->assertSame(0, (int) $variant->fresh()->stock);
    }

    public function test_repeated_success_callback_does_not_consume_stock_twice(): void
    {
        [$user, $order, $payment, $variant] = $this->makeOrder(1);
        $this->actingAs($user)->postJson('/api/payments/'.$order->id.'/pay')->assertOk();
        $payment->refresh();
        $payload = ['payment' => $payment->id, 'token' => $payment->authority, 'outcome' => 'success'];
        $this->postJson('/api/payment/mock/callback', $payload)->assertOk();
        $this->postJson('/api/payment/mock/callback', $payload)->assertOk()->assertJsonPath('idempotent', true);
        $this->assertSame(0, (int) $variant->fresh()->stock);
    }

    private function makeOrder(int $stock): array
    {
        $user = User::factory()->create();
        $address = Address::create(['user_id'=>$user->id,'receiver_name'=>'Test','phone'=>'09120000000','province'=>'Tehran','city'=>'Tehran','address'=>'Test street','postal_code'=>'1234567890','is_default'=>true]);
        $product = Product::factory()->create(['status'=>true,'stock'=>$stock,'price'=>500000]);
        $variant = ProductVariant::create(['product_id'=>$product->id,'size'=>'M','color'=>'Black','SKU'=>'MOCK-'.uniqid(),'stock'=>$stock,'status'=>true]);
        $cart = Cart::create(['user_id'=>$user->id]);
        CartItem::create(['cart_id'=>$cart->id,'product_id'=>$product->id,'variant_id'=>$variant->id,'quantity'=>1]);
        $this->actingAs($user)->postJson('/api/checkout', ['address_id'=>$address->id,'shipping_method'=>'standard'])->assertCreated();
        $order = Order::where('user_id',$user->id)->latest()->firstOrFail();
        $payment = $order->payment()->firstOrFail();
        return [$user, $order, $payment, $variant];
    }
}
