<?php

namespace App\Http\Requests\Ai;

use Illuminate\Foundation\Http\FormRequest;

class ResizeImageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->isManager() ?? false;
    }

    public function rules(): array
    {
        return [
            'image' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:10240'],
            
            
            'width' => ['nullable', 'required_without:height', 'integer', 'min:1', 'max:8000'],
            'height' => ['nullable', 'required_without:width', 'integer', 'min:1', 'max:8000'],
        ];
    }

    public function messages(): array
    {
        return [
            'image.required' => 'انتخاب تصویر الزامی است.',
            'image.image' => 'فایل انتخاب‌شده باید یک تصویر باشد.',
            'image.mimes' => 'فرمت تصویر باید jpg، jpeg، png یا webp باشد.',
            'image.max' => 'حجم تصویر نباید بیشتر از ۱۰ مگابایت باشد.',
            'width.required_without' => 'حداقل یکی از عرض یا ارتفاع باید مشخص شود.',
            'width.integer' => 'عرض باید عدد صحیح باشد.',
            'width.max' => 'عرض نباید بیشتر از ۸۰۰۰ پیکسل باشد.',
            'height.required_without' => 'حداقل یکی از عرض یا ارتفاع باید مشخص شود.',
            'height.integer' => 'ارتفاع باید عدد صحیح باشد.',
            'height.max' => 'ارتفاع نباید بیشتر از ۸۰۰۰ پیکسل باشد.',
        ];
    }
}
