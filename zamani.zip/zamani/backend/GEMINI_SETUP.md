# اتصال کامل Gemini به Laravel

این فایل‌ها Gemini را از Next.js خارج می‌کنند و اتصال را از Laravel انجام می‌دهند.

## 1) config/services.php
این بخش را داخل آرایه تنظیمات اضافه کنید:

```php
'gemini' => [
    'key' => env('GEMINI_API_KEY'),
    'model' => env('GEMINI_MODEL', 'gemini-3.6-flash'),
],
```

## 2) routes/api.php
اضافه کنید:

```php
use App\Http\Controllers\Api\GeminiController;

Route::post('/ai/gemini', GeminiController::class)->middleware('throttle:ai');
Route::post('/admin/ai/gemini', GeminiController::class)->middleware(['auth:sanctum','throttle:ai']);
```

اگر throttle با نام `ai` در پروژه تعریف نشده، فعلاً `throttle:ai` را حذف کنید یا یک limiter با همین نام در RouteServiceProvider تعریف کنید.

## 3) .env بک‌اند
```env
GEMINI_API_KEY=کلید-خودت
GEMINI_MODEL=gemini-3.6-flash
# یا در پروژه‌های قدیمی: GEMINI_TEXT_MODEL=gemini-3.6-flash
```

مهم: فایل `.env` واقعی بک‌اند را تنظیم کنید؛ صرفاً `.env.example` کافی نیست.

بعد:

```bash
php artisan optimize:clear
```

کلید فقط در Laravel می‌ماند و نباید با `NEXT_PUBLIC_` تعریف شود.
