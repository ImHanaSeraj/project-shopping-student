<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ReturnPolicyTest extends TestCase
{
    use RefreshDatabase;

    public function test_customer_can_request_return_within_three_days_of_delivery(): void
    {
        $user = User::factory()->create();
        $order = Order::factory()->create([
            'user_id' => $user->id,
            'status' => 'delivered',
            'payment_status' => 'paid',
            'delivered_at' => now()->subDays(2),
        ]);

        $response = $this->actingAs($user)->postJson("/api/orders/{$order->id}/return");

        $response->assertOk();
        $this->assertDatabaseHas('orders', [
            'id' => $order->id,
            'status' => 'refund_requested',
            'payment_status' => 'refund_requested',
        ]);
    }

    public function test_customer_cannot_request_return_after_three_days(): void
    {
        $user = User::factory()->create();
        $order = Order::factory()->create([
            'user_id' => $user->id,
            'status' => 'delivered',
            'payment_status' => 'paid',
            'delivered_at' => now()->subDays(3)->subMinute(),
        ]);

        $response = $this->actingAs($user)->postJson("/api/orders/{$order->id}/return");

        $response->assertStatus(422);
        $this->assertDatabaseHas('orders', [
            'id' => $order->id,
            'status' => 'delivered',
            'payment_status' => 'paid',
        ]);
    }

    public function test_customer_cannot_request_return_for_another_users_order(): void
    {
        $owner = User::factory()->create();
        $other = User::factory()->create();
        $order = Order::factory()->create([
            'user_id' => $owner->id,
            'status' => 'delivered',
            'payment_status' => 'paid',
            'delivered_at' => now()->subDay(),
        ]);

        $this->actingAs($other)
            ->postJson("/api/orders/{$order->id}/return")
            ->assertNotFound();
    }
}
