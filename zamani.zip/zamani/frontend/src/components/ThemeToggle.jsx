import React from 'react';
import Icon from './Icon';
import { useTheme } from '../context/ThemeContext';

export default function ThemeToggle({ className = '' }) {
  const { isDark, toggleTheme } = useTheme();
  const label = isDark ? 'فعال‌کردن حالت روشن' : 'فعال‌کردن حالت تاریک';
  return (
    <button
      type="button"
      className={`theme-toggle ${className}`.trim()}
      onClick={toggleTheme}
      aria-label={label}
      title={label}
    >
      <span className="theme-toggle-track" aria-hidden="true">
        <span className="theme-toggle-icon theme-toggle-sun"><Icon name="sun" size={14} /></span>
        <span className="theme-toggle-icon theme-toggle-moon"><Icon name="moon" size={14} /></span>
        <span className="theme-toggle-knob"><Icon name={isDark ? 'moon' : 'sun'} size={12} /></span>
      </span>
      <span className="theme-toggle-label">{isDark ? 'تاریک' : 'روشن'}</span>
    </button>
  );
}
