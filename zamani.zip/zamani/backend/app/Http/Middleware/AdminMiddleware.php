<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (!$user || !$user->status || !in_array($user->role, ['admin', 'manager'], true)) {
            return response()->json([
                'message' => 'دسترسی مدیر یا مدیر اجرایی لازم است.',
            ], 403);
        }

        return $next($request);
    }
}
