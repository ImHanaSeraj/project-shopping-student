<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatConversation extends Model
{
    // Lifecycle: bot (AI answers) -> pending (customer asked for a human, waiting for
    // an operator to pick it up) -> active (an admin claimed it and is replying) -> closed.
    protected $fillable = ['user_id', 'session_id', 'status', 'assigned_admin_id', 'escalated_at', 'closed_at'];

    protected $casts = [
        'escalated_at' => 'datetime',
        'closed_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function assignedAdmin()
    {
        return $this->belongsTo(User::class, 'assigned_admin_id');
    }

    public function messages()
    {
        return $this->hasMany(ChatMessage::class);
    }

    public function isHumanHandled(): bool
    {
        return in_array($this->status, ['pending', 'active'], true);
    }

    // Label shown to the admin inbox for the person on the other end of the conversation.
    public function customerLabel(): string
    {
        return $this->user->name ?? 'مهمان #' . substr((string) $this->session_id, 0, 8);
    }
}
