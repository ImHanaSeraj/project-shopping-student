<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void { Schema::table('payments', function (Blueprint $table) { $table->string('authority')->nullable()->index(); $table->string('ref_id')->nullable()->index(); }); }
    public function down(): void { Schema::table('payments', function (Blueprint $table) { $table->dropIndex(['payments_authority_index']); $table->dropIndex(['payments_ref_id_index']); $table->dropColumn(['authority','ref_id']); }); }
};
