import api from './api';

// Password-less login
export const requestLoginOtp = (phone) => api.post('/auth/otp/request', { phone });
export const verifyLoginOtp = (phone, code) => api.post('/auth/otp/verify', { phone, code });

// Verifying the authenticated user's own phone (e.g. before checkout)
export const requestPhoneOtp = () => api.post('/profile/phone/otp/request');
export const verifyPhoneOtp = (code) => api.post('/profile/phone/otp/verify', { code });
