import Account from '../views/Account';
import ProtectedRoute from '../guards/ProtectedRoute';
export default function ProfilePage(){ return <ProtectedRoute><Account/></ProtectedRoute>; }
