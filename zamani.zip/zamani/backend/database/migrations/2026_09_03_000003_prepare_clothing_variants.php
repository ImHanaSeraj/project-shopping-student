<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('product_variants', function (Blueprint $table) {
            $table->string('size', 50)->nullable()->after('value');
            $table->string('color', 100)->nullable()->after('size');
            $table->string('image')->nullable()->after('SKU');
            $table->boolean('status')->default(true)->after('image');
            $table->index(['product_id', 'size', 'color', 'status']);
        });
    }

    public function down(): void
    {
        Schema::table('product_variants', function (Blueprint $table) {
            $table->dropIndex(['product_id', 'size', 'color', 'status']);
            $table->dropColumn(['size', 'color', 'image', 'status']);
        });
    }
};
