<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Console\Scheduling\Schedule;
use App\Http\Middleware\AdminMiddleware;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;

return Application::configure(basePath: dirname(__DIR__))
    ->withProviders([
        Laravel\Sanctum\SanctumServiceProvider::class,
    ])
    ->withSchedule(function (Schedule $schedule): void {
        if (config('backup.schedule_enabled', false)) {
            $schedule->command('backup:database')
                ->dailyAt(config('backup.schedule_time', '03:00'))
                ->withoutOverlapping();
        }
    })
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    // Registers POST /broadcasting/auth (protected by auth:sanctum, matching the
    // rest of this stateless API) and loads routes/channels.php for channel
    // authorization callbacks. Required for the live support-chat feature.
    ->withBroadcasting(
        __DIR__.'/../routes/channels.php',
        ['middleware' => ['auth:sanctum']],
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'admin' => AdminMiddleware::class,
            'active' => \App\Http\Middleware\ActiveUserMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // API clients always receive a stable JSON envelope. Internal exception
        // details and stack traces are never exposed to clients in production.
        $exceptions->render(function (ValidationException $e, Request $request) {
            if (!$request->is('api/*')) {
                return null;
            }

            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'VALIDATION_ERROR',
                    'message' => 'اطلاعات ارسال‌شده معتبر نیست.',
                    'details' => $e->errors(),
                ],
            ], 422);
        });

        $exceptions->render(function (HttpExceptionInterface $e, Request $request) {
            if (!$request->is('api/*')) {
                return null;
            }

            $status = $e->getStatusCode();
            $messages = [
                400 => 'درخواست نامعتبر است.',
                401 => 'برای انجام این عملیات باید وارد حساب شوید.',
                403 => 'شما اجازه انجام این عملیات را ندارید.',
                404 => 'مورد درخواست‌شده پیدا نشد.',
                405 => 'این عملیات مجاز نیست.',
                409 => 'درخواست با وضعیت فعلی سازگار نیست.',
                419 => 'درخواست منقضی شده است.',
                422 => 'اطلاعات ارسال‌شده معتبر نیست.',
                429 => 'تعداد درخواست‌ها بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.',
                500 => 'خطای داخلی سرور رخ داده است.',
                502 => 'ارتباط با سرویس پرداخت/خارجی با خطا مواجه شد.',
                503 => 'سرویس موقتاً در دسترس نیست.',
            ];

            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'HTTP_ERROR',
                    'message' => $messages[$status] ?? 'درخواست قابل پردازش نیست.',
                ],
            ], $status);
        });

        $exceptions->render(function (Throwable $e, Request $request) {
            if (!$request->is('api/*')) {
                return null;
            }

            // Laravel logs the exception server-side. Never return the exception
            // message, class, file, trace, query or payment payload to the client.
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'SERVER_ERROR',
                    'message' => config('app.debug')
                        ? $e->getMessage()
                        : 'خطای داخلی سرور رخ داده است.',
                ],
            ], 500);
        });
    })->create();