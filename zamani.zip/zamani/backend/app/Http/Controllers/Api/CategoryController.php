<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\JsonResponse;

class CategoryController extends Controller
{
    private function normalizeImage(?string $value): ?string
    {
        if (!$value) return null;
        $value = trim($value);
        if ($value === '') return null;

        $pos = stripos($value, '/storage/');
        if ($pos !== false) return '/storage/' . ltrim(substr($value, $pos + 9), '/');
        if (preg_match('#^storage/(.+)$#i', ltrim($value, '/'), $m)) {
            return '/storage/' . $m[1];
        }

        return $value;
    }

    private function normalizeTree($category)
    {
        $category->image = $this->normalizeImage($category->image);
        if ($category->relationLoaded('children')) {
            $category->setRelation('children', $category->children->map(function ($child) {
                $child->image = $this->normalizeImage($child->image);
                return $child;
            })->values());
        }
        return $category;
    }

    /**
     * Public category source of truth.
     *
     * The storefront must read the same categories that the admin panel writes
     * to the categories table. No hard-coded category list and no server cache
     * are used here, so an admin change is visible on the next request.
     */
    public function index(): JsonResponse
    {
        // Single source of truth for the storefront: the categories table.
        // Return every active category as a flat list so both root categories
        // and categories created as children by the admin are visible.
        $categories = Category::query()
            ->select('id', 'name', 'slug', 'description', 'image', 'parent_id', 'status')
            ->where('status', true)
            ->orderBy('id')
            ->get()
            ->map(function ($category) {
                $category->image = $this->normalizeImage($category->image);
                return $category;
            })
            ->values();

        return response()->json($categories);
    }

    public function show($slug): JsonResponse
    {
        $category = Category::query()
            ->select('id', 'name', 'slug', 'description', 'image', 'parent_id', 'status')
            ->where('slug', $slug)
            ->where('status', true)
            ->with([
                'parent:id,name,slug,parent_id,status',
                'children' => function ($query) {
                    $query->select('id', 'name', 'slug', 'description', 'image', 'parent_id', 'status')
                        ->where('status', true)
                        ->orderBy('id');
                },
            ])
            ->firstOrFail();

        $ids = $this->descendantIds($category->id);
        $category->setAttribute('product_category_ids', $ids);
        $category->setAttribute(
            'branch_products_count',
            \App\Models\Product::query()
                ->whereIn('category_id', $ids)
                ->where('status', true)
                ->count()
        );

        return response()->json($this->normalizeTree($category));
    }

    private function descendantIds(int $categoryId): array
    {
        $ids = [$categoryId];
        $frontier = [$categoryId];

        while ($frontier) {
            $children = Category::query()
                ->whereIn('parent_id', $frontier)
                ->where('status', true)
                ->pluck('id')
                ->map(fn ($id) => (int) $id)
                ->all();

            $children = array_values(array_diff($children, $ids));
            if (!$children) break;

            $ids = array_merge($ids, $children);
            $frontier = $children;
        }

        return array_values(array_unique($ids));
    }
}
