<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void {
 Schema::table('chat_conversations',function(Blueprint $t){
  $t->string('status')->default('bot')->after('session_id'); // bot | pending | active | closed
  $t->foreignId('assigned_admin_id')->nullable()->after('status')->constrained('users')->nullOnDelete();
  $t->timestamp('escalated_at')->nullable()->after('assigned_admin_id');
  $t->timestamp('closed_at')->nullable()->after('escalated_at');
 });
 Schema::table('chat_messages',function(Blueprint $t){
  $t->foreignId('sender_id')->nullable()->after('role')->constrained('users')->nullOnDelete(); // set when role=admin
 });
} public function down(): void {
 Schema::table('chat_messages',function(Blueprint $t){$t->dropConstrainedForeignId('sender_id');});
 Schema::table('chat_conversations',function(Blueprint $t){$t->dropConstrainedForeignId('assigned_admin_id');$t->dropColumn(['status','escalated_at','closed_at']);});
}};
