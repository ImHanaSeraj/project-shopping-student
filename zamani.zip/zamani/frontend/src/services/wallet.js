import api from './api';
export const getWallet = () => api.get('/wallet');
export const topupWallet = (amount) => api.post('/wallet/topup', { amount });
