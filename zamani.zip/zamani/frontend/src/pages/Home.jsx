import SEOHead from '../components/SEOHead';
import { useEffect, useState } from 'react';
import { Link } from '../utils/routerCompat';
import Icon from '../components/Icon';
import ProductCard from '../components/products/ProductCard';
import { getCategories, getProducts } from '../services/productApi';

// تصاویر اختصاصی دسته‌بندی‌های محبوب از public/images/Popular Products
const POPULAR_CATEGORY_IMAGES = [
  { keywords: ['جوراب', 'jorab'], file: 'jorab.png', label: 'جوراب' },
  { keywords: ['پیراهن', 'pirahan'], file: 'pirahan.png', label: 'پیراهن' },
  { keywords: ['ست', 'زنانه', 'setzanane', 'set zanane'], file: 'setzanane.png', label: 'ست زنانه' },
  { keywords: ['شلوار', 'shalvar'], file: 'shalvar.png', label: 'شلوار' },
  { keywords: ['شومیز', 'shomiz'], file: 'shomiz.png', label: 'شومیز' },
  { keywords: ['تیشرت', 'تی‌شرت', 'تی شرت', 'شلوارک', 'tshirt', 'shalvarak'], file: 'tshirt-shalvarak.png', label: 'تیشرت و شلوارک' },
];

const POPULAR_CATEGORY_DIR = '/images/Popular%20Products';
const DEFAULT_CATEGORY_IMAGE = 'https://images.pexels.com/photos/4947543/pexels-photo-4947543.jpeg?auto=compress&cs=tinysrgb&w=400';

function findPopularCategory(category = {}) {
  const haystack = `${category.name || ''} ${category.slug || ''}`.toLowerCase().replace(/[-_]/g, ' ');
  return POPULAR_CATEGORY_IMAGES.find(item => item.keywords.some(keyword => haystack.includes(keyword.toLowerCase())));
}

function categoryImage(category = {}) {
  const match = findPopularCategory(category);
  return match ? `${POPULAR_CATEGORY_DIR}/${match.file}` : DEFAULT_CATEGORY_IMAGE;
}

function ProductSection({ id, title, products, linkLabel = 'مشاهده همه', linkHref = '/products' }) {
  return <section className="section container" id={id}>
    <div className="section-heading">
      <div><h2>{title}</h2></div>
      <Link to={linkHref}>{linkLabel} <Icon name="arrow" size={15} /></Link>
    </div>
    <div className="product-grid">{products.map(product => <ProductCard key={product.id} product={product} />)}</div>
  </section>;
}

function Home() {
  const [products, setProducts] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [latest, setLatest] = useState([]);
  const [apiCategories, setApiCategories] = useState([]);
  const [heroSlide, setHeroSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setHeroSlide(v => (v + 1) % 3), 5200);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    getProducts({ per_page: 8 }).then(({ data }) => setProducts(data?.data || data || [])).catch(() => {});
    getProducts({ per_page: 4, feature: 'featured' }).then(({ data }) => setFeatured(data?.data || data || [])).catch(() => {});
    getProducts({ per_page: 4, sort: 'latest' }).then(({ data }) => setLatest(data?.data || data || [])).catch(() => {});
    getCategories().then(({ data }) => setApiCategories(data?.data || data || [])).catch(() => {});
  }, []);

  const categoryItems = [
    ['مقایسه محصولات', 'compare', '/compare'],
    ['لوازم جانبی لپتاپ', 'laptop', '/products?category=laptop'],
    ['لوازم جانبی موبایل', 'mobile', '/products?category=mobile'],
    ['هدفون و هندزفری', 'audio', '/products?category=audio'],
    ['شارژر و کابل', 'charger', '/products?category=charger'],
    ['استند و نگهدارنده', 'stand', '/products?category=stand'],
    ['سایر تجهیزات', 'other', '/categories'],
  ];

  const heroCopy = [
    ['لوازم جانبی موبایل و لپتاپ', 'با بهترین کیفیت و قیمت', 'از قاب و شارژر تا هندزفری و استند؛ همه‌چیز برای تجربه بهتر شما.', 'مشاهده محصولات'],
    ['انتخاب هوشمندانه', 'برای تکنولوژی روزمره', 'محصولات کاربردی، شیک و قابل اعتماد را سریع‌تر پیدا کنید.', 'مشاهده جدیدترین‌ها'],
    ['ویژه زمانی', 'تخفیف‌های محدود', 'محصولات منتخب با قیمت‌های ویژه؛ فرصت را از دست ندهید.', 'مشاهده تخفیف‌ها'],
  ];

  const heroProducts = products.slice(0, 4);

  return <div className="home-page zamani-luxury-home">
    <section className="zamani-hero container">
      <div className="zamani-hero-copy">
        <span className="zamani-eyebrow">ZAMANI · MOBILE & LAPTOP ACCESSORIES</span>
        <h1>{heroCopy[heroSlide][0]}<br /><b>{heroCopy[heroSlide][1]}</b></h1>
        <p>{heroCopy[heroSlide][2]}</p>
        <div className="zamani-hero-actions">
          <Link to={heroSlide === 2 ? '/special-offers' : heroSlide === 1 ? '/latest' : '/products'} className="zamani-gold-btn">{heroCopy[heroSlide][3]} <Icon name="arrow" size={16}/></Link>
          <Link to="/categories" className="zamani-outline-btn">دسته‌بندی‌ها</Link>
        </div>
      </div>
      <div className="zamani-hero-art" aria-label="محصولات لوازم جانبی">
        <div className="zamani-gold-orb orb-one" /><div className="zamani-gold-orb orb-two" />
        {heroProducts.map((p, i) => <div className={`zamani-floating-product product-${i}`} key={p.id || i}>
          {p.image ? <img src={p.image} alt={p.name || 'محصول زمانی'} /> : <span>Z</span>}
        </div>)}
        {heroProducts.length === 0 && <div className="zamani-hero-placeholder"><Icon name="bag" size={70}/><span>ACCESSORIES</span></div>}
      </div>
      <div className="zamani-slider-controls"><button onClick={() => setHeroSlide(v => (v + 2) % 3)} aria-label="قبلی">‹</button><span>{heroSlide + 1} / 3</span><button onClick={() => setHeroSlide(v => (v + 1) % 3)} aria-label="بعدی">›</button></div>
    </section>

    <section className="zamani-category-strip container">
      {categoryItems.map(([label, icon, href]) => <Link key={label} href={href} className="zamani-category-item"><span><Icon name={icon === 'mobile' ? 'phone' : icon === 'laptop' ? 'laptop' : icon === 'audio' ? 'headphones' : icon === 'charger' ? 'zap' : icon === 'stand' ? 'monitor' : icon === 'compare' ? 'compare' : 'grid'} size={27}/></span><b>{label}</b></Link>)}
    </section>

    <section className="section container zamani-products-section">
      <div className="section-heading"><div><h2>جدیدترین محصولات</h2></div><Link href="/latest">مشاهده همه <Icon name="arrow" size={15}/></Link></div>
      <div className="product-grid">{(latest.length ? latest : products).slice(0, 4).map(product => <ProductCard key={product.id} product={product} />)}</div>
    </section>

    <section className="section container zamani-products-section">
      <div className="section-heading"><div><h2>محبوب‌ترین‌ها</h2></div><Link href="/products">مشاهده همه <Icon name="arrow" size={15}/></Link></div>
      <div className="product-grid">{(featured.length ? featured : products).slice(0, 4).map(product => <ProductCard key={product.id} product={product} />)}</div>
    </section>

    <section className="zamani-promo container">
      <div><span>SMART SHOPPING</span><h2>انتخاب، مقایسه و خرید<br /><b>همه در زمانی</b></h2><p>دستیار زمانی هم برای انتخاب محصول کنار شماست.</p></div>
      <Link href="/compare" className="zamani-gold-btn">مقایسه محصولات <Icon name="compare" size={16}/></Link>
    </section>

    <section className="section container zamani-products-section">
      <div className="section-heading"><div><h2>دسته‌بندی‌های محبوب</h2></div><Link href="/categories">مشاهده همه <Icon name="arrow" size={15}/></Link></div>
      <div className="category-circle-grid">{(apiCategories.length ? apiCategories.slice(0, 6) : POPULAR_CATEGORY_IMAGES.slice(0,6).map((x,i)=>({id:i,name:x.label,slug:''}))).map((category, index) => <Link className="category-circle-item" to={category.slug ? `/categories/${category.slug}` : '/categories'} key={category.id || index}><span className="category-circle"><Icon name={index % 2 ? 'laptop' : 'phone'} size={34}/></span><h3>{category.name}</h3></Link>)}</div>
    </section>
  </div>;
}

export default Home;
