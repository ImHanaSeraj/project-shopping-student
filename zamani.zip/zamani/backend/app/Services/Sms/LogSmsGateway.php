<?php

namespace App\Services\Sms;

use App\Contracts\SmsGatewayInterface;
use Illuminate\Support\Facades\Log;

/**
 * Default SMS driver: no real gateway is configured, so the message is
 * written to the application log instead of being sent. This keeps the OTP
 * flow fully working (codes are visible in the log) in local/dev/testing
 * environments without needing an SMS provider account.
 */
class LogSmsGateway implements SmsGatewayInterface
{
    public function send(string $phone, string $message): void
    {
        Log::info('SMS (log driver — no real gateway configured)', [
            'phone' => $phone,
            'message' => $message,
        ]);
    }
}
