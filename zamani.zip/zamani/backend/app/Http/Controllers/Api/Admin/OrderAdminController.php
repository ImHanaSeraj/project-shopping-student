<?php

namespace App\Http\Controllers\Api\Admin;

use App\Models\Order;
use App\Services\InventoryService;
use App\Services\OrderStatusService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class OrderAdminController extends AdminBaseController
{
    public function index(Request $r)
    {
        $this->guardAdmin($r);
        $q = Order::with(['user:id,name,email,phone','address','items','payment'])->latest();

        if ($r->filled('search')) {
            $s = $r->search;
            $q->where(fn ($x) => $x->where('order_number','like','%'.$s.'%')
                ->orWhereHas('user', fn ($u) => $u->where('name','like','%'.$s.'%')->orWhere('phone','like','%'.$s.'%')));
        }
        if ($r->filled('status')) $q->where('status', $r->status);
        if ($r->filled('payment_status')) $q->where('payment_status', $r->payment_status);

        return $q->paginate(15);
    }

    public function show(Request $r, $id)
    {
        $this->guardAdmin($r);
        return Order::with(['user','address','items.product','payment'])->findOrFail($id);
    }

    public function updateStatus(Request $r, $id, OrderStatusService $statuses)
    {
        $this->guardAdmin($r);

        $d = $r->validate([
            'status' => 'required|in:pending,awaiting_payment,paid,processing,shipped,delivered,cancelled,refund_requested,refunded',
        ]);

        return DB::transaction(function () use ($d, $id, $statuses) {
            $order = Order::whereKey($id)->lockForUpdate()->firstOrFail();
            $from = $order->status;

            try {
                $statuses->transition($order, $d['status']);
            } catch (RuntimeException $e) {
                abort(422, $e->getMessage());
            }

            if ($d['status'] === 'cancelled') {
                app(InventoryService::class)->release($order);
                $order->payment_status = $order->payment_status === 'paid' ? 'paid' : 'cancelled';
            }

            if ($d['status'] === 'refund_requested') {
                $order->payment_status = 'refund_requested';
            }

            if ($d['status'] === 'refunded') {
                $order->payment_status = 'refunded';
            }

            $order->save();

            return $order->load(['user','address','items','payment']);
        });
    }
}
