import { useSearchParams, useNavigate } from '../utils/routerCompat';
import { useEffect, useState } from 'react';
import api from '../services/api';
import { formatPrice } from '../services/cart';
import Icon from '../components/Icon';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { notifyError } from '../components/notifications/notificationBus';

export default function MockPayment() {
  useDocumentTitle('پرداخت آزمایشی | زمانی');
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState('');
  const [ready, setReady] = useState(false);
  const order = params.get('order');
  const payment = params.get('payment');
  const token = params.get('token');

  useEffect(() => {
    setReady(true);
  }, []);

  const callback = async (outcome) => {
    setLoading(outcome);
    try {
      const { data } = await api.post('/payment/mock/callback', { payment:Number(payment), token, outcome });
      navigate(`/payment/result?status=${data.status}&order=${order}&transaction_id=${encodeURIComponent(data.ref_id || '')}&mock=1`, { replace:true });
    } catch (e) {
      setLoading('');
      notifyError(e?.response?.data?.message || 'پرداخت آزمایشی انجام نشد.');
    }
  };

  // Keep the first server/client render identical. Next.js Pages Router may not
  // have the query string available during the initial server render.
  if (!ready) return <main className="payment-result container"><div className="payment-result-card"><div className="payment-result-icon"><Icon name="shield" size={34}/></div><span className="eyebrow">MOCK PAYMENT</span><h1>درگاه پرداخت آزمایشی</h1><p>در حال بارگذاری اطلاعات پرداخت...</p></div></main>;

  if (!order || !payment || !token) return <main className="payment-result container"><div className="payment-result-card is-failed"><div className="payment-result-icon"><Icon name="x" size={34}/></div><h1>اطلاعات پرداخت ناقص است</h1></div></main>;
  return <main className="payment-result container"><div className="payment-result-card">
    <div className="payment-result-icon"><Icon name="shield" size={34}/></div>
    <span className="eyebrow">MOCK PAYMENT</span>
    <h1>درگاه پرداخت آزمایشی</h1>
    <p>این صفحه فقط برای تست منطق پرداخت پروژه است و به بانک یا زرین‌پال متصل نیست.</p>
    <div className="payment-result-meta"><span>شماره سفارش</span><strong>{order}</strong></div>
    <div className="payment-result-actions">
      <button className="btn btn-primary" onClick={() => callback('success')} disabled={!!loading}>{loading==='success'?'در حال تأیید...':'پرداخت موفق'}</button>
      <button className="btn btn-secondary" onClick={() => callback('failed')} disabled={!!loading}>{loading==='failed'?'در حال ثبت...':'پرداخت ناموفق'}</button>
    </div>
  </div></main>;
}