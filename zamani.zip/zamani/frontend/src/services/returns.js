import api from './api';
export const requestReturn = (orderId) => api.post(`/orders/${orderId}/return`);
