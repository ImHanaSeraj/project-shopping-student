<?php
// Add to routes/api.php:
// use App\Http\Controllers\Api\GeminiController;
// Route::post('/ai/gemini', GeminiController::class)->middleware('throttle:ai');
// Route::post('/admin/ai/gemini', GeminiController::class)->middleware(['auth:sanctum','throttle:ai']);
