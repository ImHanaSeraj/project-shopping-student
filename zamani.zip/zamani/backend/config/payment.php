<?php

return [
    // Use "zarinpal" for production. "mock" is intended for local/staging testing only.
    'gateway' => env('PAYMENT_GATEWAY', 'mock'),
    'mock_enabled' => filter_var(env('MOCK_PAYMENT_ENABLED', false), FILTER_VALIDATE_BOOL),
    'mock_frontend_url' => env('MOCK_PAYMENT_FRONTEND_URL', env('APP_URL').'/payment/mock'),
];
