<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AddressManagementTest extends TestCase
{
    use RefreshDatabase;

    private function user(): User
    {
        return User::factory()->create(['status' => true, 'role' => 'customer']);
    }

    private function payload(array $overrides = []): array
    {
        return array_merge([
            'receiver_name' => 'علی رضایی',
            'phone' => '09121234567',
            'province' => 'تهران',
            'city' => 'تهران',
            'address' => 'خیابان نمونه، پلاک ۱۰',
            'postal_code' => '1234567890',
            'is_default' => false,
        ], $overrides);
    }

    public function test_first_address_becomes_default(): void
    {
        $user = $this->user();
        $response = $this->actingAs($user)->postJson('/api/checkout/addresses', $this->payload());
        $response->assertCreated()->assertJsonPath('is_default', true);
    }

    public function test_only_one_default_address_is_kept(): void
    {
        $user = $this->user();
        $first = Address::factory()->create(['user_id' => $user->id, 'is_default' => true]);
        $second = Address::factory()->create(['user_id' => $user->id, 'is_default' => false]);

        $this->actingAs($user)->patchJson("/api/checkout/addresses/{$second->id}/default")
            ->assertOk()
            ->assertJsonPath('is_default', true);

        $this->assertFalse($first->fresh()->is_default);
        $this->assertTrue($second->fresh()->is_default);
    }

    public function test_user_cannot_edit_or_delete_another_users_address(): void
    {
        $owner = $this->user();
        $other = $this->user();
        $address = Address::factory()->create(['user_id' => $other->id]);

        $this->actingAs($owner)->putJson("/api/checkout/addresses/{$address->id}", $this->payload())
            ->assertNotFound();
        $this->actingAs($owner)->deleteJson("/api/checkout/addresses/{$address->id}")
            ->assertNotFound();
        $this->assertDatabaseHas('addresses', ['id' => $address->id, 'user_id' => $other->id]);
    }

    public function test_deleting_default_promotes_another_address(): void
    {
        $user = $this->user();
        $first = Address::factory()->create(['user_id' => $user->id, 'is_default' => true]);
        $second = Address::factory()->create(['user_id' => $user->id, 'is_default' => false]);

        $this->actingAs($user)->deleteJson("/api/checkout/addresses/{$first->id}")->assertOk();
        $this->assertTrue($second->fresh()->is_default);
    }
}
