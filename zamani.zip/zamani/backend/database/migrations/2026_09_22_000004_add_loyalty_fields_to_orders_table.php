<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->unsignedBigInteger('loyalty_points_used')->default(0)->after('discount');
            $table->decimal('loyalty_discount', 14, 2)->default(0)->after('loyalty_points_used');
            $table->unsignedBigInteger('loyalty_points_earned')->default(0)->after('loyalty_discount');
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn(['loyalty_points_used', 'loyalty_discount', 'loyalty_points_earned']);
        });
    }
};
