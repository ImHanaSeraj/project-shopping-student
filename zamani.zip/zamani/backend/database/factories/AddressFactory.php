<?php

namespace Database\Factories;

use App\Models\Address;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class AddressFactory extends Factory
{
    protected $model = Address::class;
    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'receiver_name' => fake()->name(),
            'phone' => '0912' . fake()->numerify('#######'),
            'province' => 'تهران',
            'city' => 'تهران',
            'address' => fake()->address(),
            'postal_code' => fake()->numerify('##########'),
            'is_default' => false,
        ];
    }
}
