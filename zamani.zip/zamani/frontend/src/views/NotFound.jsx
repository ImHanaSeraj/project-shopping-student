import Link from '../components/SafeLink';

import SEOHead from '../components/SEOHead';

export default function NotFound() {
  return <main className="container section not-found-page">
    <SEOHead title="صفحه پیدا نشد" description="صفحه‌ای که به دنبال آن هستید پیدا نشد." noindex path="/404" />
    <span className="eyebrow">404 · PAGE NOT FOUND</span>
    <h1>این صفحه پیدا نشد</h1>
    <p>ممکن است آدرس تغییر کرده باشد یا صفحه موردنظر حذف شده باشد.</p>
    <Link className="btn btn-primary" href="/">بازگشت به صفحه اصلی</Link>
  </main>;
}
