<?php

use App\Http\Controllers\SeoController;
use Illuminate\Support\Facades\Route;

Route::get('/robots.txt', [SeoController::class, 'robots']);
Route::get('/sitemap.xml', [SeoController::class, 'sitemap']);

Route::get('/', function () {
    return response()->json([
        'app' => 'ZAMANI',
        'message' => 'کالکشن زمانی API Backend',
        'status' => 'ok',
    ]);
});
