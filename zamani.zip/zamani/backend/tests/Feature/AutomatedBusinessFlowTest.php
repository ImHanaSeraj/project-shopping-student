<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Category;
use App\Models\Discount;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AutomatedBusinessFlowTest extends TestCase
{
    use RefreshDatabase;

    private function customer(array $overrides = []): User
    {
        return User::factory()->create(array_merge(['role' => 'customer', 'status' => true], $overrides));
    }

    private function admin(): User
    {
        return User::factory()->create(['role' => 'admin', 'status' => true]);
    }

    private function productWithVariant(int $stock = 5): array
    {
        $category = Category::create(['name' => 'تست', 'slug' => 'test-' . uniqid()]);
        $product = Product::create([
            'name' => 'تیشرت تست',
            'slug' => 'test-shirt-' . uniqid(),
            'price' => 500000,
            'discount_price' => null,
            'stock' => $stock,
            'SKU' => 'P-' . uniqid(),
            'category_id' => $category->id,
            'status' => true,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'size' => 'M',
            'color' => 'مشکی',
            'SKU' => 'V-' . uniqid(),
            'stock' => $stock,
            'price' => 650000,
            'status' => true,
        ]);
        return [$product, $variant];
    }

    public function test_register_login_and_logout(): void
    {
        $email = 'auth-' . uniqid() . '@example.com';
        $payload = [
            'name' => 'Customer Test',
            'phone' => '09' . random_int(100000000, 999999999),
            'email' => $email,
            'password' => 'StrongPass123!',
            'password_confirmation' => 'StrongPass123!',
        ];

        $register = $this->postJson('/api/auth/register', $payload)->assertCreated();
        $token = $register->json('token');
        $this->assertNotEmpty($token);

        $login = $this->postJson('/api/auth/login', [
            'login' => $email,
            'password' => 'StrongPass123!',
        ])->assertSuccessful();
        $loginToken = $login->json('token');
        $this->assertNotEmpty($loginToken);

        $this->withToken($loginToken)->postJson('/api/auth/logout')->assertSuccessful();
    }

    public function test_product_variant_and_stock_are_read_from_database(): void
    {
        [$product, $variant] = $this->productWithVariant(7);

        $this->getJson('/api/products/' . $product->id)
            ->assertSuccessful()
            ->assertJsonPath('data.id', $product->id)
            ->assertJsonPath('data.variants.0.id', $variant->id)
            ->assertJsonPath('data.variants.0.stock', 7)
            ->assertJsonPath('data.variants.0.size', 'M');
    }

    public function test_cart_add_update_and_remove(): void
    {
        $user = $this->customer();
        [$product, $variant] = $this->productWithVariant(5);
        Sanctum::actingAs($user);

        $add = $this->postJson('/api/cart/items', [
            'product_id' => $product->id,
            'variant_id' => $variant->id,
            'quantity' => 2,
        ])->assertCreated();
        $itemId = $add->json('item.id');

        $this->patchJson('/api/cart/items/' . $itemId, ['quantity' => 3])
            ->assertSuccessful()
            ->assertJsonPath('item.quantity', 3);

        $this->deleteJson('/api/cart/items/' . $itemId)->assertSuccessful();

        $this->assertDatabaseMissing('cart_items', ['id' => $itemId]);
    }

    public function test_order_creation_rejects_invalid_stock_and_unauthorized_order_access(): void
    {
        $owner = $this->customer();
        $other = $this->customer();
        [$product, $variant] = $this->productWithVariant(1);

        Sanctum::actingAs($owner);
        $cart = Cart::create(['user_id' => $owner->id]);
        CartItem::create([
            'cart_id' => $cart->id,
            'product_id' => $product->id,
            'variant_id' => $variant->id,
            'quantity' => 2,
            'price' => $variant->price,
        ]);
        $address = Address::create([
            'user_id' => $owner->id, 'receiver_name' => 'Test', 'phone' => '09120000000',
            'province' => 'Tehran', 'city' => 'Tehran', 'address' => 'Test',
            'postal_code' => '1234567890', 'is_default' => true,
        ]);

        $this->postJson('/api/checkout', [
            'address_id' => $address->id,
            'shipping_method' => 'standard',
        ])->assertStatus(422);

        $order = Order::create([
            'user_id' => $owner->id,
            'address_id' => $address->id,
            'order_number' => 'TEST-' . strtoupper(uniqid()),
            'total' => 100000,
            'discount' => 0,
            'shipping_cost' => 0,
            'final_total' => 100000,
            'status' => 'pending',
            'payment_status' => 'pending',
            'inventory_status' => 'none',
        ]);
        Sanctum::actingAs($other);
        $this->getJson('/api/orders/' . $order->id)->assertStatus(404);
    }

    public function test_mock_payment_success_failed_and_duplicate_are_covered_by_api_contract(): void
    {
        config(['payment.gateway' => 'mock', 'payment.mock_enabled' => true]);

        $user = $this->customer();
        [$product, $variant] = $this->productWithVariant(2);
        $address = Address::create([
            'user_id' => $user->id, 'receiver_name' => 'Test', 'phone' => '09120000000',
            'province' => 'Tehran', 'city' => 'Tehran', 'address' => 'Test',
            'postal_code' => '1234567890', 'is_default' => true,
        ]);
        $cart = Cart::create(['user_id' => $user->id]);
        CartItem::create([
            'cart_id' => $cart->id, 'product_id' => $product->id,
            'variant_id' => $variant->id, 'quantity' => 1, 'price' => $variant->price,
        ]);

        Sanctum::actingAs($user);
        $this->postJson('/api/checkout', [
            'address_id' => $address->id, 'shipping_method' => 'standard',
        ])->assertCreated();

        $order = Order::where('user_id', $user->id)->latest()->firstOrFail();
        $payment = $order->payments()->latest()->firstOrFail();

        $this->postJson('/api/payments/' . $order->id . '/pay')->assertSuccessful();
        $payment->refresh();

        $payload = ['payment' => $payment->id, 'token' => $payment->authority, 'outcome' => 'success'];
        $this->postJson('/api/payment/mock/callback', $payload)
            ->assertSuccessful()
            ->assertJsonPath('status', 'success');

        $this->postJson('/api/payment/mock/callback', $payload)
            ->assertSuccessful()
            ->assertJsonPath('idempotent', true);

        $order->refresh();
        $variant->refresh();
        $this->assertSame('paid', $order->payment_status);
        $this->assertSame(1, (int) $variant->stock);
    }

    public function test_admin_authorization_and_admin_product_and_discount_endpoints(): void
    {
        $customer = $this->customer();
        Sanctum::actingAs($customer);
        $this->getJson('/api/admin/products')->assertForbidden();
        $this->postJson('/api/admin/discounts', [])->assertForbidden();

        Sanctum::actingAs($this->admin());
        $category = Category::create(['name' => 'ادمین', 'slug' => 'admin-' . uniqid()]);

        $productResponse = $this->postJson('/api/admin/products', [
            'name' => 'محصول ادمین',
            'slug' => 'admin-product-' . uniqid(),
            'price' => 800000,
            'stock' => 0,
            'SKU' => 'ADMIN-' . uniqid(),
            'category_id' => $category->id,
            'status' => true,
            'variants' => [[
                'size' => 'Free Size', 'color' => 'مشکی',
                'SKU' => 'ADMIN-V-' . uniqid(), 'stock' => 3, 'status' => true,
            ]],
        ])->assertCreated();

        $productId = $productResponse->json('data.id');

        $discount = $this->postJson('/api/admin/discounts', [
            'code' => 'AUTO' . strtoupper(substr(uniqid(), -6)),
            'product_id' => $productId,
            'type' => 'percent',
            'value' => 10,
            'status' => true,
        ])->assertCreated();

        $this->assertDatabaseHas('discounts', ['id' => $discount->json('id')]);
    }

    public function test_register_does_not_allow_role_escalation(): void
    {
        $email = 'escalation-' . uniqid() . '@example.com';
        $this->postJson('/api/auth/register', [
            'name' => 'Attacker',
            'phone' => '09' . random_int(100000000, 999999999),
            'email' => $email,
            'password' => 'StrongPass123!',
            'password_confirmation' => 'StrongPass123!',
            'role' => 'admin',
            'status' => true,
        ])->assertCreated();

        $user = User::where('email', $email)->firstOrFail();
        $this->assertSame('customer', $user->role);
    }
}
