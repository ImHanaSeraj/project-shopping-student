<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // role is intentionally a string in this project, so 'manager' needs no DB enum change.
        // Ensure the role/status index exists only if the role column is already present.
        if (Schema::hasColumn('users', 'role') && !Schema::hasColumn('users', 'status')) {
            Schema::table('users', function (Blueprint $table) {
                $table->boolean('status')->default(true)->after('role');
            });
        }
    }

    public function down(): void
    {
        // No destructive rollback: role is a free-form string by design.
    }
};
