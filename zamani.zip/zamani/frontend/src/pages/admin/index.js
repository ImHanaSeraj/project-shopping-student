import Admin from '../../views/admin/Admin';
import AdminRoute from '../../guards/AdminRoute';
export default function AdminPage(){ return <AdminRoute><Admin/></AdminRoute>; }
