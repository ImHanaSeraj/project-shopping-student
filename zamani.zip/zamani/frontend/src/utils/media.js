import { API_URL } from './constants';

const API_ORIGIN = String(API_URL || '').replace(/\/api\/?$/i, '').replace(/\/$/, '');

export function resolveMediaUrl(value) {
  if (!value) return '';
  const src = String(value).trim();
  if (!src) return '';
  if (/^(data:|blob:|https?:|\/\/)/i.test(src)) return src;
  if (src.startsWith('#')) return src;

  // Backend image fields commonly arrive as /storage/... or storage/....
  // Resolve those against Laravel instead of the Next.js frontend origin.
  const clean = src.replace(/^\/+/, '');
  if (/^(storage|uploads|product-images|product_images|media)\//i.test(clean)) {
    return `${API_ORIGIN}/${clean}`;
  }

  // Keep frontend-owned assets such as /images/banners/... untouched.
  return `/${clean}`;
}
