import { useEffect } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import UXFeedback from "../components/UXFeedback";
import ChatWidget from "../components/chat/ChatWidget";
import CompareBar from "../components/products/CompareBar";
import { useLocation } from '../utils/routerCompat';

function ScrollToHash() {
  const { hash, pathname } = useLocation();
  useEffect(() => {
    if (!hash) return;
    const id = hash.replace('#', '');
    const timer = setTimeout(() => {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
    return () => clearTimeout(timer);
  }, [hash, pathname]);
  return null;
}

function MainLayout({ children }) {
  const { pathname } = useLocation();
  // The admin panel gets its own "چت پشتیبانی" inbox tab instead of the
  // floating customer widget.
  const isAdmin = pathname.startsWith('/admin');
  return (
    <div className="app">
      <Header />
      <ScrollToHash />
      <main className="main-content">{children}</main>
      <Footer />
      <UXFeedback />
      {!isAdmin && <ChatWidget />}
      {!isAdmin && <CompareBar />}
    </div>
  );
}
export default MainLayout;
