import api from './api';

// The customer's own conversation channel is public (keyed by a UUID
// session_id) so a guest with no auth token can still receive live replies -
// see routes/channels.php on the backend for why "admin.chat" is the only
// channel that actually needs authorization.
let echoInstance = null;

function authEndpoint() {
  const apiUrl = (process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api').replace(/\/$/, '');
  return apiUrl.replace(/\/api$/, '') + '/broadcasting/auth';
}

// Lazily creates a single Echo/Pusher connection for the whole app. Returns
// null (instead of throwing) when no Pusher key is configured yet, so pages
// can fall back to "live chat isn't set up" instead of crashing.
export function getEcho() {
  if (typeof window === 'undefined') return null;
  const key = process.env.NEXT_PUBLIC_PUSHER_KEY;
  if (!key) return null;
  if (echoInstance) return echoInstance;

  // Loaded lazily so pages that never touch chat don't pay for the bundle.
  const Pusher = require('pusher-js');
  const Echo = require('laravel-echo').default;
  window.Pusher = Pusher;

  const token = localStorage.getItem('token');
  echoInstance = new Echo({
    broadcaster: 'pusher',
    key,
    cluster: process.env.NEXT_PUBLIC_PUSHER_CLUSTER || 'mt1',
    forceTLS: true,
    authEndpoint: authEndpoint(),
    auth: { headers: token ? { Authorization: `Bearer ${token}` } : {} },
  });
  return echoInstance;
}

// Call after login/logout so a new Bearer token is used for private-channel
// (admin.chat) authorization on the next subscription.
export function resetEcho() {
  if (echoInstance) {
    echoInstance.disconnect();
    echoInstance = null;
  }
}

export const chatApi = {
  // Customer widget
  send: (payload) => api.post('/chatbot/send', payload),
  gemini: (payload) => api.post('/ai/gemini', payload),
  escalate: (conversationId) => api.post('/chatbot/escalate', { conversation_id: conversationId }),
  history: (conversationId) => api.get(`/chatbot/${conversationId}`),

  // Admin inbox
  inbox: () => api.get('/admin/support-chat'),
  conversation: (id) => api.get(`/admin/support-chat/${id}`),
  claim: (id) => api.post(`/admin/support-chat/${id}/claim`),
  reply: (id, message) => api.post(`/admin/support-chat/${id}/reply`, { message }),
  close: (id) => api.post(`/admin/support-chat/${id}/close`),
};
