<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->unique(['order_id', 'authority'], 'payments_order_authority_unique');
            $table->unique('ref_id', 'payments_ref_id_unique');
        });
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->dropUnique('payments_order_authority_unique');
            $table->dropUnique('payments_ref_id_unique');
        });
    }
};
