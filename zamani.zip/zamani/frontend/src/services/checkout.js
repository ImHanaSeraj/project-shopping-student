import api from './api';

export const getAddresses = () => api.get('/checkout/addresses');
export const createAddress = (data) => api.post('/checkout/addresses', data);
export const getCheckoutSummary = (shipping_method, discount_code = null) => api.post('/checkout/summary', { shipping_method, discount_code });
export const validateDiscount = (code, shipping_method = 'standard') => api.post('/checkout/discount', { code, shipping_method });
export const createOrder = (data) => api.post('/checkout', data);
