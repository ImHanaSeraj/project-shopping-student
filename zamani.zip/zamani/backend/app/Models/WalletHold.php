<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class WalletHold extends Model { use HasFactory; protected $fillable=['user_id','order_id','amount','status','expires_at','consumed_at','released_at']; protected $casts=['amount'=>'decimal:2','expires_at'=>'datetime','consumed_at'=>'datetime','released_at'=>'datetime']; }
