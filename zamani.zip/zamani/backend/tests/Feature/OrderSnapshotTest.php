<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\Cart;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class OrderSnapshotTest extends TestCase
{
    use RefreshDatabase;

    public function test_order_stores_customer_address_product_and_variant_snapshots(): void
    {
        $user = User::create([
            'name' => 'علی قدیمی',
            'email' => 'snapshot-' . uniqid() . '@example.com',
            'phone' => '09120000001',
            'password' => 'StrongPass123!',
            'status' => true,
        ]);
        $address = Address::create([
            'user_id' => $user->id,
            'receiver_name' => 'گیرنده قدیمی',
            'phone' => '09120000002',
            'province' => 'تهران',
            'city' => 'تهران',
            'address' => 'خیابان قدیمی، پلاک ۱',
            'postal_code' => '1111111111',
        ]);
        $product = Product::create([
            'name' => 'تیشرت قدیمی', 'slug' => 'snapshot-' . uniqid(), 'price' => 500000,
            'stock' => 2, 'SKU' => 'P-SNAPSHOT-' . uniqid(), 'status' => true,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id, 'size' => 'M', 'color' => 'مشکی',
            'SKU' => 'V-SNAPSHOT-' . uniqid(), 'stock' => 2, 'price' => 550000, 'status' => true,
        ]);
        $cart = Cart::create(['user_id' => $user->id]);
        $cart->items()->create(['product_id' => $product->id, 'variant_id' => $variant->id, 'quantity' => 1, 'price' => 550000]);

        Sanctum::actingAs($user);

        $response = $this->postJson('/api/checkout', [
            'address_id' => $address->id,
            'shipping_method' => 'standard',
        ]);

        $response->assertCreated();
        $order = $response->json('order');
        $this->assertSame('علی قدیمی', $order['customer_name']);
        $this->assertSame('گیرنده قدیمی', $order['receiver_name']);
        $this->assertSame('خیابان قدیمی، پلاک ۱', $order['shipping_address']);
        $this->assertSame('تیشرت قدیمی', $order['items'][0]['product_name']);
        $this->assertSame($product->SKU, $order['items'][0]['product_sku']);
        $this->assertSame($variant->SKU, $order['items'][0]['variant_sku']);
        $this->assertSame('M', $order['items'][0]['variant_size']);
        $this->assertSame('مشکی', $order['items'][0]['variant_color']);

        $user->update(['name' => 'علی جدید', 'email' => 'changed@example.com', 'phone' => '09999999999']);
        $address->update(['receiver_name' => 'گیرنده جدید', 'address' => 'آدرس جدید']);
        $product->update(['name' => 'تیشرت جدید', 'price' => 700000]);
        $variant->update(['size' => 'L', 'color' => 'سفید', 'SKU' => 'V-NEW']);

        $show = $this->getJson('/api/orders/' . $order['id'])->assertOk();
        $show->assertJsonPath('snapshot.customer.name', 'علی قدیمی');
        $show->assertJsonPath('snapshot.shipping.receiver_name', 'گیرنده قدیمی');
        $show->assertJsonPath('snapshot.shipping.address', 'خیابان قدیمی، پلاک ۱');
        $show->assertJsonPath('order.items.0.product_name', 'تیشرت قدیمی');
        $show->assertJsonPath('order.items.0.variant_size', 'M');
        $show->assertJsonPath('order.items.0.variant_color', 'مشکی');
    }
}
