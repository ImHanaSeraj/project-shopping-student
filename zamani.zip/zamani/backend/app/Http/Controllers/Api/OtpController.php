<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\OtpService;
use Illuminate\Http\Request;
use RuntimeException;

class OtpController extends Controller
{
    public function __construct(private OtpService $otp)
    {
    }

    /**
     * Request an OTP for password-less login. Always returns the same
     * generic message regardless of whether the phone belongs to an active
     * account, and no SMS is sent for unknown numbers — this prevents the
     * endpoint from being used to check which phone numbers are registered.
     */
    public function requestLogin(Request $request)
    {
        $data = $request->validate([
            'phone' => ['required', 'string', 'max:30'],
        ]);

        $user = User::where('phone', $data['phone'])->where('status', true)->first();

        if ($user) {
            try {
                $this->otp->send($data['phone'], 'login', $request->ip());
            } catch (RuntimeException $e) {
                return response()->json(['message' => $e->getMessage()], 429);
            }
        }

        return response()->json([
            'message' => 'در صورت ثبت بودن این شماره، کد تایید برای آن ارسال شد.',
        ]);
    }

    /** Verify an OTP and log the user in (issuing a Sanctum token), same as password login. */
    public function verifyLogin(Request $request)
    {
        $data = $request->validate([
            'phone' => ['required', 'string', 'max:30'],
            'code' => ['required', 'string', 'max:10'],
        ]);

        $user = User::where('phone', $data['phone'])->where('status', true)->first();

        if (!$user || !$this->otp->verify($data['phone'], $data['code'], 'login')) {
            return response()->json(['message' => 'کد وارد شده نامعتبر یا منقضی شده است.'], 422);
        }

        // A successful OTP login is itself proof of phone ownership.
        if (!$user->phone_verified_at) {
            $user->forceFill(['phone_verified_at' => now()])->save();
        }

        $token = $user->createToken($this->tokenName($request))->plainTextToken;

        return response()->json(['user' => $user->fresh(), 'token' => $token]);
    }

    /** Request an OTP to verify the authenticated user's own current phone number (e.g. before placing an order). */
    public function requestPhoneVerification(Request $request)
    {
        $user = $request->user();

        try {
            $this->otp->send($user->phone, 'phone_verify', $request->ip());
        } catch (RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 429);
        }

        return response()->json(['message' => 'کد تایید برای شماره موبایل شما ارسال شد.']);
    }

    public function verifyPhoneVerification(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:10'],
        ]);

        $user = $request->user();

        if (!$this->otp->verify($user->phone, $data['code'], 'phone_verify')) {
            return response()->json(['message' => 'کد وارد شده نامعتبر یا منقضی شده است.'], 422);
        }

        $user->forceFill(['phone_verified_at' => now()])->save();

        return response()->json([
            'message' => 'شماره موبایل شما با موفقیت تایید شد.',
            'user' => $user->fresh(),
        ]);
    }

    private function tokenName(Request $request): string
    {
        return 'web-otp-' . substr(hash('sha256', (string) $request->userAgent()), 0, 16);
    }
}
