export const APP_NAME = "کالکشن زمانی";
export const APP_NAME_EN = "ZAMANI";
export const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000/api";
