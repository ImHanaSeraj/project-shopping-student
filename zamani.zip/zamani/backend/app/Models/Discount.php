<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
class Discount extends Model {
    protected $fillable = [
        'code','product_id','type','value','start_date','end_date','min_purchase','max_discount',
        'usage_limit','used_count','per_user_limit','status'
    ];
    protected $casts = [
        'status'=>'boolean','start_date'=>'date','end_date'=>'date',
        'value'=>'decimal:2','min_purchase'=>'decimal:2','max_discount'=>'decimal:2',
        'usage_limit'=>'integer','used_count'=>'integer','per_user_limit'=>'integer'
    ];
    public function product(): BelongsTo { return $this->belongsTo(Product::class); }
    public function usages(): HasMany { return $this->hasMany(DiscountUsage::class); }
}
