<?php

namespace Tests\Feature;

use Tests\TestCase;

class HealthCheckTest extends TestCase
{
    public function test_health_endpoint_returns_ok(): void
    {
        $response = $this->getJson('/api/health');

        $response->assertStatus(200)
            ->assertJsonStructure([
                'success',
                'application',
                'status',
                'database',
                'environment',
                'timestamp',
            ]);
    }

    public function test_version_endpoint_returns_api_version(): void
    {
        $response = $this->getJson('/api/version');

        $response->assertOk()
            ->assertJson([
                'success' => true,
                'app' => 'ZAMANI',
                'api_version' => 'v1',
            ]);
    }
}