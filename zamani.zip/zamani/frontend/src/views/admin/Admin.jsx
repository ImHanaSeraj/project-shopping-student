import OptimizedImage from '../../components/OptimizedImage';
import React, {useEffect, useMemo, useRef, useState} from 'react';
import Link from '../../components/SafeLink';
import {useNavigate, useSearchParams} from '../../utils/routerCompat';
import Icon from '../../components/Icon';
import {adminApi} from '../../services/admin';
import {useAuth} from '../../context/AuthContext';
import { useNotifications } from '../../components/notifications/NotificationProvider';
import { notifyError } from '../../components/notifications/notificationBus';
import SupportChat from './SupportChat';
const money = v => new Intl.NumberFormat('fa-IR').format(Number(v||0)) + ' تومان';
const date = v => v ? new Date(v).toLocaleDateString('fa-IR') : '—';
const statusLabel = {pending_payment:'در انتظار پرداخت',paid:'پرداخت شده',processing:'در حال آماده‌سازی',shipped:'ارسال شده',delivered:'تحویل شده',cancelled:'لغو شده',active:'فعال',inactive:'غیرفعال',pending:'در انتظار'};
const paymentLabel = {pending:'در انتظار',paid:'پرداخت شده',failed:'ناموفق',cancelled:'لغو شده'};

function Notice({text,error}){ return text ? <div className={`admin-notice ${error?'error':''}`}>{text}</div> : null; }
function Modal({title,children,onClose}){ return <div className="admin-modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><div className="admin-modal"><div className="modal-head"><h3>{title}</h3><button onClick={onClose}><Icon name="x"/></button></div>{children}</div></div>; }
function Field({label,children,full=false}){return <label className={full?'admin-field full':'admin-field'}><span>{label}</span>{children}</label>}
function CustomSelect({value,onChange,options,placeholder='انتخاب کنید',className='',disabled=false}){
 const [open,setOpen]=useState(false);
 const ref=useRef(null);
 useEffect(()=>{
  if(!open)return;
  const onDoc=e=>{if(ref.current&&!ref.current.contains(e.target))setOpen(false)};
  const onKey=e=>{if(e.key==='Escape')setOpen(false)};
  document.addEventListener('mousedown',onDoc);
  document.addEventListener('keydown',onKey);
  return()=>{document.removeEventListener('mousedown',onDoc);document.removeEventListener('keydown',onKey)};
 },[open]);
 const current=options.find(o=>String(o.value)===String(value));
 return <div className={`custom-select ${open?'open':''} ${disabled?'disabled':''} ${className}`} ref={ref}>
  <button type="button" className="custom-select-trigger" onClick={()=>!disabled&&setOpen(o=>!o)} disabled={disabled}>
   <span className={current?'':'placeholder'}>{current?current.label:placeholder}</span>
   <Icon name="chevron" className="custom-select-caret"/>
  </button>
  {open&&<ul className="custom-select-list" role="listbox">
   {options.map(o=><li key={o.value} role="option" aria-selected={String(o.value)===String(value)} className={String(o.value)===String(value)?'selected':''} onClick={()=>{onChange(o.value);setOpen(false)}}>{o.label}</li>)}
  </ul>}
 </div>
}

export default function Admin(){
 const {user} = useAuth(); const {notifySuccess, notifyError, showDialog} = useNotifications(); const nav=useNavigate(); const [params,setParams]=useSearchParams();
 const initial=params.get('tab')||'dashboard'; const [tab,setTab]=useState(initial);
 const [data,setData]=useState({dashboard:null,products:null,discounts:null,categories:[],brands:[],orders:null,users:null,reviews:null,settings:null});
 const [loading,setLoading]=useState(true); const [page,setPage]=useState(1); const [error,setError]=useState(''); const [notice,setNotice]=useState(''); const [modal,setModal]=useState(null); const [refresh,setRefresh]=useState(0); const [sidebarCollapsed,setSidebarCollapsed]=useState(false);
 useEffect(()=>{if(!user || (user.role!=='admin'&&user.role!=='manager'&&user.is_admin!==true)){nav('/');return;}},[user,nav]);
 useEffect(()=>{setPage(1)},[tab]);
 useEffect(()=>{let alive=true; setLoading(true); setError(''); const load=async()=>{try{if(tab==='support'){if(alive)setLoading(false);return;} let res; if(tab==='dashboard')res=await adminApi.dashboard(); if(tab==='discounts'){res=await adminApi.discounts();} if(tab==='products'){const [p,c,b]=await Promise.all([adminApi.products({page}),adminApi.categories(),adminApi.brands()]); if(!alive)return; setData(d=>({...d,products:p.data,categories:c.data,brands:b.data})); setLoading(false); return;} if(tab==='categories')res=await adminApi.categories(); if(tab==='brands')res=await adminApi.brands(); if(tab==='orders')res=await adminApi.orders({page}); if(tab==='users')res=await adminApi.users({page}); if(tab==='reviews')res=await adminApi.reviews({page}); if(tab==='settings')res=await adminApi.settings(); if(!alive)return; if(!res){setLoading(false);return;} setData(d=>({...d,[tab]:res.data}));}catch(e){if(alive)setError(e.response?.data?.error?.message || e.response?.data?.message || e.message || 'دریافت اطلاعات پنل مدیر انجام نشد.');}finally{if(alive)setLoading(false)}};load();return()=>{alive=false}},[tab,refresh]);
 const select=t=>{setTab(t);setParams({tab:t==='dashboard'?'':t});};
 const reload=()=>setRefresh(x=>x+1);
 const confirmDelete=async(message, fn, successMessage)=>{ const result=await showDialog('question','تأیید حذف',message,{confirmText:'حذف شود',cancelText:'انصراف'}); if(result==='confirm') return act(fn, successMessage); return null; };
 const act=async(fn,msg='عملیات با موفقیت انجام شد.')=>{try{await fn();setNotice(msg);notifySuccess(msg);reload();setTimeout(()=>setNotice(''),2800)}catch(e){const message=e.response?.data?.message||'عملیات انجام نشد.';setError(message);notifyError(message)}};
 if(!user || (user.role!=='admin'&&user.role!=='manager'&&user.is_admin!==true))return null;
 const navItems=[['dashboard','داشبورد','card'],['products','محصولات','bag'],['discounts','تخفیف‌ها','star'],['categories','دسته‌بندی‌ها','menu'],['brands','برندها','star'],['orders','سفارش‌ها','truck'],['users','کاربران','user'],['reviews','نظرات','heart'],['support','چت پشتیبانی','support'],['settings','تنظیمات','card']];
 return <div className="admin-page" dir="rtl">
   <aside className={`admin-sidebar ${sidebarCollapsed ? 'is-collapsed' : ''}`}>
     <div className="admin-brand"><div className="admin-z">Z</div><div className="admin-brand-copy"><b>ZAMANI</b><small>پنل مدیریت فروشگاه</small></div><button type="button" className="admin-sidebar-toggle" onClick={()=>setSidebarCollapsed(v=>!v)} aria-label={sidebarCollapsed?"باز کردن منو":"جمع کردن منو"}>{sidebarCollapsed?"‹":"›"}</button></div>
     <div className="admin-user"><div className="admin-avatar">{(user.name||'A').slice(0,1)}</div><div><strong>{user.name}</strong><small>مدیر سیستم</small></div></div>
     <nav>{navItems.map(([key,label,icon])=><button key={key} className={tab===key?'active':''} onClick={()=>select(key)}><Icon name={icon}/><span>{label}</span></button>)}</nav>
     <div className="admin-side-bottom"><Link href="/"><Icon name="arrow"/> مشاهده فروشگاه</Link><Link href="/account"><Icon name="user"/> حساب کاربری</Link></div>
   </aside>
   <main className="admin-main">
     <header className="admin-top"><div><h1>{navItems.find(x=>x[0]===tab)?.[1]}</h1></div><div className="admin-top-actions"><button onClick={reload} title="بروزرسانی"><Icon name="refresh"/></button><Link href="/"><Icon name="arrow"/> فروشگاه</Link></div></header>
     <Notice text={notice}/><Notice text={error} error/>
     {loading ? <div className="admin-loading"><span></span><p>در حال دریافت اطلاعات...</p></div> : <>
       {tab==='dashboard'&&<Dashboard data={data.dashboard} money={money} date={date} select={select}/>} 
       {tab==='discounts'&&<Discounts data={data.discounts} productsLoad={adminApi.discountProducts} create={adminApi.createDiscount} remove={adminApi.deleteDiscount} act={act} confirmDelete={confirmDelete}/>} 
       {tab==='products'&&<Products data={data.products} categories={data.categories} brands={data.brands} open={setModal} act={act} confirmDelete={confirmDelete} page={page} setPage={setPage}/>} 
       {tab==='categories'&&<Categories data={data.categories} open={setModal} act={act} confirmDelete={confirmDelete}/>} 
       {tab==='brands'&&<Brands data={data.brands} open={setModal} act={act} confirmDelete={confirmDelete}/>} 
       {tab==='orders'&&<Orders data={data.orders} open={setModal} act={act} page={page} setPage={setPage}/>} 
       {tab==='users'&&<Users data={data.users} open={setModal} act={act} page={page} setPage={setPage}/>} 
       {tab==='reviews'&&<Reviews data={data.reviews} act={act} confirmDelete={confirmDelete} page={page} setPage={setPage}/>}
       {tab==='support'&&<SupportChat/>}
       {tab==='settings'&&<Settings data={data.settings} act={act}/>} 
     </>}
   </main>
   {modal?.type==='product'&&<ProductModal item={modal.item} categories={data.categories} brands={data.brands} close={()=>setModal(null)} done={()=>{setModal(null);reload()}}/>}
   {modal?.type==='category'&&<CategoryModal item={modal.item} categories={data.categories} close={()=>setModal(null)} done={()=>{setModal(null);reload()}}/>}
   {modal?.type==='brand'&&<BrandModal item={modal.item} close={()=>setModal(null)} done={()=>{setModal(null);reload()}}/>}
   {modal?.type==='order'&&<OrderModal id={modal.id} close={()=>setModal(null)} act={act}/>} 
   {modal?.type==='user'&&<UserModal id={modal.id} close={()=>setModal(null)} act={act}/>} 
 </div>
}


function Discounts({data,productsLoad,create,remove,act,confirmDelete}){
 const [products,setProducts]=useState([]);
 const [form,setForm]=useState({code:'',product_id:'',type:'percent',value:'',start_date:'',end_date:'',min_purchase:'',max_discount:'',usage_limit:'',per_user_limit:'',status:true});
 useEffect(()=>{productsLoad().then(r=>setProducts(r.data?.data||r.data||[])).catch(()=>{});},[productsLoad]);
 const update=(key,value)=>setForm(f=>({...f,[key]:value}));
 const save=e=>{e.preventDefault();if(!form.code.trim()||!form.value)return;const payload={...form,code:form.code.trim().toUpperCase(),product_id:form.product_id||null,min_purchase:form.min_purchase||0,max_discount:form.max_discount||null,usage_limit:form.usage_limit||null,per_user_limit:form.per_user_limit||null};act(()=>create(payload),'کد تخفیف با موفقیت ایجاد شد.');setForm({code:'',product_id:'',type:'percent',value:'',start_date:'',end_date:'',min_purchase:'',max_discount:'',usage_limit:'',per_user_limit:'',status:true});};
 const list=data?.data||data||[];
 const percentCount=list.filter(d=>d.type==='percent').length;
 const fixedCount=list.filter(d=>d.type==='fixed').length;
 const selectedProduct=products.find(p=>String(p.id)===String(form.product_id));
 return <div className="admin-section discounts-page">
   <div className="discounts-intro"><div><h2>مدیریت کدهای تخفیف</h2><p>کد تخفیف را با شرایط استفاده، تاریخ و محدودیت مصرف مدیریت کنید.</p></div><div className="discounts-count"><strong>{list.length}</strong><span>کد ثبت شده</span></div></div>
   <div className="discount-stats"><div className="discount-stat"><span>کل کدها</span><strong>{list.length}</strong><small>ثبت‌شده</small></div><div className="discount-stat"><span>درصدی</span><strong>{percentCount}</strong><small>تخفیف درصدی</small></div><div className="discount-stat"><span>مبلغ ثابت</span><strong>{fixedCount}</strong><small>تخفیف مبلغی</small></div></div>
   <section className="discount-create-card"><div className="discount-card-head"><div className="discount-head-icon"><Icon name="plus"/></div><div><h3>ایجاد کد تخفیف جدید</h3><p>شرایط کد را مشخص کنید؛ محاسبه نهایی در سرور انجام می‌شود.</p></div></div>
    <form onSubmit={save}><div className="discount-form-grid coupon-grid">
      <Field label="کد تخفیف"><input value={form.code} onChange={e=>update('code',e.target.value.toUpperCase())} placeholder="مثلاً ZAMANI10" required maxLength={50}/></Field>
      <Field label="محصول (اختیاری)"><CustomSelect value={form.product_id} onChange={v=>update('product_id',v)} placeholder="همه محصولات" options={[{value:'',label:'همه محصولات'},...products.map(p=>({value:String(p.id),label:p.name}))]}/>{selectedProduct&&<small className="discount-form-hint">فقط برای این محصول</small>}</Field>
      <Field label="نوع تخفیف"><CustomSelect value={form.type} onChange={v=>update('type',v)} options={[{value:'percent',label:'درصدی'},{value:'fixed',label:'مبلغ ثابت'}]}/></Field>
      <Field label={form.type==='percent'?'درصد':'مبلغ تخفیف'}><div className="discount-value-wrap"><input type="number" min="0" step="0.01" required value={form.value} onChange={e=>update('value',e.target.value)} placeholder={form.type==='percent'?'مثلاً ۱۰':'مثلاً ۱۰۰۰۰۰'}/><span>{form.type==='percent'?'٪':'تومان'}</span></div></Field>
      <Field label="حداقل خرید"><input type="number" min="0" step="0.01" value={form.min_purchase} onChange={e=>update('min_purchase',e.target.value)} placeholder="۰ = بدون محدودیت"/></Field>
      <Field label="سقف تخفیف"><input type="number" min="0" step="0.01" value={form.max_discount} onChange={e=>update('max_discount',e.target.value)} placeholder="اختیاری"/></Field>
      <Field label="شروع"><input type="date" value={form.start_date} onChange={e=>update('start_date',e.target.value)}/></Field>
      <Field label="پایان"><input type="date" value={form.end_date} onChange={e=>update('end_date',e.target.value)}/></Field>
      <Field label="کل دفعات"><input type="number" min="1" step="1" value={form.usage_limit} onChange={e=>update('usage_limit',e.target.value)} placeholder="نامحدود"/></Field>
      <Field label="سقف هر کاربر"><input type="number" min="1" step="1" value={form.per_user_limit} onChange={e=>update('per_user_limit',e.target.value)} placeholder="نامحدود"/></Field>
      <Field label="وضعیت"><CustomSelect value={String(form.status)} onChange={v=>update('status',v==='true')} options={[{value:'true',label:'فعال'},{value:'false',label:'غیرفعال'}]}/></Field>
      <div className="discount-submit-wrap"><button className="admin-btn primary discount-submit" type="submit"><Icon name="plus"/> ثبت کد</button></div>
    </div></form></section>
   <section className="discount-list-card"><div className="discount-list-head"><div><h3>کدهای ثبت‌شده</h3><p>{list.length?'وضعیت و محدودیت مصرف هر کد را بررسی کنید.':'هنوز کدی ثبت نشده است.'}</p></div><span className="discount-list-badge">{list.length} مورد</span></div>
    {list.length?<div className="discount-table-wrap"><table className="discount-table"><thead><tr><th>کد</th><th>محدوده</th><th>تخفیف</th><th>شرایط</th><th>مصرف</th><th>وضعیت</th><th></th></tr></thead><tbody>{list.map(d=><tr key={d.id}>
      <td><strong className="discount-code">{d.code||'—'}</strong></td>
      <td><span>{d.product?.name||'همه محصولات'}</span></td>
      <td><strong className="discount-amount">{d.type==='percent'?`${d.value}٪`:money(d.value)}</strong></td>
      <td><div className="discount-dates"><span>حداقل {money(d.min_purchase||0)}</span><span>{d.max_discount?`سقف ${money(d.max_discount)}`:'بدون سقف'}</span></div></td>
      <td><span>{d.used_count||0}{d.usage_limit?` / ${d.usage_limit}`:' / ∞'}</span><small className="discount-user-limit">هر کاربر: {d.per_user_limit||'∞'}</small></td>
      <td><span className={`discount-status ${d.status===false?'off':'on'}`}><i></i>{d.status===false?'غیرفعال':'فعال'}</span></td>
      <td><button className="discount-delete" onClick={()=>confirmDelete('این کد تخفیف حذف شود؟',()=>remove(d.id),'کد تخفیف حذف شد.')}>حذف</button></td>
    </tr>)}</tbody></table></div>:<div className="discount-empty"><div className="discount-empty-icon"><Icon name="star"/></div><strong>هنوز کد تخفیفی ثبت نشده</strong><span>از فرم بالا اولین کد فروشگاه را ایجاد کنید.</span></div>}
   </section>
 </div>
}

function ViewportCounter({value}){
 const ref=React.useRef(null);
 const target=Number(String(value??0).replace(/[^0-9.-]/g,''))||0;
 const [display,setDisplay]=useState(0);
 useEffect(()=>{
  const el=ref.current;
  if(!el)return;
  let frame=null; let started=false;
  const run=()=>{
   if(started)return; started=true;
   const duration=650; const start=performance.now();
   const tick=now=>{
    const progress=Math.min((now-start)/duration,1);
    const eased=1-Math.pow(1-progress,3);
    setDisplay(Math.round(target*eased));
    if(progress<1) frame=requestAnimationFrame(tick);
   };
   frame=requestAnimationFrame(tick);
  };
  if(!('IntersectionObserver' in window)){run();return()=>{if(frame)cancelAnimationFrame(frame)}}
  const observer=new IntersectionObserver(entries=>{if(entries[0]?.isIntersecting){run();observer.disconnect()}},{threshold:.35});
  observer.observe(el);
  return()=>{observer.disconnect();if(frame)cancelAnimationFrame(frame)};
 },[target]);
 return <strong ref={ref} className="viewport-counter">{new Intl.NumberFormat('fa-IR').format(display)}</strong>;
}

function Dashboard({data,money,date,select}){if(!data)return null; const cards=[['فروش امروز',money(data.sales_today),'card',false],['فروش ماه',money(data.sales_month),'card',false],['تعداد سفارش',data.orders_count,'bag',true],['کاربران',data.users_count,'user',true],['محصولات',data.products_count,'bag',true],['کم‌موجودی',data.low_stock_count,'chevron',true],['سفارش‌های جدید',data.new_orders_count,'truck',true]]; return <div className="admin-section admin-dashboard">
 <div className="metric-grid">
  {cards.map(([l,v,i,count])=><div className="metric" key={l}><div className="metric-icon"><Icon name={i}/></div><div><span>{l}</span>{count?<ViewportCounter value={v}/>:<strong>{v}</strong>}</div></div>)}
  <div className="metric metric-lowstock">
   <div className="metric-lowstock-head"><span>محصولات کم‌موجودی</span><button className="text-action" onClick={()=>select('products')}>مدیریت محصولات</button></div>
   <div className="low-list mini">{data.low_stock_products?.length?data.low_stock_products.map(p=><div className="low-row" key={p.id}><div className="admin-thumb">{p.image?<OptimizedImage src={p.image} alt="" />:<span>Z</span>}</div><div><strong>{p.name}</strong><small>{p.category?.name||'بدون دسته'}</small></div><b className={Number(p.stock)<=2?'danger':''}>{p.stock} عدد</b></div>):<span className="low-list-empty">موردی یافت نشد</span>}</div>
  </div>
 </div>
 <Panel title="سفارش‌های جدید" action={<button className="text-action" onClick={()=>select('orders')}>مشاهده همه</button>}><div className="admin-table-wrap"><table><thead><tr><th>شماره</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th></tr></thead><tbody>{data.new_orders?.map(o=><tr key={o.id}><td>{o.order_number}</td><td>{o.user?.name||'مهمان'}</td><td>{money(o.final_total)}</td><td><Status value={o.status}/></td><td>{date(o.created_at)}</td></tr>)}</tbody></table></div></Panel>
 </div>}

function Panel({title,action,children}){return <section className="admin-panel"><div className="panel-title"><h2>{title}</h2>{action}</div>{children}</section>}
function Status({value}){return <span className={`status-chip ${value}`}>{statusLabel[value]||paymentLabel[value]||value}</span>}
function Toolbar({search,setSearch,action,children}){return <div className="admin-toolbar"><div className="admin-search"><Icon name="search"/><input value={search||''} onChange={e=>setSearch(e.target.value)} placeholder="جستجو..."/></div><div className="toolbar-actions">{children}{action}</div></div>}
function Products({data,categories,brands,open,act,confirmDelete,page,setPage}){const [search,setSearch]=useState('');const [statusFilter,setStatusFilter]=useState('');const list=data?.data||[];const filtered=useMemo(()=>list.filter(p=>(p.name||'').includes(search)||(p.SKU||'').toLowerCase().includes(search.toLowerCase())),[list,search]);return <div className="admin-section"><Toolbar search={search} setSearch={setSearch} action={<button className="admin-btn primary" onClick={()=>open({type:'product'})}><Icon name="plus"/> افزودن محصول</button>}><CustomSelect className="admin-select" value={statusFilter} onChange={setStatusFilter} placeholder="همه وضعیت‌ها" options={[{value:'',label:'همه وضعیت‌ها'},{value:'active',label:'فعال'},{value:'inactive',label:'غیرفعال'}]}/></Toolbar><Panel title={`لیست محصولات`}><div className="admin-table-wrap"><table><thead><tr><th>محصول</th><th>SKU</th><th>دسته</th><th>برند</th><th>قیمت</th><th>تخفیف</th><th>موجودی</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>{filtered.map(p=><tr key={p.id}><td><div className="table-product"><div className="admin-thumb">{p.image?<OptimizedImage src={p.image} alt="" />:<span>Z</span>}</div><strong>{p.name}</strong></div></td><td>{p.SKU}</td><td>{p.category?.name||'—'}</td><td>{p.brand?.name||'—'}</td><td><div>{money(p.price)}{p.discount_price&&<small className="discount-price">{money(p.discount_price)}</small>}</div></td><td>{p.discount_price?`${Math.round((1-(p.discount_price/p.price))*100)}%`: '—'}</td><td><b className={Number(p.stock)<=5?'stock-low':''}>{p.stock}</b></td><td><Status value={p.status?'active':'inactive'}/></td><td><div className="row-actions"><button onClick={()=>open({type:'product',item:p})}>ویرایش</button><button onClick={()=>act(()=>adminApi.toggleProduct(p.id),p.status?'محصول غیرفعال شد.':'محصول فعال شد.')}>{p.status?'غیرفعال':'فعال'}</button><button className="danger-btn" onClick={()=>confirmDelete('محصول حذف شود؟',()=>adminApi.deleteProduct(p.id),'محصول حذف شد.')}>حذف</button></div></td></tr>)}</tbody></table></div><Pagination data={data} page={page} setPage={setPage}/></Panel></div>}
function Categories({data,open,act,confirmDelete}){return <div className="admin-section categories-page"><Toolbar action={<button className="admin-btn primary" onClick={()=>open({type:'category'})}><Icon name="plus"/> افزودن دسته</button>}/><Panel title="دسته‌بندی‌ها"><div className="entity-grid">{data.map(c=><div className="entity-card" key={c.id}><div className="entity-image">{c.image?<OptimizedImage src={c.image} alt="" />:<span>{c.name?.slice(0,1)}</span>}</div><div><h3>{c.name}</h3><small>{c.parent?.name||'دسته اصلی'} · {c.products_count||0} محصول</small></div><div className="entity-actions"><button onClick={()=>open({type:'category',item:c})}>ویرایش</button><button className="danger-btn" onClick={()=>confirmDelete('دسته حذف شود؟',()=>adminApi.deleteCategory(c.id),'دسته حذف شد.')}>حذف</button></div></div>)}</div></Panel></div>}
function Brands({data,open,act,confirmDelete}){return <div className="admin-section brands-page"><Toolbar action={<button className="admin-btn primary" onClick={()=>open({type:'brand'})}><Icon name="plus"/> افزودن برند</button>}/><Panel title="برندها"><div className="entity-grid">{data.map(b=><div className="entity-card" key={b.id}><div className="brand-logo">{b.logo?<OptimizedImage src={b.logo} alt="" />:<span>{b.name?.slice(0,1)}</span>}</div><div><h3>{b.name}</h3><small>{b.products_count||0} محصول</small></div><div className="entity-actions"><button onClick={()=>open({type:'brand',item:b})}>ویرایش</button><button className="danger-btn" onClick={()=>confirmDelete('برند حذف شود؟',()=>adminApi.deleteBrand(b.id),'برند حذف شد.')}>حذف</button></div></div>)}</div></Panel></div>}
function Orders({data,open,act,page,setPage}){const [search,setSearch]=useState('');const [filter,setFilter]=useState('');const list=data?.data||[];const filtered=list.filter(o=>(o.order_number||'').includes(search)||(o.user?.name||'').includes(search)).filter(o=>!filter||o.status===filter);return <div className="admin-section orders-admin-page"><Toolbar search={search} setSearch={setSearch} action={<CustomSelect className="admin-select" value={filter} onChange={setFilter} placeholder="همه وضعیت‌ها" options={[{value:'',label:'همه وضعیت‌ها'},...Object.entries(statusLabel).map(([k,v])=>({value:k,label:v}))]}/>}/><Panel title={`سفارش‌ها · ${data?.total||list.length}`}><div className="admin-table-wrap"><table><thead><tr><th>شماره سفارش</th><th>مشتری</th><th>محصولات</th><th>مبلغ</th><th>شناسه تراکنش</th><th>پرداخت</th><th>وضعیت</th><th>تاریخ</th><th></th></tr></thead><tbody>{filtered.map(o=><tr key={o.id}><td><b>{o.order_number}</b></td><td>{o.user?.name||'مهمان'}<small className="table-sub">{o.user?.phone}</small></td><td>{o.items?.length||0} قلم</td><td>{money(o.final_total)}</td><td>{o.payment?.transaction_id||'—'}</td><td><Status value={o.payment_status}/></td><td><Status value={o.status}/></td><td>{date(o.created_at)}</td><td><button className="link-btn" onClick={()=>open({type:'order',id:o.id})}>جزئیات</button></td></tr>)}</tbody></table></div><Pagination data={data} page={page} setPage={setPage}/></Panel></div>}
function Users({data,open,act,page,setPage}){const [search,setSearch]=useState('');const list=(data?.data||[]).filter(u=>(u.name||'').includes(search)||(u.email||'').toLowerCase().includes(search.toLowerCase())||(u.phone||'').includes(search));return <div className="admin-section"><Toolbar search={search} setSearch={setSearch}/><Panel title={`کاربران · ${data?.total||list.length}`}><div className="admin-table-wrap"><table><thead><tr><th>کاربر</th><th>تماس</th><th>نقش</th><th>سفارش‌ها</th><th>وضعیت</th><th>عضویت</th><th></th></tr></thead><tbody>{list.map(u=><tr key={u.id}><td><div className="table-user"><div className="mini-avatar">{u.name?.slice(0,1)}</div><strong>{u.name}</strong></div></td><td>{u.phone}<small className="table-sub">{u.email}</small></td><td><CustomSelect className="role-select-table" value={u.role||'customer'} onChange={v=>act(()=>adminApi.updateUser(u.id,{role:v}),'نقش کاربر تغییر کرد.')} options={[{value:'customer',label:'مشتری'},{value:'manager',label:'مدیر اجرایی'},{value:'admin',label:'مدیر کل'}]}/></td><td>{u.orders_count||0}</td><td><Status value={u.status?'active':'inactive'}/></td><td>{date(u.created_at)}</td><td><button className="link-btn" onClick={()=>open({type:'user',id:u.id})}>مشاهده</button></td></tr>)}</tbody></table></div><Pagination data={data} page={page} setPage={setPage}/></Panel></div>}
function Reviews({data,act,confirmDelete,page,setPage}){const list=data?.data||[];return <div className="admin-section reviews-admin-page"><Panel title={`نظرات · ${data?.total||list.length}`}><div className="review-admin-list">{list.map(r=><article className="review-admin" key={r.id}><div className="review-head"><div><strong>{r.user?.name||'کاربر'}</strong><small>{r.product?.name||'محصول'} · {date(r.created_at)}</small></div><div className="stars">{'★'.repeat(r.rating)}<span>{'★'.repeat(5-r.rating)}</span></div></div><p>{r.comment||'بدون متن'}</p><div className="review-actions"><Status value={r.status}/><button onClick={()=>act(()=>adminApi.updateReview(r.id,'approved'),'نظر تأیید شد.')}>تأیید</button><button onClick={()=>act(()=>adminApi.updateReview(r.id,'rejected'),'نظر رد شد.')}>رد</button><button className="danger-btn" onClick={()=>confirmDelete('نظر حذف شود؟',()=>adminApi.deleteReview(r.id),'نظر حذف شد.')}>حذف</button></div></article>)}</div><Pagination data={data} page={page} setPage={setPage}/></Panel></div>}

function Pagination({data,page,setPage}){const last=data?.last_page||1;if(last<=1)return null;return <div className="admin-pagination"><button disabled={page<=1} onClick={()=>setPage(page-1)}>قبلی</button><span>صفحه {page} از {last}</span><button disabled={page>=last} onClick={()=>setPage(page+1)}>بعدی</button></div>}

function ProductModal({item,categories,brands,close,done}){
 const [form,setForm]=useState({name:item?.name||'',slug:item?.slug||'',short_description:item?.short_description||'',description:item?.description||'',price:item?.price||'',discount_price:item?.discount_price||'',discount_percent:item?.price&&item?.discount_price?Math.round((1-(Number(item.discount_price)/Number(item.price)))*100):'',stock:item?.stock??0,SKU:item?.SKU||'',category_id:item?.category_id||'',brand_id:item?.brand_id||'',status:item?.status??true,featured:item?.featured??false,images:(item?.images||[]).map(x=>typeof x==='string'?x:x.image)||[],variants:(item?.variants||[]).map(v=>({...v,stock:Number(v.stock||0),price:v.price??'',status:v.status??true}))});
 const [files,setFiles]=useState([]); const [busy,setBusy]=useState(false); const [err,setErr]=useState('');
 const set=(k,v)=>setForm(f=>({...f,[k]:v}));
 const removeImage=i=>set('images',form.images.filter((_,idx)=>idx!==i));
 const addVariant=()=>set('variants',[...form.variants,{size:'',color:'',SKU:'',stock:0,price:'',image:'',status:true}]);
 const updateVariant=(index,key,value)=>set('variants',form.variants.map((v,i)=>i===index?{...v,[key]:value}:v));
 const removeVariant=index=>set('variants',form.variants.filter((_,i)=>i!==index));
 const variantStock=form.variants.filter(v=>v.status!==false).reduce((sum,v)=>sum+Number(v.stock||0),0);
 const submit=async e=>{e.preventDefault();setBusy(true);setErr('');try{let images=[...form.images];for(const file of files){const r=await adminApi.uploadImage(file);images.push(r.data.url)}const variants=form.variants.map(v=>({...v,stock:Number(v.stock||0),price:v.price===''?null:Number(v.price),status:Boolean(v.status)}));const payload={...form,images,price:Number(form.price),discount_price:form.discount_price===''?null:Number(form.discount_price),stock:variants.length?variantStock:Number(form.stock),category_id:Number(form.category_id),brand_id:form.brand_id?Number(form.brand_id):null,variants};delete payload.discount_percent;if(item)await adminApi.updateProduct(item.id,payload);else await adminApi.createProduct(payload);done()}catch(e){setErr(e.response?.data?.message||Object.values(e.response?.data?.errors||{}).flat()[0]||'ذخیره محصول ناموفق بود.')}finally{setBusy(false)}};
 return <Modal title={item?'ویرایش محصول':'افزودن محصول'} onClose={close}><form onSubmit={submit}>
   <div className="form-grid-admin">
    <Field label="نام لباس"><input required value={form.name} onChange={e=>set('name',e.target.value)}/></Field>
    <Field label="SKU اصلی"><input required value={form.SKU} onChange={e=>set('SKU',e.target.value)}/></Field>
    <Field label="قیمت پایه"><input required type="number" min="0" value={form.price} onChange={e=>set('price',e.target.value)}/></Field>
    <Field label="قیمت با تخفیف"><input type="number" min="0" value={form.discount_price} onChange={e=>set('discount_price',e.target.value)}/></Field>
    <Field label="درصد تخفیف"><div className="discount-input"><input type="number" min="0" max="100" value={form.discount_percent} onChange={e=>{const v=e.target.value;set('discount_percent',v);set('discount_price',v===''?'':(Number(form.price)*(100-Number(v))/100).toFixed(0))}}/><span>%</span></div></Field>
    <Field label={form.variants.length?'موجودی کل (محاسبه‌شده)':'موجودی'}><input disabled={form.variants.length>0} required type="number" min="0" value={form.variants.length?variantStock:form.stock} onChange={e=>set('stock',e.target.value)}/>{form.variants.length>0&&<small className="field-hint-admin">جمع موجودی تنوع‌های فعال</small>}</Field>
    <Field label="دسته"><CustomSelect value={form.category_id} onChange={v=>set('category_id',v)} placeholder="انتخاب کنید" options={categories.map(c=>({value:String(c.id),label:c.name}))}/></Field>
    <Field label="برند"><CustomSelect value={form.brand_id} onChange={v=>set('brand_id',v)} placeholder="بدون برند" options={[{value:'',label:'بدون برند'},...brands.map(b=>({value:String(b.id),label:b.name}))]}/></Field>
    <Field label="وضعیت"><CustomSelect value={String(form.status)} onChange={v=>set('status',v==='true')} options={[{value:'true',label:'فعال'},{value:'false',label:'غیرفعال'}]}/></Field>
    <Field label="توضیح کوتاه" full><textarea rows="3" value={form.short_description} onChange={e=>set('short_description',e.target.value)} placeholder="یک توضیح کوتاه درباره محصول بنویسید..."/></Field>
    <Field label="توضیحات کامل" full><textarea rows="8" value={form.description} onChange={e=>set('description',e.target.value)} placeholder="ویژگی‌ها، کاربرد و سازگاری محصول را بنویسید..."/></Field>
    <Field label="تصاویر محصول" full><input type="file" accept="image/*" multiple onChange={e=>setFiles([...e.target.files])}/><div className="image-url-list">{form.images.map((x,i)=><div className="image-chip" key={i}><img src={x} alt="" className="image-chip-thumb"/><button type="button" className="image-chip-remove" onClick={()=>removeImage(i)} aria-label="حذف تصویر" title="حذف تصویر"><Icon name="x"/></button></div>)}{files.map((f,i)=><div className="image-chip pending" key={`new-${i}`}><img src={URL.createObjectURL(f)} alt="" className="image-chip-thumb"/><button type="button" className="image-chip-remove" onClick={()=>setFiles(files.filter((_,idx)=>idx!==i))} aria-label="حذف تصویر" title="حذف تصویر"><Icon name="x"/></button></div>)}</div></Field>
   </div>
   <section className="variant-editor" dir="rtl">
    <div className="variant-editor-head"><div><h3>سایز، رنگ و موجودی</h3><p>هر ردیف یک ترکیب واقعی از لباس است؛ مثلاً مشکی / M یا رنگ / Free Size.</p></div><button type="button" className="admin-btn primary" onClick={addVariant}><Icon name="plus"/> افزودن تنوع</button></div>
    {form.variants.length===0?<div className="variant-empty">هنوز هیچ تنوعی ثبت نشده است. برای لباس‌های سایزبندی‌شده یا فری‌سایز، تنوع‌ها را از همین‌جا اضافه کنید.</div>:<div className="variant-list">{form.variants.map((v,i)=><div className="variant-row" key={v.id||`new-${i}`}>
      <div className="variant-index">{i+1}</div>
      <Field label="سایز"><CustomSelect value={v.size||''} onChange={val=>updateVariant(i,'size',val)} placeholder="بدون سایز" options={[{value:'',label:'بدون سایز'},{value:'S',label:'S'},{value:'M',label:'M'},{value:'L',label:'L'},{value:'XL',label:'XL'},{value:'XXL',label:'XXL'},{value:'Free Size',label:'Free Size'}]}/></Field>
      <Field label="رنگ"><input placeholder="مثلاً مشکی" value={v.color||''} onChange={e=>updateVariant(i,'color',e.target.value)}/></Field>
      <Field label="SKU اختصاصی"><input required placeholder="مثلاً ZM-TS-BLK-M" value={v.SKU||''} onChange={e=>updateVariant(i,'SKU',e.target.value)}/></Field>
      <Field label="موجودی"><input required type="number" min="0" value={v.stock??0} onChange={e=>updateVariant(i,'stock',e.target.value)}/></Field>
      <Field label="قیمت اختصاصی"><input type="number" min="0" placeholder="قیمت پایه" value={v.price??''} onChange={e=>updateVariant(i,'price',e.target.value)}/></Field>
      <Field label="تصویر Variant"><input placeholder="آدرس تصویر" value={v.image||''} onChange={e=>updateVariant(i,'image',e.target.value)}/></Field>
      <Field label="وضعیت"><CustomSelect value={String(v.status!==false)} onChange={val=>updateVariant(i,'status',val==='true')} options={[{value:'true',label:'فعال'},{value:'false',label:'غیرفعال'}]}/></Field>
      <button type="button" className="variant-remove" onClick={()=>removeVariant(i)} aria-label="حذف تنوع">حذف</button>
    </div>)}</div>}
   </section>
   <div className="check-row"><label><input type="checkbox" checked={form.featured} onChange={e=>set('featured',e.target.checked)}/> محصول Featured</label></div>
   <Notice text={err} error/><div className="modal-actions"><button type="button" className="admin-btn" onClick={close}>انصراف</button><button className="admin-btn primary" disabled={busy}>{busy?'در حال ذخیره...':'ذخیره محصول'}</button></div>
 </form></Modal>
}
function CategoryModal({item,categories,close,done}){
 const [form,setForm]=useState({name:item?.name||'',slug:item?.slug||'',description:item?.description||'',image:item?.image||'',parent_id:item?.parent_id||'',status:item?.status??true});
 const [file,setFile]=useState(null); const [preview,setPreview]=useState(item?.image||''); const [busy,setBusy]=useState(false);
 const chooseFile=e=>{const f=e.target.files?.[0]||null;setFile(f);if(f){const url=URL.createObjectURL(f);setPreview(url);}};
 const submit=async e=>{
   e.preventDefault(); setBusy(true);
   try{
     let image=form.image||null;
     if(file){
       const upload=await adminApi.uploadCategoryImage(file);
       image=upload.data?.url || null;
       if(!image) throw new Error('آدرس تصویر از سرور دریافت نشد.');
     }
     const payload={
       name:form.name.trim(),
       slug:form.slug.trim()||null,
       description:form.description||null,
       image,
       parent_id:form.parent_id ? Number(form.parent_id) : null,
       status:!!form.status,
     };
     if(item) await adminApi.updateCategory(item.id,payload); else await adminApi.createCategory(payload);
     done();
   }catch(e){
     const data=e.response?.data||{};
     const errors=data.errors || data.error?.details;
     const detail=errors ? Object.values(errors).flat().join(' ') : (data.error?.message||data.message||e.message||'ذخیره انجام نشد.');
     notifyError(detail);
   }finally{setBusy(false)}
 };
 return <Modal title={item?'ویرایش دسته':'افزودن دسته'} onClose={close}><form onSubmit={submit}><div className="form-grid-admin">
   <Field label="نام"><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></Field>
   <Field label="نامک"><input value={form.slug} onChange={e=>setForm({...form,slug:e.target.value})}/></Field>
   <Field label="دسته والد"><CustomSelect value={form.parent_id} onChange={v=>setForm({...form,parent_id:v})} placeholder="دسته اصلی" options={[{value:'',label:'دسته اصلی'},...categories.filter(c=>c.id!==item?.id).map(c=>({value:String(c.id),label:c.name}))]}/></Field>
   <Field label="تصویر دسته"><div className="category-image-upload"><label className="category-upload-box"><input type="file" accept="image/jpeg,image/png,image/webp" onChange={chooseFile}/><span>{file?'تغییر تصویر':'انتخاب تصویر از سیستم'}</span><small>JPG، PNG یا WEBP — حداکثر ۵ مگابایت</small></label>{preview&&<div className="category-image-preview"><img src={preview} alt="پیش‌نمایش تصویر دسته"/><button type="button" onClick={()=>{setFile(null);setPreview('');setForm({...form,image:''})}}>حذف تصویر</button></div>}</div></Field>
   <Field label="توضیحات" full><textarea rows="4" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></Field>
 </div><div className="modal-actions"><button type="button" className="admin-btn" onClick={close}>انصراف</button><button className="admin-btn primary" disabled={busy}>{busy?'در حال ذخیره...':'ذخیره'}</button></div></form></Modal>
}
function BrandModal({item,close,done}){const [form,setForm]=useState({name:item?.name||'',slug:item?.slug||'',logo:item?.logo||'',description:item?.description||'',status:item?.status??true});const [busy,setBusy]=useState(false);const submit=async e=>{e.preventDefault();setBusy(true);try{item?await adminApi.updateBrand(item.id,form):await adminApi.createBrand(form);done()}catch(e){notifyError(e.response?.data?.message||'ذخیره انجام نشد.')}finally{setBusy(false)}};return <Modal title={item?'ویرایش برند':'افزودن برند'} onClose={close}><form onSubmit={submit}><div className="form-grid-admin"><Field label="نام"><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></Field><Field label="نامک"><input value={form.slug} onChange={e=>setForm({...form,slug:e.target.value})}/></Field><Field label="آدرس لوگو"><input value={form.logo} onChange={e=>setForm({...form,logo:e.target.value})}/></Field><Field label="وضعیت"><CustomSelect value={String(form.status)} onChange={v=>setForm({...form,status:v==='true'})} options={[{value:'true',label:'فعال'},{value:'false',label:'غیرفعال'}]}/></Field><Field label="توضیحات" full><textarea rows="4" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></Field></div><div className="modal-actions"><button type="button" className="admin-btn" onClick={close}>انصراف</button><button className="admin-btn primary" disabled={busy}>{busy?'در حال ذخیره...':'ذخیره'}</button></div></form></Modal>}
function OrderModal({id,close,act}){const [o,setO]=useState(null);const [statusVal,setStatusVal]=useState('');useEffect(()=>{adminApi.order(id).then(r=>{setO(r.data);setStatusVal(r.data.status);}).catch(()=>{});},[id]);if(!o)return <Modal title="جزئیات سفارش" onClose={close}><div className="admin-loading"><span></span></div></Modal>;return <Modal title={`سفارش ${o.order_number}`} onClose={close}><div className="detail-grid"><div><span>مشتری</span><strong>{o.user?.name||'مهمان'}</strong></div><div><span>مبلغ نهایی</span><strong>{money(o.final_total)}</strong></div><div><span>شناسه تراکنش</span><strong>{o.payment?.transaction_id||'—'}</strong></div><div><span>پرداخت</span><Status value={o.payment_status}/></div><div><span>تاریخ</span><strong>{date(o.created_at)}</strong></div></div><h4>محصولات</h4><div className="detail-items">{o.items?.map(i=><div key={i.id}><span>{i.product_name}</span><b>{i.quantity} × {money(i.price)}</b></div>)}</div><div className="order-address"><b>آدرس:</b> {o.address?`${o.address.province}، ${o.address.city}، ${o.address.address} — ${o.address.postal_code}`:'ثبت نشده'}</div><div className="status-editor"><CustomSelect value={statusVal} onChange={setStatusVal} options={[{value:'pending_payment',label:'در انتظار پرداخت'},{value:'paid',label:'پرداخت شده'},{value:'processing',label:'در حال آماده‌سازی'},{value:'shipped',label:'ارسال شده'},{value:'delivered',label:'تحویل شده'},{value:'cancelled',label:'لغو شده'}]}/><button className="admin-btn primary" onClick={()=>{act(()=>adminApi.updateOrder(id,{status:statusVal}),'وضعیت سفارش تغییر کرد.');setO({...o,status:statusVal})}}>ذخیره وضعیت</button></div></Modal>}
function UserModal({id,close,act}){const [u,setU]=useState(null);const [statusVal,setStatusVal]=useState('true');const [roleVal,setRoleVal]=useState('customer');useEffect(()=>{adminApi.user(id).then(r=>{setU(r.data);setStatusVal(String(r.data.status));setRoleVal(r.data.role);}).catch(()=>{});},[id]);if(!u)return <Modal title="اطلاعات کاربر" onClose={close}><div className="admin-loading"><span></span></div></Modal>;return <Modal title={`کاربر · ${u.name}`} onClose={close}><div className="detail-grid"><div><span>نام</span><strong>{u.name}</strong></div><div><span>ایمیل</span><strong>{u.email}</strong></div><div><span>موبایل</span><strong>{u.phone||'—'}</strong></div><div><span>نقش</span><strong>{u.role==='admin'?'مدیر کل':u.role==='manager'?'مدیر اجرایی':'مشتری'}</strong></div></div><div className="status-editor"><CustomSelect value={statusVal} onChange={setStatusVal} options={[{value:'true',label:'فعال'},{value:'false',label:'غیرفعال'}]}/><CustomSelect value={roleVal} onChange={setRoleVal} options={[{value:'customer',label:'مشتری'},{value:'manager',label:'مدیر اجرایی'},{value:'admin',label:'مدیر کل'}]}/><button className="admin-btn primary" onClick={()=>act(()=>adminApi.updateUser(id,{status:statusVal==='true',role:roleVal}),'کاربر به‌روزرسانی شد.')}>ذخیره</button></div><h4>آخرین سفارش‌ها</h4>{u.orders?.length?<div className="detail-items">{u.orders.map(o=><div key={o.id}><span>{o.order_number}</span><b>{money(o.final_total)}</b></div>)}</div>:<p className="muted-admin">سفارشی ثبت نشده است.</p>}</Modal>}


function Settings({data, act}){
 const rows=Array.isArray(data?.data)?data.data:[];
 const initial={store_name:'زمانی', support_phone:'', shipping_fee:'0', free_shipping_threshold:'0', currency:'تومان', special_offer_end_at:''};
 const [values,setValues]=useState(initial);
 useEffect(()=>{
   const next={...initial};
   rows.forEach(r=>{ if(Object.prototype.hasOwnProperty.call(next,r.key)) next[r.key]=r.value??''; });
   setValues(next);
 },[data]);
 const labels={store_name:'نام فروشگاه',support_phone:'شماره پشتیبانی',shipping_fee:'هزینه ارسال (تومان)',free_shipping_threshold:'حداقل خرید برای ارسال رایگان (تومان)',currency:'واحد پول',special_offer_end_at:'پایان شمارش معکوس فروش ویژه'};
 const saveAll=e=>{
   e.preventDefault();
   act(async()=>{
     for(const key of Object.keys(values)){
       await adminApi.saveSetting({key,value:String(values[key]??'')});
     }
   },'تنظیمات با موفقیت ذخیره شد.');
 };
 return <div className="admin-section settings-admin-page">
   <div className="admin-intro">
     <span className="admin-eyebrow settings-eyebrow">STORE / SETTINGS</span>
     <h2>تنظیمات فروشگاه</h2>
     <p>تنظیمات عمومی فروشگاه را از این بخش مدیریت کنید.</p>
   </div>
   <Panel title="تنظیمات عمومی">
     <form className="admin-form-grid" onSubmit={saveAll}>
       {Object.keys(labels).map(key=><Field key={key} label={labels[key]}>
         {key==='special_offer_end_at'?<><input type="datetime-local" value={values[key]} onChange={e=>setValues(v=>({...v,[key]:e.target.value}))}/><small className="field-hint-admin">شمارش معکوس بخش «فروش ویژه» صفحه اصلی و صفحه /special-offers تا این تاریخ و ساعت (به‌وقت تهران) می‌رود.</small></>:<input value={values[key]} onChange={e=>setValues(v=>({...v,[key]:e.target.value}))}/>}
       </Field>)}
       <div><button className="admin-btn primary" type="submit">ذخیره تنظیمات</button></div>
     </form>
   </Panel>
 </div>
}