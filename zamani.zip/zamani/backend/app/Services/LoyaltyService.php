<?php

namespace App\Services;

use App\Models\LoyaltyPointHold;
use App\Models\LoyaltyPointTransaction;
use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class LoyaltyService
{
    public const DEFAULT_POINT_VALUE = 1000;       // 1 point = 1,000 تومان discount
    public const DEFAULT_EARN_THRESHOLD = 10000;   // 1 point per 10,000 تومان eligible spend

    public function pointValue(): int
    {
        return max(1, (int) config('loyalty.point_value', self::DEFAULT_POINT_VALUE));
    }

    public function earnThreshold(): int
    {
        return max(1, (int) config('loyalty.earn_threshold', self::DEFAULT_EARN_THRESHOLD));
    }

    public function availablePoints(User $user, bool $lock = false): int
    {
        $query = User::query()->whereKey($user->id);
        if ($lock) $query->lockForUpdate();
        $lockedUser = $query->firstOrFail();

        $held = (int) LoyaltyPointHold::query()
            ->where('user_id', $lockedUser->id)
            ->where('status', 'held')
            ->where(fn ($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()))
            ->sum('points');

        return max(0, (int) $lockedUser->loyalty_points_balance - $held);
    }

    public function discountForPoints(int $points): float
    {
        return round(max(0, $points) * $this->pointValue(), 2);
    }

    public function maxRedeemable(User $user, float $subtotal, float $couponDiscount = 0): int
    {
        $available = $this->availablePoints($user);
        $eligible = max(0, $subtotal - $couponDiscount);
        return min($available, (int) floor($eligible / $this->pointValue()));
    }

    public function validateRedemption(User $user, int $requested, float $subtotal, float $couponDiscount = 0): array
    {
        if ($requested < 0) {
            throw new RuntimeException('تعداد امتیاز قابل استفاده معتبر نیست.');
        }

        $max = $this->maxRedeemable($user, $subtotal, $couponDiscount);
        if ($requested > $max) {
            throw new RuntimeException("حداکثر {$max} امتیاز برای این سفارش قابل استفاده است.");
        }

        return [
            'points' => $requested,
            'discount' => $this->discountForPoints($requested),
            'available_points' => $this->availablePoints($user),
            'max_points' => $max,
            'point_value' => $this->pointValue(),
        ];
    }

    public function reserve(User $user, Order $order, int $points): ?LoyaltyPointHold
    {
        if ($points <= 0) return null;

        return DB::transaction(function () use ($user, $order, $points) {
            $lockedUser = User::query()->whereKey($user->id)->lockForUpdate()->firstOrFail();

            $existing = LoyaltyPointHold::query()
                ->where('order_id', $order->id)
                ->lockForUpdate()
                ->first();

            if ($existing) {
                if ($existing->status === 'held' && (int) $existing->points !== $points) {
                    throw new RuntimeException('امتیاز رزروشده سفارش با درخواست جدید یکسان نیست.');
                }
                return $existing;
            }

            $held = (int) LoyaltyPointHold::query()
                ->where('user_id', $lockedUser->id)
                ->where('status', 'held')
                ->sum('points');

            $available = max(0, (int) $lockedUser->loyalty_points_balance - $held);
            if ($points > $available) {
                throw new RuntimeException('امتیاز کافی برای این سفارش ندارید.');
            }

            return LoyaltyPointHold::create([
                'user_id' => $lockedUser->id,
                'order_id' => $order->id,
                'points' => $points,
                'status' => 'held',
                'expires_at' => now()->addHours(max(1, (int) config('loyalty.hold_hours', 24))),
            ]);
        }, 3);
    }

    public function consume(Order $order): void
    {
        DB::transaction(function () use ($order) {
            $hold = LoyaltyPointHold::query()->where('order_id', $order->id)->lockForUpdate()->first();
            if (!$hold || $hold->status !== 'held') return;

            $user = User::query()->whereKey($hold->user_id)->lockForUpdate()->firstOrFail();
            $points = (int) $hold->points;
            if ((int) $user->loyalty_points_balance < $points) {
                throw new RuntimeException('موجودی امتیاز کاربر برای تکمیل سفارش کافی نیست.');
            }

            $user->loyalty_points_balance -= $points;
            $user->save();

            $this->recordTransaction(
                $user,
                -$points,
                'redeemed',
                "مصرف {$points} امتیاز برای سفارش {$order->order_number}",
                "order:{$order->id}:redeemed",
                $order
            );

            $hold->forceFill(['status' => 'consumed', 'consumed_at' => now()])->save();
        }, 3);
    }

    public function release(Order $order): void
    {
        $hold = LoyaltyPointHold::query()->where('order_id', $order->id)->first();
        if (!$hold || $hold->status !== 'held') return;

        $hold->forceFill(['status' => 'released', 'released_at' => now()])->save();
    }

    public function earnForOrder(Order $order): int
    {
        if ($order->payment_status !== 'paid') return 0;

        return DB::transaction(function () use ($order) {
            $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
            $existing = LoyaltyPointTransaction::query()
                ->where('reference', "order:{$lockedOrder->id}:earned")
                ->lockForUpdate()
                ->first();

            if ($existing) return (int) $existing->points;

            $eligibleSpend = max(
                0,
                (float) $lockedOrder->total
                - (float) $lockedOrder->discount
                - (float) $lockedOrder->loyalty_discount
            );
            $points = (int) floor($eligibleSpend / $this->earnThreshold());
            if ($points <= 0) return 0;

            $user = User::query()->whereKey($lockedOrder->user_id)->lockForUpdate()->firstOrFail();
            $user->loyalty_points_balance += $points;
            $user->save();

            $this->recordTransaction(
                $user,
                $points,
                'earned',
                "امتیاز خرید سفارش {$lockedOrder->order_number}",
                "order:{$lockedOrder->id}:earned",
                $lockedOrder
            );

            $lockedOrder->forceFill(['loyalty_points_earned' => $points])->save();
            return $points;
        }, 3);
    }

    public function refundRedeemedPoints(Order $order): int
    {
        return DB::transaction(function () use ($order) {
            $reference = "order:{$order->id}:redeemed_refund";
            if (LoyaltyPointTransaction::where('reference', $reference)->exists()) return 0;

            $redeemed = LoyaltyPointTransaction::where('order_id', $order->id)
                ->where('type', 'redeemed')
                ->where('points', '<', 0)
                ->sum(DB::raw('ABS(points)'));

            if ($redeemed <= 0) return 0;

            $user = User::query()->whereKey($order->user_id)->lockForUpdate()->firstOrFail();
            $user->loyalty_points_balance += (int) $redeemed;
            $user->save();

            $this->recordTransaction(
                $user,
                (int) $redeemed,
                'refund',
                "بازگشت امتیاز سفارش {$order->order_number}",
                $reference,
                $order
            );

            return (int) $redeemed;
        }, 3);
    }

    public function refundEarnedPoints(Order $order): int
    {
        return DB::transaction(function () use ($order) {
            $earned = LoyaltyPointTransaction::where('order_id', $order->id)
                ->where('type', 'earned')
                ->where('points', '>', 0)
                ->first();

            if (!$earned) return 0;

            $reference = "order:{$order->id}:earned_refund";
            if (LoyaltyPointTransaction::where('reference', $reference)->exists()) return 0;

            $user = User::query()->whereKey($order->user_id)->lockForUpdate()->firstOrFail();
            $reversal = min((int) $earned->points, (int) $user->loyalty_points_balance);

            if ($reversal <= 0) return 0;

            $user->loyalty_points_balance -= $reversal;
            $user->save();

            $this->recordTransaction(
                $user,
                -$reversal,
                'refund_earned',
                "اصلاح امتیاز خرید مرجوع‌شده {$order->order_number}",
                $reference,
                $order
            );

            return $reversal;
        }, 3);
    }

    public function stats(): array
    {
        return [
            'users_with_points' => User::where('loyalty_points_balance', '>', 0)->count(),
            'total_points' => (int) User::sum('loyalty_points_balance'),
            'points_earned' => (int) LoyaltyPointTransaction::where('type', 'earned')->sum('points'),
            'points_redeemed' => abs((int) LoyaltyPointTransaction::where('type', 'redeemed')->sum('points')),
            'points_refunded' => (int) LoyaltyPointTransaction::where('type', 'refund')->sum('points'),
        ];
    }

    private function recordTransaction(
        User $user,
        int $points,
        string $type,
        string $description,
        string $reference,
        ?Order $order = null
    ): LoyaltyPointTransaction {
        $existing = LoyaltyPointTransaction::where('reference', $reference)->first();
        if ($existing) return $existing;

        return LoyaltyPointTransaction::create([
            'user_id' => $user->id,
            'order_id' => $order?->id,
            'type' => $type,
            'points' => $points,
            'balance_after' => (int) $user->loyalty_points_balance,
            'description' => $description,
            'reference' => $reference,
        ]);
    }
}
