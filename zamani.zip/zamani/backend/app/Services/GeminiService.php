<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use RuntimeException;

class GeminiService
{
    public function generate(string $mode, array $payload): array
    {
        $key = config('services.gemini.key');
        $model = config('services.gemini.model', 'gemini-3.6-flash');
        if (!$key) throw new RuntimeException('کلید Gemini در تنظیمات بک‌اند تعریف نشده است.');

        $system = '';
        $contents = [];
        $config = ['temperature' => 0.35, 'maxOutputTokens' => 700];

        if ($mode === 'product_copy') {
            $type = ($payload['copy_type'] ?? 'full') === 'short' ? 'short' : 'full';
            $product = $payload['product'] ?? [];
            $existing = mb_substr((string)($payload['current_text'] ?? ''), 0, 6000);
            $system = 'تو نویسنده حرفه‌ای محتوای فروشگاه اینترنتی ZAMANI هستی. برای محصول داده‌شده متن فارسی طبیعی، دقیق و قابل استفاده بنویس. اطلاعات فنی یا ویژگی‌هایی که داده نشده‌اند را حدس نزن. از اغراق تبلیغاتی و تکرار بی‌دلیل خودداری کن. ' .
                ($type === 'short' ? 'توضیح کوتاه را در 1 تا 3 جمله و حدود 25 تا 60 کلمه بنویس.' : 'توضیحات کامل را در چند پاراگراف منظم و خوانا بنویس و فقط ویژگی‌های داده‌شده را توضیح بده.') .
                ' پاسخ فقط JSON معتبر با کلید text باشد.';
            $contents[] = ['role'=>'user','parts'=>[['text'=>"نوع متن: $type\nاطلاعات محصول: ".json_encode($product, JSON_UNESCAPED_UNICODE)."\nمتن فعلی: ".($existing ?: 'هنوز متنی نوشته نشده است.')]]];
            $config['maxOutputTokens'] = $type === 'short' ? 250 : 900;
        } elseif ($mode === 'size') {
            $sizes = array_values(array_filter($payload['available_sizes'] ?? []));
            $product = $payload['product'] ?? [];
            $system = 'تو دستیار هوشمند انتخاب سایز فروشگاه ZAMANI هستی. بر اساس قد و وزن یک سایز تقریبی پیشنهاد بده. فقط از سایزهای موجود استفاده کن و اگر داده کافی نیست نزدیک‌ترین گزینه را با اطمینان پایین اعلام کن. پاسخ فقط JSON معتبر با کلیدهای size, confidence, alternative_size, reason باشد. confidence یکی از low, medium, high باشد.';
            $contents[] = ['role'=>'user','parts'=>[['text'=>"قد: ".($payload['height_cm'] ?? '')." سانتی‌متر\nوزن: ".($payload['weight_kg'] ?? '')." کیلوگرم\nسایزهای موجود: ".json_encode($sizes, JSON_UNESCAPED_UNICODE)."\nمحصول: ".json_encode($product, JSON_UNESCAPED_UNICODE)]]];
        } else {
            $system = 'تو دستیار هوشمند فروشگاه اینترنتی پوشاک زنانه ZAMANI (زمانی) هستی. این فروشگاه لباس، کیف، کفش و اکسسوری زنانه می‌فروشد؛ نه موبایل، لپ‌تاپ یا لوازم جانبی دیجیتال. به فارسی روان، مودبانه و کوتاه پاسخ بده و در موضوعاتی مثل انتخاب سایز و راهنمای سایزبندی، انتخاب رنگ و جنس پارچه، مقایسه محصولات پوشاک، ست کردن لباس، وضعیت سفارش، ارسال و مرجوعی کمک کن. اگر اطلاعاتی نداری حدس نزن و کاربر را به پشتیبانی انسانی ارجاع بده.';
            foreach (array_slice($payload['history'] ?? [], -12) as $item) {
                $text = mb_substr((string)($item['content'] ?? ''), 0, 4000);
                if ($text !== '') $contents[] = ['role'=>in_array($item['role'] ?? '', ['assistant','model'], true) ? 'model' : 'user','parts'=>[['text'=>$text]]];
            }
            $message = trim((string)($payload['message'] ?? ''));
            if ($message === '') throw new RuntimeException('پیام خالی است.');
            $contents[] = ['role'=>'user','parts'=>[['text'=>mb_substr($message, 0, 4000)]]];
        }

        // For the two structured modes, force Gemini to actually emit JSON instead
        // of just asking nicely in the prompt - "please reply with only JSON" is a
        // suggestion the model can (and does) ignore, response_mime_type is not.
        if (in_array($mode, ['size', 'product_copy'], true)) {
            $config['responseMimeType'] = 'application/json';
        }

        $url = 'https://generativelanguage.googleapis.com/v1beta/models/'.rawurlencode($model).':generateContent';
        $response = Http::timeout(45)->withHeaders(['x-goog-api-key'=>$key])->post($url, [
            'contents'=>$contents,
            'systemInstruction'=>['parts'=>[['text'=>$system]]],
            'generationConfig'=>$config,
        ]);
        if (!$response->successful()) throw new RuntimeException($response->json('error.message') ?: 'ارتباط با Gemini برقرار نشد.');
        $text = collect($response->json('candidates', []))->flatMap(fn($c)=>$c['content']['parts'] ?? [])->pluck('text')->implode('');
        $text = trim($text);
        if ($text === '') throw new RuntimeException('Gemini پاسخ متنی معتبری برنگرداند.');

        if (in_array($mode, ['size','product_copy'], true)) {
            $data = json_decode($text, true);
            if (!is_array($data)) {
                // Gemini sometimes wraps JSON in markdown fences or returns plain text
                // even when JSON was requested. Be tolerant instead of failing the UI.
                $clean = preg_replace('/^```(?:json)?\s*|\s*```$/iu', '', $text);
                $data = json_decode(trim($clean), true);
            }
            if (!is_array($data)) {
                // Last resort: pull out the first {...} block, in case the model added
                // a stray sentence of commentary before or after the JSON object.
                if (preg_match('/\{.*\}/s', $text, $m)) {
                    $data = json_decode($m[0], true);
                }
            }
            if (!is_array($data) && $mode === 'product_copy') {
                $data = ['text' => trim(preg_replace('/^```(?:text|markdown)?\s*|\s*```$/iu', '', $text))];
            }
            if (!is_array($data)) throw new RuntimeException('Gemini پاسخ قابل پردازشی برنگرداند. متن خام: '.mb_substr($text, 0, 300));
            if ($mode === 'size' && empty($data['size'])) throw new RuntimeException('پاسخ پیشنهاد سایز معتبر نبود.');
            if ($mode === 'product_copy' && empty($data['text'])) throw new RuntimeException('پاسخ تکمیل متن معتبر نبود.');
            return ['data'=>$data,'provider'=>'gemini','model'=>$model];
        }
        return ['reply'=>$text,'provider'=>'gemini','model'=>$model];
    }
}
