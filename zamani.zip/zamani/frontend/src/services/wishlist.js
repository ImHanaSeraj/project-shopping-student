import api from './api';

export async function getWishlist(page = 1) {
  return api.get('/wishlist', { params: { page } });
}

export async function addToWishlist(productId) {
  return api.post(`/wishlist/${productId}`);
}

export async function removeFromWishlist(productId) {
  return api.delete(`/wishlist/${productId}`);
}

export async function getWishlistStatus(productId) {
  return api.get(`/wishlist/${productId}/status`);
}
