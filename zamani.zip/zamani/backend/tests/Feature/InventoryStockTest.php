<?php

namespace Tests\Feature;

use App\Models\Address;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use App\Services\InventoryService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class InventoryStockTest extends TestCase
{
    use RefreshDatabase;

    private function user(): User
    {
        return User::create([
            'name' => 'Inventory Test',
            'email' => 'inventory-' . uniqid() . '@example.com',
            'phone' => '09' . random_int(100000000, 999999999),
            'password' => 'StrongPass123!',
            'role' => 'customer',
            'status' => true,
        ]);
    }

    private function productWithVariant(int $stock): array
    {
        $product = Product::create([
            'name' => 'تیشرت موجودی',
            'slug' => 'inventory-shirt-' . uniqid(),
            'price' => 500000,
            'stock' => $stock,
            'SKU' => 'ZM-INV-' . strtoupper(substr(uniqid(), -6)),
            'status' => true,
        ]);
        $variant = ProductVariant::create([
            'product_id' => $product->id,
            'name' => 'لباس',
            'value' => 'مشکی / M',
            'size' => 'M',
            'color' => 'مشکی',
            'stock' => $stock,
            'SKU' => 'ZM-INV-V-' . strtoupper(substr(uniqid(), -6)),
            'status' => true,
        ]);
        return [$product, $variant];
    }

    private function orderFor(User $user, Product $product, ProductVariant $variant, int $quantity): Order
    {
        $address = Address::create([
            'user_id' => $user->id,
            'receiver_name' => $user->name,
            'phone' => $user->phone,
            'province' => 'تهران',
            'city' => 'تهران',
            'address' => 'آدرس تست',
            'postal_code' => '1111111111',
        ]);
        $order = Order::create([
            'user_id' => $user->id,
            'address_id' => $address->id,
            'order_number' => 'ZM-INV-' . strtoupper(substr(uniqid(), -8)),
            'total' => 500000 * $quantity,
            'discount' => 0,
            'shipping_cost' => 0,
            'final_total' => 500000 * $quantity,
            'status' => 'pending_payment',
            'payment_status' => 'pending',
            'inventory_status' => 'none',
        ]);
        $order->items()->create([
            'product_id' => $product->id,
            'variant_id' => $variant->id,
            'product_name' => $product->name,
            'quantity' => $quantity,
            'price' => 500000,
        ]);
        return $order;
    }

    public function test_stock_zero_cannot_be_added_to_cart(): void
    {
        $user = $this->user();
        [$product, $variant] = $this->productWithVariant(0);
        Sanctum::actingAs($user);

        $this->postJson('/api/cart/items', [
            'product_id' => $product->id,
            'variant_id' => $variant->id,
            'quantity' => 1,
        ])->assertUnprocessable();
    }

    public function test_reservation_of_last_item_reduces_variant_stock_and_product_aggregate(): void
    {
        $user = $this->user();
        [$product, $variant] = $this->productWithVariant(1);
        $order = $this->orderFor($user, $product, $variant, 1);

        DB::transaction(fn () => app(InventoryService::class)->reserve($order));

        $this->assertDatabaseHas('product_variants', ['id' => $variant->id, 'stock' => 0]);
        $this->assertDatabaseHas('products', ['id' => $product->id, 'stock' => 0]);
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'inventory_status' => 'reserved']);
    }

    public function test_second_reservation_cannot_buy_more_than_available_stock(): void
    {
        $user = $this->user();
        [$product, $variant] = $this->productWithVariant(1);
        $first = $this->orderFor($user, $product, $variant, 1);
        DB::transaction(fn () => app(InventoryService::class)->reserve($first));

        $second = $this->orderFor($user, $product, $variant, 1);
        $this->expectException(\RuntimeException::class);
        DB::transaction(fn () => app(InventoryService::class)->reserve($second));
    }

    public function test_payment_failure_releases_reserved_stock_and_is_idempotent(): void
    {
        $user = $this->user();
        [$product, $variant] = $this->productWithVariant(2);
        $order = $this->orderFor($user, $product, $variant, 2);
        DB::transaction(fn () => app(InventoryService::class)->reserve($order));

        DB::transaction(fn () => app(InventoryService::class)->release($order));
        DB::transaction(fn () => app(InventoryService::class)->release($order));

        $this->assertDatabaseHas('product_variants', ['id' => $variant->id, 'stock' => 2]);
        $this->assertDatabaseHas('products', ['id' => $product->id, 'stock' => 2]);
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'inventory_status' => 'released']);
    }

    public function test_successful_payment_commits_reservation_without_double_decrement(): void
    {
        $user = $this->user();
        [$product, $variant] = $this->productWithVariant(1);
        $order = $this->orderFor($user, $product, $variant, 1);
        DB::transaction(fn () => app(InventoryService::class)->reserve($order));
        DB::transaction(fn () => app(InventoryService::class)->commit($order));

        $this->assertDatabaseHas('product_variants', ['id' => $variant->id, 'stock' => 0]);
        $this->assertDatabaseHas('products', ['id' => $product->id, 'stock' => 0]);
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'inventory_status' => 'committed']);
    }

    public function test_cancelled_order_releases_reserved_stock(): void
    {
        $user = $this->user();
        [$product, $variant] = $this->productWithVariant(1);
        $order = $this->orderFor($user, $product, $variant, 1);
        DB::transaction(fn () => app(InventoryService::class)->reserve($order));
        Sanctum::actingAs($user);

        $this->postJson('/api/orders/' . $order->id . '/cancel')
            ->assertOk();

        $this->assertDatabaseHas('product_variants', ['id' => $variant->id, 'stock' => 1]);
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'cancelled', 'inventory_status' => 'released']);
    }
}
