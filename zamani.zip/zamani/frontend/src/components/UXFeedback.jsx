import { useEffect, useState } from 'react';
import Icon from './Icon';

export function notify(message, type = 'success', options = {}) {
  window.dispatchEvent(new CustomEvent('zamani:toast', { detail: { message, type, duration: options.duration ?? 3200 } }));
}

export function confirmAction(message, title = 'تأیید عملیات') {
  return new Promise(resolve => {
    window.dispatchEvent(new CustomEvent('zamani:confirm', { detail: { message, title, resolve } }));
  });
}

export default function UXFeedback() {
  const [toast, setToast] = useState(null);
  const [modal, setModal] = useState(null);

  useEffect(() => {
    const onToast = e => {
      const detail = e.detail || {};
      setToast(detail);
      window.clearTimeout(window.__zamaniToastTimer);
      window.__zamaniToastTimer = window.setTimeout(() => setToast(null), detail.duration || 3200);
    };
    const onConfirm = e => setModal(e.detail);
    window.addEventListener('zamani:toast', onToast);
    window.addEventListener('zamani:confirm', onConfirm);
    return () => {
      window.removeEventListener('zamani:toast', onToast);
      window.removeEventListener('zamani:confirm', onConfirm);
      window.clearTimeout(window.__zamaniToastTimer);
    };
  }, []);

  const closeConfirm = value => {
    if (modal?.resolve) modal.resolve(value);
    setModal(null);
  };

  return <>
    <div className={`ux-toast ${toast ? 'is-visible' : ''} ux-toast-${toast?.type || 'success'}`} role="status" aria-live="polite">
      <span className="ux-toast-icon"><Icon name={toast?.type === 'error' ? 'x' : toast?.type === 'warning' ? 'shield' : 'check'} size={17} /></span>
      <span>{toast?.message}</span>
    </div>

    {modal && <div className="ux-modal-backdrop" role="presentation" onMouseDown={() => closeConfirm(false)}>
      <section className="ux-confirm-modal" role="dialog" aria-modal="true" aria-labelledby="ux-confirm-title" onMouseDown={e => e.stopPropagation()}>
        <button className="ux-modal-close" type="button" onClick={() => closeConfirm(false)} aria-label="بستن"><Icon name="x" size={17}/></button>
        <div className="ux-modal-icon"><Icon name="shield" size={22}/></div>
        <span className="eyebrow">CONFIRM ACTION</span>
        <h2 id="ux-confirm-title">{modal.title || 'تأیید عملیات'}</h2>
        <p>{modal.message}</p>
        <div className="ux-modal-actions"><button className="btn btn-secondary" type="button" onClick={() => closeConfirm(false)}>انصراف</button><button className="btn btn-primary" type="button" onClick={() => closeConfirm(true)}>تأیید</button></div>
      </section>
    </div>}
  </>;
}
