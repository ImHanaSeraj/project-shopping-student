<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(
            ['email' => 'IMHANASERAJ@GMAIL.COM'],
            [
                'name' => 'Hana',
                'phone' => '09107433755',
                'password' => Hash::make('37553755'),
                'role' => 'admin',
            ]
        );
    }
}
