import React, { useEffect, useState } from 'react';
import Link from '../SafeLink';

import Icon from '../Icon';
import { useAuth } from '../../context/AuthContext';
import { addToWishlist, removeFromWishlist } from '../../services/wishlist';
import { useNavigate } from '../../utils/routerCompat';
import { notify } from '../UXFeedback';
import OptimizedImage from '../OptimizedImage';
import { startSharedProductImage } from '../scroll/SharedElementTransition';
import QuickView from './QuickView';
import { isInCompare, toggleCompare, COMPARE_LIMIT } from '../../utils/compareStorage';

const formatPrice = (value) => new Intl.NumberFormat('fa-IR').format(Number(value || 0));
const productPath = (product) => `/products/${product.slug || product.id}`;

export default function ProductCard({ product }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [wishlisted, setWishlisted] = useState(false);
  const [wishlistBusy, setWishlistBusy] = useState(false);
  const [wishlistAnimating, setWishlistAnimating] = useState(false);
  const [quickViewOpen, setQuickViewOpen] = useState(false);
  const [compared, setCompared] = useState(false);

  useEffect(() => {
    const ids = JSON.parse(localStorage.getItem('zamani_wishlist') || '[]');
    setWishlisted(ids.includes(Number(product.id)));
  }, [product.id]);

  useEffect(() => {
    setCompared(isInCompare(product.id));
    const sync = () => setCompared(isInCompare(product.id));
    window.addEventListener('zamani-compare-updated', sync);
    return () => window.removeEventListener('zamani-compare-updated', sync);
  }, [product.id]);

  const handleToggleCompare = (event) => {
    event.preventDefault();
    event.stopPropagation();
    const { added, limitReached } = toggleCompare(product.id);
    if (limitReached) {
      notify(`حداکثر ${COMPARE_LIMIT} محصول را می‌توانید هم‌زمان مقایسه کنید.`, 'error');
      return;
    }
    setCompared(added);
    notify(added ? 'محصول به مقایسه اضافه شد.' : 'محصول از مقایسه حذف شد.');
  };

  const toggleWishlist = async (event) => {
    event.preventDefault();
    event.stopPropagation();

    if (!user) {
      navigate('/login', { state: { from: { pathname: productPath(product) } } });
      return;
    }

    if (wishlistBusy) return;
    setWishlistBusy(true);

    try {
      if (wishlisted) {
        await removeFromWishlist(product.id);
      } else {
        await addToWishlist(product.id);
      }

      setWishlisted(!wishlisted);
      setWishlistAnimating(true);
      window.setTimeout(() => setWishlistAnimating(false), 360);
      notify(wishlisted ? 'محصول از علاقه‌مندی‌ها حذف شد.' : 'محصول به علاقه‌مندی‌ها اضافه شد.');

      const ids = JSON.parse(localStorage.getItem('zamani_wishlist') || '[]');
      const next = wishlisted
        ? ids.filter((id) => Number(id) !== Number(product.id))
        : [...new Set([...ids, Number(product.id)])];

      localStorage.setItem('zamani_wishlist', JSON.stringify(next));
      window.dispatchEvent(new Event('zamani-wishlist-updated'));
    } catch (e) {
      if (e?.response?.status === 401) {
        navigate('/login');
      } else {
        notify('تغییر علاقه‌مندی انجام نشد.', 'error');
      }
    } finally {
      setWishlistBusy(false);
    }
  };

  const images = (product.images || [])
    .map((item) => (typeof item === 'string' ? item : item?.image || item?.path))
    .filter(Boolean);
  const image = images[0] || product.image || '';
  const hoverImage = images[1] || '';
  const price = product.discount_price || product.price;
  const hasDiscount = product.discount_price && Number(product.discount_price) < Number(product.price);
  const discount = hasDiscount
    ? Math.round((1 - Number(product.discount_price) / Number(product.price)) * 100)
    : 0;

  const handleMediaClick = (event) => {
    if (image && event.target.closest('a')) {
      startSharedProductImage(event, product, image);
    }
  };

  const handleDetailsClick = (event) => {
    startSharedProductImage(event, product, image);
  };

  return (
    <>
      <article className="product-card">
        <div className="product-media" onClick={handleMediaClick}>
          {image ? (
            <div className="product-image-swap">
              <OptimizedImage src={image} alt={product.name} />
              {hoverImage && (
                <OptimizedImage
                  src={hoverImage}
                  alt=""
                  aria-hidden="true"
                  className="product-hover-image"
                />
              )}
            </div>
          ) : (
            <div className="product-card-placeholder">
              <span>ZAMANI</span>
              <small>PRODUCT IMAGE</small>
            </div>
          )}

          {hasDiscount && <span className="product-badge">{discount}٪</span>}

          <button
            type="button"
            className={`product-wishlist ${wishlisted ? 'is-active' : ''} ${wishlistAnimating ? 'wishlist-pulse' : ''}`}
            onClick={toggleWishlist}
            aria-label={wishlisted ? 'حذف از علاقه‌مندی' : 'افزودن به علاقه‌مندی'}
            disabled={wishlistBusy}
          >
            <Icon name="heart" size={18} />
          </button>

          <button
            type="button"
            className={`product-compare ${compared ? 'is-active' : ''}`}
            onClick={handleToggleCompare}
            aria-label={compared ? 'حذف از مقایسه' : 'افزودن به مقایسه'}
          >
            <Icon name="compare" size={18} />
          </button>

          <div className="product-quick">
            <button
              type="button"
              onClick={(event) => {
                event.preventDefault();
                event.stopPropagation();
                setQuickViewOpen(true);
              }}
            >
              مشاهده سریع <Icon name="eye" size={14} />
            </button>
            <Link href={productPath(product)} onClick={handleDetailsClick}>
              جزئیات <Icon name="arrow" size={14} />
            </Link>
          </div>
        </div>

        <div className="product-info">
          <div className="product-category">ZAMANI · WOMEN</div>
          <Link href={productPath(product)} onClick={handleDetailsClick}>
            <h3>{product.name}</h3>
          </Link>
          <div className="price-row">
            <strong>
              {formatPrice(price)} <small>تومان</small>
            </strong>
            {hasDiscount && <del>{formatPrice(product.price)}</del>}
          </div>
        </div>
      </article>

      <QuickView
        product={product}
        open={quickViewOpen}
        onClose={() => setQuickViewOpen(false)}
      />
    </>
  );
}
